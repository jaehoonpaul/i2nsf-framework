
Deprecated, go for official version https://pypi.org/project/mysql-connector-python.


