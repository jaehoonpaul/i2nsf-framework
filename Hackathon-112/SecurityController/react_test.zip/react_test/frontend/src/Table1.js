
import logo from './logo.svg';
import './App.css';
import { useHistory } from 'react-router-dom';
import {RealTimeChart, RealTimeChart3} from '.';


const Table1 = ()=> {

	const history = useHistory();
	const componentClicked = (e) =>{
	if (e==='time'){
	history.push({pathname:"/time"})
	}
	}


  return (
    <div className="App">
      <header style={{backgroundColor: "white"}} className="App-header">
        <div style={{fontWeight:'600', fontSize:'40px', color:'black'}}>
<p>
          URL Filtering Resources Data
</p>

</div>
<button onClick={(e)=> componentClicked('time')}>Firewall</button>
<div style={{display:'flex'}}>
<div style={{fontSize:'20px', marginTop:'20px', marginRight:'20px', width:'40%', textAlign:'left', color:'black'}}>
NSF Name : url_filtering
<br></br>
Platform : Linux64
<br></br>
OS : Ubuntu 16.04.7 LTS
<br></br>
Total RAM : 2.4 GB
<br></br>
CPU Model Name : QEMU Virtual CPU version 2.5+ @ 2.4 GHz
<br></br>
Disk size : 20 GB
</div>
<div>
        <RealTimeChart>
	</RealTimeChart>

	<RealTimeChart3>
	</RealTimeChart3>      
</div>
<div>
        <RealTimeChart3>
        </RealTimeChart3>
</div>
<div>


</div>
</div>	
</header>
</div>
  );
}

export default Table1;
