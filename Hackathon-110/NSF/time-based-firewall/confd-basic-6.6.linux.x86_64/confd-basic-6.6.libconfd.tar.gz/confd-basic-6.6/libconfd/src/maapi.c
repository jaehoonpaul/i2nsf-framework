/*
 * Copyright 2005-2007 Tail-F Systems AB
 */

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <stdarg.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <netdb.h>
#include <unistd.h>
#include <errno.h>
#include <assert.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <signal.h>
#include <fcntl.h>

#include "erl_interface.h"
#include "ei.h"
#include "confd_lib.h"
#include "confd_internal.h"
#include "confd_type.h"
#include "confd_maapi.h"
#include "maapi_proto.h"

#include "hash/hashtable.h"

static int cursor_id = 1;

int maapi_connect(int sock, const struct sockaddr* srv, int srv_sz)
{
    int ret;

    if ((ret = confd_do_connect(sock, srv, srv_sz, CLIENT_MAAPI)) != CONFD_OK)
        return ret;
    confd_trace(CONFD_TRACE, "Connected (maapi) to ConfD\n");
    return CONFD_OK;
}


static int intcall(int sock, int op, int thandle, ETERM *req)
{

    ETERM *reply;
    int retval, status;
    clr_confd_err();
    reply = op_request_term(sock, op, thandle, 0, req, &status);
    if (req)
        erl_free_compound(req);
    if (status == CONFD_OK && reply != NULL &&
        ERL_IS_INTEGER(reply)) {
        retval = ERL_INT_VALUE(reply);
    }
    else {
        retval = status;
    }
    if (reply) erl_free_compound(reply);
    return retval;
}

static ETERM *mk_atom_or_binary(const char *str)
{
    if (str == NULL)
        return erl_mk_atom("undefined");
    else
        return erl_mk_binary(str, strlen(str));
}

static ETERM *mk_user_identity(const char *vendor,
                               const char *product,
                               const char *version,
                               const char *client_id)
{
    if (!(vendor || product || version || client_id)) {
        return erl_mk_atom("undefined");
    }

    ETERM *uident[4];
    uident[0] = mk_atom_or_binary(vendor);
    uident[1] = mk_atom_or_binary(product);
    uident[2] = mk_atom_or_binary(version);
    uident[3] = mk_atom_or_binary(client_id);
    return erl_mk_tuple(uident, 4);
}

int maapi_start_user_session3(int sock,
                              const char *username,
                              const char *context,
                              const char **groups, int numgroups,
                              const struct confd_ip *src_addr,
                              int src_port,
                              enum confd_proto prot,
                              const char *vendor,
                              const char *product,
                              const char *version,
                              const char *client_id)
{
    ETERM *ipterm[2];
    ETERM *reqarr[7];
    ETERM *egroups[numgroups];
    int i;

    if (src_addr->af == AF_INET) {
        ipterm[0] = ip4_to_term(&src_addr->ip.v4);
    }
    else if (src_addr->af == AF_INET6) {
        ipterm[0] = ip6_to_term(&src_addr->ip.v6);
    }
    else {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Unknown address family %d", src_addr->af);
    }
    ipterm[1] = erl_mk_uint(src_port);
    if ((username == NULL) && (strcmp(context, "system") == 0)) {
        username = "system";
    }

    reqarr[0] = erl_mk_binary(username, strlen(username));
    reqarr[1] = erl_mk_tuple(ipterm, 2);
    reqarr[2] = erl_mk_atom(context);
    reqarr[3] = erl_mk_int(prot);

    reqarr[4] = erl_mk_atom("false"); // UseIKP
    for (i=0; i<numgroups; i++)
        egroups[i] = erl_mk_binary(groups[i], strlen(groups[i]));
    reqarr[5] = erl_mk_list(egroups, numgroups);
    reqarr[6] = mk_user_identity(vendor, product, version, client_id);

    return intcall(sock,MAAPI_START_USER_SESSION,-1,erl_mk_tuple(reqarr, 7));
}

int maapi_close(int sock)
{
    /* Don't end the user session here, it might be one we got via
       maapi_attach()/maapi_set_user_session()/maapi_start_trans2() */
    /* int status = maapi_end_user_session(sock); */
    if (close(sock) != 0) {
        return ret_err(CONFD_ERR_OS, "Failed to close socket: %s",
                       strerror(errno));
    }
    return CONFD_OK;
}


int maapi_end_user_session(int sock)
{
    return intcall(sock, MAAPI_END_USER_SESSION, -1, NULL);
}

int maapi_get_running_db_status(int sock)
{
    return intcall(sock, MAAPI_GET_RUNNING_DB_STATUS, -1, NULL);
}

int maapi_set_running_db_status(int sock, int status)
{
    return intcall(sock, MAAPI_SET_RUNNING_DB_STATUS, -1, erl_mk_int(status));
}

/* not documented  */
int maapi_restart_node(int sock)
{
    return intcall(sock, MAAPI_RESTART_NODE, -1, NULL);
}

int maapi_kill_user_session(int sock, int usessid)
{
    return intcall(sock, MAAPI_KILL_USER_SESSION, -1, erl_mk_int(usessid));
}

int maapi_get_my_user_session_id(int sock)
{
    return intcall(sock, MAAPI_GET_MY_USER_SESSION, -1, NULL);
}

int maapi_set_user_session(int sock, int usessid)
{
    return intcall(sock, MAAPI_SET_USER_SESSION, -1, erl_mk_int(usessid));
}

int maapi_set_next_user_session_id(int sock, int usessid)
{
    return intcall(sock, MAAPI_SET_NEXT_USER_SESSION_ID,
                   -1, erl_mk_int(usessid));
}

int maapi_attach(int sock, int namespace, struct confd_trans_ctx *ctx)
{
    ETERM *tup[2];
    tup[0] = erl_mk_int(namespace);
    tup[1] = erl_mk_int(ctx->uinfo->usid);
    return intcall(sock, MAAPI_ATTACH, ctx->thandle,
                   erl_mk_tuple(tup,2));
}


int maapi_attach2(int sock, int namespace, int usid, int thandle)
{
    ETERM *tup[2], *req;

    if (thandle == -1) {
        return ret_err(CONFD_ERR_NOEXISTS,
                       "-1 is an invalid transaction handle");
    }
    tup[0] = erl_mk_int(namespace);
    if (usid != 0) {
        tup[1] = erl_mk_int(usid);
        req = erl_mk_tuple(tup,2);
    } else {
        req = erl_mk_tuple(tup,1);
    }
    return intcall(sock, MAAPI_ATTACH, thandle, req);
}

/* Attach to upgrade or init session */
int maapi_attach_init(int sock, int *th)
{
    int ret;
    if (th == NULL) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Invalid NULL th pointer");
    }
    ret = maapi_attach2(sock, -1, -2, -2);
    if (ret == CONFD_OK) {
        *th = -2;
    }
    return ret;
}

int maapi_detach(int sock, struct confd_trans_ctx *ctx)
{
   return intcall(sock, MAAPI_DETACH, ctx->thandle,NULL);
}

int maapi_detach2(int sock, int thandle)
{
   return intcall(sock, MAAPI_DETACH, thandle, NULL);
}


static int do_authenticate(int sock, ETERM *request,
                       char *groups[], int n)
{
    ETERM *reply;
    int status;
    int i = 0;

    reply = op_request_term(sock, MAAPI_AUTHENTICATE,-1,0, request,&status);
    if (status < 0) {
        erl_free_compound(request);
        return status;
    }
    erl_free_compound(request);
    if (ERL_IS_LIST(reply)) {  /* successful auth */
        ETERM *tail = reply;
        while (! ERL_IS_EMPTY_LIST(tail) && i < (n-1)) {
            ETERM *hd = ERL_CONS_HEAD(tail);
            groups[i++] = (char *) confd_memdup(ERL_BIN_PTR(hd),
                                                ERL_BIN_SIZE(hd));
            tail = ERL_CONS_TAIL(tail);
        }
        groups[i] = NULL;
        erl_free_compound(reply);
        return 1;
    }
    else if ERL_IS_TUPLE(reply) {
        groups[0] = NULL;
        confd_set_lasterr("%s", ERL_BIN_PTR(TE(reply,1)));
        erl_free_compound(reply);
        return 0;
    }
    return 0;
}

/* return 0 | 1  | CONFD_ERR | CONFD_EOF */
int maapi_authenticate(int sock, const char *user, const char *pass,
                       char *groups[], int n)
{
    ETERM *request;
    ETERM *tup[2];

    tup[0] = erl_mk_binary(user, strlen(user));
    tup[1] = erl_mk_binary(pass, strlen(pass));
    request = erl_mk_tuple(tup, 2);
    return do_authenticate(sock, request, groups, n);
}

/* return 0 | 1  | CONFD_ERR | CONFD_EOF */
int maapi_authenticate2(int sock, const char *user, const char *pass,
                        const struct confd_ip *src_addr, int src_port,
                        const char *context, enum confd_proto prot,
                        char *groups[], int n)
{
    ETERM *request;
    ETERM *tup[6];

    switch (src_addr->af) {
    case AF_INET:
        tup[2] = ip4_to_term(&src_addr->ip.v4);
        break;
    case AF_INET6:
        tup[2] = ip6_to_term(&src_addr->ip.v6);
        break;
    default:
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Unknown address family %d", src_addr->af);
    }
    tup[0] = erl_mk_binary(user, strlen(user));
    tup[1] = erl_mk_binary(pass, strlen(pass));
    tup[3] = erl_mk_uint(src_port);
    tup[4] = erl_mk_atom(context);
    tup[5] = erl_mk_int(prot);
    request = erl_mk_tuple(tup, 6);
    return do_authenticate(sock, request, groups, n);
}

/* return 0 | 1  | CONFD_ERR | CONFD_EOF */
int maapi_validate_token(int sock, const char *token,
                         const struct confd_ip *src_addr, int src_port,
                         const char *context, enum confd_proto prot,
                         char *groups[], int n)
{
    ETERM *request;
    ETERM *tup[5];
    ETERM *reply;
    int status;
    int i = 0;

    switch (src_addr->af) {
    case AF_INET:
        tup[1] = ip4_to_term(&src_addr->ip.v4);
        break;
    case AF_INET6:
        tup[1] = ip6_to_term(&src_addr->ip.v6);
        break;
    default:
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Unknown address family %d", src_addr->af);
    }
    tup[0] = erl_mk_binary(token, strlen(token));
    tup[2] = erl_mk_uint(src_port);
    tup[3] = erl_mk_atom(context);
    tup[4] = erl_mk_int(prot);
    request = erl_mk_tuple(tup, 5);

    reply = op_request_term(sock, MAAPI_VALIDATE_TOKEN,-1,0, request,
                            &status);
    if (status < 0) {
        erl_free_compound(request);
        return status;
    }
    erl_free_compound(request);
    if (ERL_IS_LIST(reply)) {  /* successful auth */
        ETERM *tail = reply;
        while (! ERL_IS_EMPTY_LIST(tail) && i < (n-1)) {
            ETERM *hd = ERL_CONS_HEAD(tail);
            groups[i++] = (char *) confd_memdup(ERL_BIN_PTR(hd),
                                                ERL_BIN_SIZE(hd));
            tail = ERL_CONS_TAIL(tail);
        }
        groups[i] = NULL;
        erl_free_compound(reply);
        return 1;
    }
    else if ERL_IS_TUPLE(reply) {
        groups[0] = NULL;
        confd_set_lasterr("%s", ERL_BIN_PTR(TE(reply,1)));
        erl_free_compound(reply);
        return 0;
    }
    return 0;
}

int maapi_load_rollback(int sock, int th, int rollback_num)
{
    return intcall(sock, MAAPI_LOAD_ROLLBACK, th, erl_mk_int(rollback_num));
}

int maapi_list_rollbacks(int sock, struct maapi_rollback *rp,
                         int *rp_size)
{
    int status;
    int i = 0;
    ETERM *reply, *tail;

    reply = op_request_term(sock, MAAPI_LIST_ROLLBACK,-1,0, NULL,&status);
    if (status <  0)
        return status;
    tail = reply;
    while (! ERL_IS_EMPTY_LIST(tail) && i < ((*rp_size)-1)) {
        ETERM *hd = ERL_CONS_HEAD(tail);
        struct maapi_rollback *r = (rp + i);
        r->nr = TINT(hd, 0);
        bin_copy(&r->creator[0], MAXUSERNAMELEN, TE(hd,1));
        bin_copy(&r->datestr[0], 255, TE(hd,2));
        bin_copy(&r->via[0], 255, TE(hd,3));
        if (ERL_TUPLE_SIZE(hd) > 4) {
            r->fixed_nr = TINT(hd, 4);
        } else {
            r->fixed_nr = -1;
        }
        if (ERL_TUPLE_SIZE(hd) > 6) {
            bin_copy(&r->label[0], 255, TE(hd,5));
            bin_copy(&r->comment[0], 255, TE(hd,6));
        } else {
            r->label[0] = '\0';
            r->comment[0] = '\0';
        }
        tail = ERL_CONS_TAIL(tail);
        i++;
    }
    erl_free_compound(reply);
    *rp_size = i;
    return CONFD_OK;
}

int maapi_cli_cmd_to_path(int sock, const char *line,
                          char *ns, int nsize,
                          char *path, int psize)
{
    return maapi_cli_cmd_to_path2(sock, -1, line, ns, nsize, path, psize);
}

int maapi_cli_cmd_to_path2(int sock, int th, const char *line,
                           char *ns, int nsize,
                           char *path, int psize)
{
    int status;
    int len;
    ETERM *reply, *namespace, *aaa_path;
    ETERM *cmd;

    cmd = erl_mk_binary(line, strlen(line));

    if (th == -1)
        reply = op_request_term(sock, MAAPI_CLI_CMD_TO_PATH, -1, 0,
                                cmd, &status);
    else
        reply = op_request_term(sock, MAAPI_CLI_CMD_TO_PATH2, th, 0,
                                cmd, &status);

    if (status <  0)
        return status;

    if (!ERL_IS_TUPLE(reply) || ERL_TUPLE_SIZE(reply) != 2) {
        return ret_err(CONFD_ERR_INTERNAL, "Bad reply data");
    }
    namespace = ERL_TUPLE_ELEMENT(reply, 0);
    aaa_path = ERL_TUPLE_ELEMENT(reply, 1);

    if (!ERL_IS_BINARY(namespace) || !ERL_IS_BINARY(aaa_path)) {
        return ret_err(CONFD_ERR_INTERNAL, "Bad reply data");
    }

    /* copy namespace */

    len = ERL_BIN_SIZE(namespace);

    if (len > (nsize-1))
        len = nsize-1;

    memcpy(ns, ERL_BIN_PTR(namespace), len);
    ns[len]='\0';

    /* copy path */

    len = ERL_BIN_SIZE(aaa_path);

    if (len > (psize-1))
        len = psize-1;

    memcpy(path, ERL_BIN_PTR(aaa_path), len);
    path[len]='\0';


    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_cli_prompt(int sock, int usess, const char *prompt, int echo,
                     char *res, int size)
{
    int status;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[5];

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(prompt, strlen(prompt));
    tup[2] = erl_mk_empty_list();
    if (echo)
        tup[3] = erl_mk_atom("true");
    else
        tup[3] = erl_mk_atom("false");
    tup[4] = erl_mk_atom("infinity");

    request = erl_mk_tuple(tup, 5);

    reply = op_request_term(sock, MAAPI_CLI_PROMPT, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_prompt2(int sock, int usess, const char *prompt, int echo,
                      int timeout, char *res, int size)
{
    int status;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[5];

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(prompt, strlen(prompt));
    tup[2] = erl_mk_empty_list();
    if (echo)
        tup[3] = erl_mk_atom("true");
    else
        tup[3] = erl_mk_atom("false");
    tup[4] = erl_mk_int(timeout*1000);

    request = erl_mk_tuple(tup, 5);

    reply = op_request_term(sock, MAAPI_CLI_PROMPT, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_read_eof(int sock, int usess, int echo, char *res, int size)
{
    int status;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[3];

    tup[0] = erl_mk_int(usess);
    if (echo)
        tup[1] = erl_mk_atom("true");
    else
        tup[1] = erl_mk_atom("false");
    tup[2] = erl_mk_atom("infinity");

    request = erl_mk_tuple(tup, 3);

    reply = op_request_term(sock, MAAPI_CLI_READ_EOF, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_read_eof2(int sock, int usess, int echo, int timeout,
                        char *res, int size)
{
    int status;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[3];

    tup[0] = erl_mk_int(usess);
    if (echo)
        tup[1] = erl_mk_atom("true");
    else
        tup[1] = erl_mk_atom("false");
    tup[2] = erl_mk_int(timeout*1000);

    request = erl_mk_tuple(tup, 3);

    reply = op_request_term(sock, MAAPI_CLI_READ_EOF, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_prompt_oneof(int sock, int usess, const char *prompt,
                           char **choice, int count, char *res, int size)
{
    int status;
    int i;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[5];
    ETERM *tup2[count];

    for(i = 0 ; i < count ; i++)
        tup2[i] = erl_mk_binary(choice[i], strlen(choice[i]));

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(prompt, strlen(prompt));
    tup[2] = erl_mk_list(tup2, count);
    tup[3] = erl_mk_atom("true");
    tup[4] = erl_mk_atom("infinity");

    request = erl_mk_tuple(tup, 5);

    reply = op_request_term(sock, MAAPI_CLI_PROMPT, -1, 0,
                            request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_prompt_oneof2(int sock, int usess, const char *prompt,
                            char **choice, int count,
                            int timeout, char *res, int size)
{
    int status;
    int i;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[5];
    ETERM *tup2[count];

    for(i = 0 ; i < count ; i++)
        tup2[i] = erl_mk_binary(choice[i], strlen(choice[i]));

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(prompt, strlen(prompt));
    tup[2] = erl_mk_list(tup2, count);
    tup[3] = erl_mk_atom("true");
    tup[4] = erl_mk_int(timeout*1000);

    request = erl_mk_tuple(tup, 5);

    reply = op_request_term(sock, MAAPI_CLI_PROMPT, -1, 0,
                            request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_write(int sock, int usess, const char *buf, int size)
{
    int status;
    ETERM *request;
    ETERM *tup[2];
    ETERM *reply;

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    request = erl_mk_tuple(tup, 2);

    reply = op_request_term(sock, MAAPI_CLI_WRITE, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_get(int sock, int usess, const char *opt, char *res, int size)
{
    int status;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[2];

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(opt, strlen(opt));
    request = erl_mk_tuple(tup, 2);

    reply = op_request_term(sock, MAAPI_CLI_GET, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

    erl_free_compound(request);
    erl_free_compound(reply);

    return -1;
}

int maapi_cli_set(int sock, int usess, const char *opt, const char *value)
{
    int status;
    ETERM *request;
    ETERM *reply;
    ETERM *tup[3];

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(opt, strlen(opt));
    tup[2] = erl_mk_binary(value, strlen(value));
    request = erl_mk_tuple(tup, 3);

    reply = op_request_term(sock, MAAPI_CLI_SET, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_diff_cmd(int sock, int thandle, int thandle_old, char *res,
                       int size, int flags, const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args,fmt);
    ret = maapi_vcli_diff_cmd(sock, thandle, thandle_old, res,
                              size, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vcli_diff_cmd(int sock, int thandle, int thandle_old, char *res,
                        int size, int flags, const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *request;
    ETERM *tup[3];
    ETERM *reply;

    clr_confd_err();

    if ((tup[0] = parse_path(&isrel, fmt, args)) == NULL)
        goto err;

    if (isrel == 1)
        goto err;

    tup[1] = erl_mk_int(flags),
    tup[2] = erl_mk_int(thandle_old),

    request = erl_mk_tuple(tup, 3);
    reply =
        op_request_term(sock, MAAPI_CLI_DIFF_CMD, thandle, 0, request, &status);

    if (status < 0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

  err:
    return ret_err(CONFD_ERR_BADPATH, "bad path");
}

int maapi_cli_path_cmd(int sock, int thandle, char *res, int size, int flags,
                       const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args,fmt);
    ret = maapi_vcli_path_cmd(sock, thandle, res, size, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vcli_path_cmd(int sock, int thandle, char *res, int size, int flags,
                       const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *request;
    ETERM *tup[2];
    ETERM *reply;

    clr_confd_err();

    if ((tup[0] = parse_path(&isrel, fmt, args)) == NULL)
        goto err;

    if (isrel == 1)
        goto err;

    tup[1] = erl_mk_int(flags),

    request = erl_mk_tuple(tup, 2);
    reply =
        op_request_term(sock, MAAPI_CLI_PATH_CMD, thandle, 0, request, &status);

    if (status < 0) {
        erl_free_compound(request);
        return status;
    }

    if (ERL_IS_BINARY(reply)) {
        int len = ERL_BIN_SIZE(reply);

        if (len > (size-1))
            len = size-1;

        memcpy(res, ERL_BIN_PTR(reply), len);
        res[len]='\0';

        erl_free_compound(request);
        erl_free_compound(reply);

        return CONFD_OK;
    }

  err:
    return ret_err(CONFD_ERR_BADPATH, "bad path");
}

int maapi_cli_cmd(int sock, int usess, const char *buf, int size)
{
    int status;
    ETERM *request;
    ETERM *tup[4];
    ETERM *reply;

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    tup[2] = erl_mk_int(0);
    tup[3] = erl_mk_binary(buf, 0);
    request = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_CLI_CMD, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_cmd2(int sock, int usess, const char *buf, int size, int flags)
{
    int status;
    ETERM *request;
    ETERM *tup[4];
    ETERM *reply;

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    tup[2] = erl_mk_int(flags);
    tup[3] = erl_mk_binary(buf, 0);
    request = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_CLI_CMD, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_cmd3(int sock, int usess, const char *buf, int size, int flags,
                   const char *unhide, int usize)
{
    int status;
    ETERM *request;
    ETERM *tup[4];
    ETERM *reply;

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    tup[2] = erl_mk_int(flags);
    tup[3] = erl_mk_binary(unhide, usize);
    request = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_CLI_CMD, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_cmd4(int sock, int usess, const char *buf, int size, int flags,
                   char **unhide, int usize)
{
    int status;
    ETERM *request;
    ETERM *tup[4];
    ETERM *reply;
    ETERM *unhide_list[usize];
    int i;

    for(i = 0 ; i < usize ; i++) {
        int s = strlen(unhide[i]);
        unhide_list[i] = erl_mk_binary(unhide[i], s);
    }

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    tup[2] = erl_mk_int(flags);
    tup[3] = erl_mk_list(unhide_list, usize);
    request = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_CLI_CMD, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_cmd_io(int sock, int usess, const char *buf, int size, int flags,
                      const char *unhide, int usize)
{
    int status;
    ETERM *request;
    ETERM *tup[4];
    ETERM *reply;

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    tup[2] = erl_mk_int(flags);
    tup[3] = erl_mk_binary(unhide, usize);
    request = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_CLI_CMD_IO, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        status = ERL_INT_VALUE(reply);
        erl_free_compound(request);
        erl_free_compound(reply);
        return status;
    }
}

int maapi_cli_cmd_io2(int sock, int usess, const char *buf, int size, int flags,
                      char **unhide, int usize)
{
    int status;
    ETERM *request;
    ETERM *tup[4];
    ETERM *reply;

    ETERM *unhide_list[usize];
    int i;

    for(i = 0 ; i < usize ; i++) {
        int s = strlen(unhide[i]);
        unhide_list[i] = erl_mk_binary(unhide[i], s);
    }

    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(buf, size);
    tup[2] = erl_mk_int(flags);
    tup[3] = erl_mk_list(unhide_list, usize);
    request = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_CLI_CMD_IO, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        status = ERL_INT_VALUE(reply);
        erl_free_compound(request);
        erl_free_compound(reply);
        return status;
    }
}


int maapi_cli_cmd_io_result(int sock, int saveId)
{
    return intcall(sock, MAAPI_CLI_CMD_IO_RESULT, -1, erl_mk_int(saveId));
}

int maapi_cli_printf(int sock, int usess, const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args,fmt);
    ret = maapi_cli_vprintf(sock, usess, fmt, args);
    va_end(args);
    return ret;
}

int maapi_cli_vprintf(int sock, int usess, const char *fmt, va_list args)
{
    va_list args2;
    int status;
    ETERM *tup[2];
    ETERM *request;
    ETERM *reply;
    char buf[BUFSIZ];
    int size;
    char *tptr = &buf[0];

    va_copy(args2, args);
    size = vsnprintf(tptr, BUFSIZ, fmt, args);
    if (size >= BUFSIZ) {
        if ((tptr = confd_malloc(size+1)) == NULL)
            return CONFD_ERR;
        vsnprintf(tptr, size, fmt, args2);
    }
    tup[0] = erl_mk_int(usess);
    tup[1] = erl_mk_binary(tptr, size);
    request = erl_mk_tuple(tup, 2);

    reply = op_request_term(sock, MAAPI_CLI_WRITE, -1, 0, request, &status);

    if (tptr != &buf[0])
        free(tptr);
    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}


int maapi_user_message(int sock, const char *to, const char *message,
                       const char *sender)
{
    int status;
    ETERM *request;
    ETERM *tup[3];
    ETERM *reply;

    tup[0] = erl_mk_binary(to, strlen(to));
    tup[1] = erl_mk_binary(message, strlen(message));
    tup[2] = erl_mk_binary(sender, strlen(sender));
    request = erl_mk_tuple(tup, 3);

    reply = op_request_term(sock, MAAPI_USER_MESSAGE, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_sys_message(int sock, const char *to, const char *message)
{
    int status;
    ETERM *request;
    ETERM *tup[2];
    ETERM *reply;

    tup[0] = erl_mk_binary(to, strlen(to));
    tup[1] = erl_mk_binary(message, strlen(message));
    request = erl_mk_tuple(tup, 2);

    reply = op_request_term(sock, MAAPI_SYS_MESSAGE, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_cli_accounting(int sock, const char *user, const int usid,
                         const char *cmdstr)
{
    int status;
    ETERM *request;
    ETERM *tup[3];
    ETERM *reply;

    tup[0] = erl_mk_binary(user, strlen(user));
    tup[1] = erl_mk_int(usid);
    tup[2] = erl_mk_binary(cmdstr, strlen(cmdstr));
    request = erl_mk_tuple(tup, 3);

    reply =
        op_request_term(sock, MAAPI_CLI_ACCOUNTING, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}

int maapi_prio_message(int sock, const char *to, const char *message)
{
    int status;
    ETERM *request;
    ETERM *tup[2];
    ETERM *reply;

    tup[0] = erl_mk_binary(to, strlen(to));
    tup[1] = erl_mk_binary(message, strlen(message));
    request = erl_mk_tuple(tup, 2);

    reply = op_request_term(sock, MAAPI_PRIO_MESSAGE, -1, 0, request, &status);

    if (status <  0) {
        erl_free_compound(request);
        return status;
    }
    else {
        erl_free_compound(request);
        erl_free_compound(reply);
        return CONFD_OK;
    }
}


int maapi_get_user_sessions(int sock, int res[], int n)
{
    ETERM *reply, *tail;
    int status;
    int i = 0;
    reply = op_request_term(sock, MAAPI_GET_USER_SESSIONS,-1,0, NULL,&status);
    tail = reply;
    if (status < 0) return status;

    while (! ERL_IS_EMPTY_LIST(tail)) {
        if (i < n) {
            ETERM *hd = ERL_CONS_HEAD(tail);
            res[i] = ERL_INT_VALUE(hd);
        }
        i++;
        tail = ERL_CONS_TAIL(tail);
    }
    erl_free_compound(reply);
    return i;
}

int maapi_get_user_session(int sock, int usessid,
                           struct confd_user_info *us)
{
    int status;
    ETERM *req, *reply;
    ETERM *utup;
    int lmode;

    req = erl_mk_int(usessid);
    reply = op_request_term(sock, MAAPI_GET_USER_SESSION, -1, 0, req, &status);
    erl_free_compound(req);
    if (status < 0) {
        return CONFD_ERR;
    }
    if (ERL_TUPLE_SIZE(reply) != 2) {
        ret_err(CONFD_ERR_INTERNAL, "internal protocol error (sz=%d)",
                ERL_TUPLE_SIZE(reply));
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    utup = TE(reply, 0);
    lmode = TINT(reply, 1);
    _confd_mk_uinfo(utup, us);
    us->lmode = lmode;
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_get_user_session_identification(
    int sock, int usessid,
    struct confd_user_identification *uident)
{
    int status;
    ETERM *req, *reply;
    int sz;

    req = erl_mk_int(usessid);
    reply = op_request_term(sock, MAAPI_GET_USER_SESSION_IDENTIFICATION,
                            -1, 0, req, &status);
    erl_free_compound(req);
    if (status < 0) {
        return CONFD_ERR;
    }
    if ((sz = ERL_TUPLE_SIZE(reply)) != 4) {
        erl_free_compound(reply);
        return confd_internal_error("internal protocol error (sz=%d)", sz);
    }
    uident->vendor = bin_dup(TE(reply, 0));
    uident->product = bin_dup(TE(reply, 1));
    uident->version = bin_dup(TE(reply, 2));
    uident->client_identity = bin_dup(TE(reply, 3));
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_get_user_session_opaque(int sock, int usessid, char **opaque)
{
    int status;
    ETERM *req, *reply;

    req = erl_mk_int(usessid);
    reply = op_request_term(sock, MAAPI_GET_USER_SESSION_OPAQUE,
                            -1, 0, req, &status);
    erl_free_compound(req);
    if (status < 0) {
        return CONFD_ERR;
    }
    *opaque = bin_dup(reply);
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_get_authorization_info(int sock, int usessid,
                                 struct confd_authorization_info **ainfo)
{
    int status;
    ETERM *req, *reply;
    struct confd_authorization_info *ai;
    ETERM *groups;
    int i;

    req = erl_mk_int(usessid);
    reply = op_request_term(sock, MAAPI_GET_AUTHORIZATION_INFO,
                            -1, 0, req, &status);
    erl_free_compound(req);
    if (status < 0) {
        return CONFD_ERR;
    }
    /* keep confd_free_authorization_info() in sync if more info is added! */
    if (!ERL_IS_TUPLE(reply) || ERL_TUPLE_SIZE(reply) < 1) {
        erl_free_compound(reply);
        return ret_err(CONFD_ERR_INTERNAL, "bad reply data");
    }
    groups = TE(reply, 0);
    ai = confd_malloc(sizeof(struct confd_authorization_info));
    if (ai != NULL) {
        ai->ngroups = erl_length(groups);
        ai->groups = confd_malloc(ai->ngroups * sizeof(char *));
        if (ai->groups != NULL) {
            for (i = 0; i < ai->ngroups; i++) {
                ai->groups[i] = bin_dup(ERL_CONS_HEAD(groups));
                groups = ERL_CONS_TAIL(groups);
            }
            erl_free_compound(reply);
            *ainfo = ai;
            return CONFD_OK;
        } else {
            free(ai);
        }
    }
    erl_free_compound(reply);
    return CONFD_ERR;
}


/* db management */

int maapi_lock(int sock, enum confd_dbname name)
{
    return intcall(sock, MAAPI_LOCK, -1, erl_mk_int(name));
}

int maapi_unlock(int sock, enum confd_dbname name)
{
    return intcall(sock, MAAPI_UNLOCK, -1, erl_mk_int(name));
}

int maapi_is_lock_set(int sock,  enum confd_dbname name)
{
    return intcall(sock, MAAPI_IS_LOCK_SET, -1, erl_mk_int(name));
}

int maapi_lock_partial(int sock, enum confd_dbname name,
                       char *xpaths[], int nxpaths, int *lockid)
{
    ETERM *list[nxpaths];
    ETERM *tup[2], *req, *reply;
    int i, status;

    clr_confd_err();
    for (i = 0; i < nxpaths; i++)
        list[i] = erl_mk_binary(xpaths[i], strlen(xpaths[i]));
    tup[0] = erl_mk_int(name);
    tup[1] = erl_mk_list(list, nxpaths);
    req = erl_mk_tuple(tup, 2);
    reply = op_request_term(sock, MAAPI_LOCK_PARTIAL, -1, 0, req, &status);
    erl_free_compound(req);
    if (status < 0)
        return status;
    *lockid = ERL_INT_VALUE(reply);
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_unlock_partial(int sock, int lockid)
{
    return intcall(sock, MAAPI_UNLOCK_PARTIAL, -1, erl_mk_int(lockid));
}

int maapi_candidate_validate(int sock)
{
    return intcall(sock, MAAPI_CANDIDATE_VALIDATE, -1, NULL);
}

int maapi_delete_config(int sock,  enum confd_dbname name)
{
    return intcall(sock, MAAPI_DELETE_CONFIG, -1, erl_mk_int(name));
}

int maapi_candidate_commit(int sock)
{
    return maapi_candidate_commit_info(sock, NULL, NULL, NULL);
}

int maapi_candidate_commit_persistent(int sock, const char *persist_id)
{
    return maapi_candidate_commit_info(sock, persist_id, NULL, NULL);
}

int maapi_candidate_commit_info(int sock,
                                const char *persist_id,
                                const char *label,
                                const char *comment)
{
    ETERM *tup[3];

    if (persist_id != NULL)
        tup[0] = erl_mk_binary(persist_id, strlen(persist_id));
    else
        tup[0] = erl_mk_atom("undefined");
    if (label != NULL)
        tup[1] = erl_mk_binary(label, strlen(label));
    else
        tup[1] = erl_mk_binary("", 0);
    if (comment != NULL)
        tup[2] = erl_mk_binary(comment, strlen(comment));
    else
        tup[2] = erl_mk_binary("", 0);
    return intcall(sock,  MAAPI_CANDIDATE_COMMIT, -1, erl_mk_tuple(tup, 3));
}

int maapi_candidate_abort_commit(int sock)
{
    return intcall(sock,  MAAPI_CANDIDATE_ABORT_COMMIT, -1, NULL);
}

int maapi_candidate_abort_commit_persistent(int sock, const char *persist_id)
{
    ETERM *pi = NULL;
    if (persist_id != NULL)
        pi = erl_mk_binary(persist_id, strlen(persist_id));
    return intcall(sock,  MAAPI_CANDIDATE_ABORT_COMMIT, -1, pi);
}

int maapi_confirmed_commit_in_progress(int sock)
{
    return intcall(sock,  MAAPI_CONFIRMED_COMMIT_IN_PROGRESS, -1, NULL);
}

int maapi_candidate_confirmed_commit(int sock, int timeoutsecs)
{
    return maapi_candidate_confirmed_commit_info(
        sock, timeoutsecs, NULL, NULL, NULL, NULL);
}

int maapi_candidate_confirmed_commit_persistent(int sock, int timeoutsecs,
                                                const char *persist,
                                                const char *persist_id)
{
    return maapi_candidate_confirmed_commit_info(
        sock, timeoutsecs, persist, persist_id, NULL, NULL);
}

int maapi_candidate_confirmed_commit_info(int sock, int timeoutsecs,
                                          const char *persist,
                                          const char *persist_id,
                                          const char *label,
                                          const char *comment)
{
    ETERM *tup[5];
    tup[0] = erl_mk_int(timeoutsecs);
    if (persist != NULL)
        tup[1] = erl_mk_binary(persist, strlen(persist));
    else
        tup[1] = erl_mk_atom("undefined");
    if (persist_id != NULL)
        tup[2] = erl_mk_binary(persist_id, strlen(persist_id));
    else
        tup[2] = erl_mk_atom("undefined");
    if (label != NULL)
        tup[3] = erl_mk_binary(label, strlen(label));
    else
        tup[3] = erl_mk_binary("", 0);
    if (comment != NULL)
        tup[4] = erl_mk_binary(comment, strlen(comment));
    else
        tup[4] = erl_mk_binary("", 0);
    return intcall(sock, MAAPI_CANDIDATE_CONFIRMED_COMMIT,  -1,
                   erl_mk_tuple(tup, 5));
}

int maapi_candidate_reset(int sock)
{
    return intcall(sock, MAAPI_CANDIDATE_RESET, -1, NULL);
}

int maapi_copy_running_to_startup(int sock)
{
    return intcall(sock, MAAPI_COPY_RUNNING_TO_STARTUP, -1, NULL);
}

int maapi_is_running_modified(int sock)
{
    return intcall(sock, MAAPI_IS_RUNNING_MODIFIED, -1, NULL);
}

int maapi_is_candidate_modified(int sock)
{
    return intcall(sock, MAAPI_IS_CANDIDATE_MODIFIED, -1, NULL);
}

int maapi_start_trans_flags2(int sock, enum confd_dbname dbname,
                             enum confd_trans_mode readwrite,
                             int usid, int flags,
                             const char *vendor,
                             const char *product,
                             const char *version,
                             const char *client_id)
{
    int useikp = 0;
    ETERM *req = erl_format("{~i,~i,~i,~i,~i, ~w}",
                            dbname, readwrite, usid, useikp, flags,
                            mk_user_identity(vendor, product, version,
                                             client_id));

    return intcall(sock, MAAPI_START_TRANS, -1, req);
}

int maapi_start_trans_in_trans(int sock, enum confd_trans_mode rwmode,
                               int usid, int thandle)
{
    int useikp = 0;
    return intcall(sock, MAAPI_START_TRANS, -1,
                   erl_format("{trintr, ~i,~i,~i,~i}",
                              rwmode, usid, useikp, thandle));
}


int maapi_finish_trans(int sock, int tid)
{
    return intcall(sock, MAAPI_STOP_TRANS, tid, NULL);
}

int maapi_apply_trans(int sock, int tid, int keepopen)
{
    return maapi_apply_trans_flags(sock, tid, keepopen, 0);
}

int maapi_apply_trans_flags(int sock, int tid, int keepopen, int flags)
{
    ETERM *tup[2];
    tup[0] = keepopen ? erl_mk_atom("true") : erl_mk_atom("false");
    tup[1] = erl_mk_int(flags);
    return intcall(sock, MAAPI_APPLY_TRANS, tid, erl_mk_tuple(tup, 2));
}

int maapi_apply_trans_with_result(int sock, int thandle, int keepopen,
                                  int flags, const char *tag, int timeoutsecs,
                                  confd_tag_value_t **values, int *nvalues)
{
    int i, len;
    ETERM *tup[4], *req, *reply;
    int status, retval;
    confd_tag_value_t *tv;

    tup[0] = keepopen ? erl_mk_atom("true") : erl_mk_atom("false");
    tup[1] = erl_mk_int(flags);
    if (tag != NULL)
        tup[2] = erl_mk_binary(tag, strlen(tag));
    else
        tup[2] = erl_mk_binary("", 0);
    tup[3] = erl_mk_int(timeoutsecs);
    req = erl_mk_tuple(tup, 4);

    reply = op_request_term(sock, MAAPI_APPLY_TRANS_WITH_RESULT,
                            thandle, 0, req, &status);
    erl_free_compound(req);
    if (status < 0) {
        return CONFD_ERR;
    }
    if (reply == NULL) {
        *values = NULL;
        *nvalues = 0;
        return status;
    }
    len = erl_length(reply);
    if ((tv = confd_malloc(len * sizeof(confd_tag_value_t))) == NULL) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    retval = etermlist_to_tag_vals(reply, tv, len);
    if (retval != len) {
        erl_free_compound(reply);
        free(tv);
        if (retval != CONFD_ERR)
            confd_internal_error("Internal error, tag value list too long\n");
        return CONFD_ERR;
    }
    for (i = 0; i < len; i++) {
        if (confd_dup_value(CONFD_GET_TAG_VALUE(&tv[i])) == CONFD_ERR) {
            erl_free_compound(reply);
            free(tv);
            return CONFD_ERR;
        }
    }
    erl_free_compound(reply);
    *values = tv;
    *nvalues = len;
    return CONFD_OK;
}

/* deprecated */
int maapi_commit_queue_result(int sock, int thandle, int timeoutsecs,
                              struct ncs_commit_queue_result *result)
{
    int status;
    ETERM *req, *reply, *q;

    req = erl_mk_int(timeoutsecs);

    reply = op_request_term(sock, MAAPI_COMMIT_QUEUE_RESULT,
                            thandle, 0, req, &status);
    erl_free_compound(req);
    if (status < 0) {
        return CONFD_ERR;
    }
    if (ERL_TUPLE_SIZE(reply) != 2) {
        ret_err(CONFD_ERR_INTERNAL, "internal protocol error (sz=%d)",
                ERL_TUPLE_SIZE(reply));
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    q = ERL_TUPLE_ELEMENT(reply, 0);
    if (ERL_IS_UNSIGNED_LONGLONG(q)) {
        result->queue_id = ERL_LL_UVALUE(q);
    } else if (ERL_IS_LONGLONG(q)) {
        result->queue_id = ERL_LL_VALUE(q);
    } else {
        result->queue_id = ERL_INT_UVALUE(q);
    }
    result->status = TINT(reply, 1);
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_validate_trans(int sock, int tid, int unlock, int forcevalidation)
{
    ETERM *tup[2];
    tup[0] = unlock ? erl_mk_atom("true") : erl_mk_atom("false");
    tup[1] = forcevalidation ? erl_mk_atom("true") : erl_mk_atom("false");
    return intcall(sock, MAAPI_VALIDATE_TRANS, tid, erl_mk_tuple(tup, 2));
}
int maapi_prepare_trans(int sock, int tid)
{
    return maapi_prepare_trans_flags(sock, tid, 0);
}
int maapi_prepare_trans_flags(int sock, int tid, int flags)
{
    return intcall(sock, MAAPI_PREPARE_TRANS, tid, erl_mk_int(flags));
}
int maapi_commit_trans(int sock, int tid)
{
    return intcall(sock, MAAPI_COMMIT_TRANS, tid, NULL);
}
int maapi_abort_trans(int sock, int tid)
{
    return intcall(sock, MAAPI_ABORT_TRANS, tid, NULL);
}

int maapi_set_flags(int sock, int thandle, int flags)
{
    return intcall(sock, MAAPI_SET_FLAGS, thandle, erl_mk_int(flags));
}

int maapi_set_delayed_when(int sock, int thandle, int on)
{
    ETERM *request, *reply;
    int status;

    request = erl_mk_int(on);
    reply = op_request_term(sock, MAAPI_SET_DELAYED_WHEN,
                            thandle, 0, request, &status);
    erl_free_compound(request);
    if (status < 0)
        return status;
    status = ERL_INT_VALUE(reply);
    erl_free_compound(reply);
    return status;
}

int maapi_set_label(int sock, int thandle, const char *label)
{
    return intcall(sock, MAAPI_SET_LABEL, thandle,
                   erl_mk_binary(label, strlen(label)));
}

int maapi_set_comment(int sock, int thandle, const char *comment)
{
    return intcall(sock, MAAPI_SET_COMMENT, thandle,
                   erl_mk_binary(comment, strlen(comment)));
}

int maapi_set_namespace(int sock, int thandle, int hashed_ns)
{
    return intcall(sock, MAAPI_SET_NAMESPACE, thandle, erl_mk_int(hashed_ns));
}

static int vmaapi_set(int sock, int thandle, int op, ETERM *arg,
                      const char *fmt, va_list args)
{
    int status, isrel;
    ETERM *req;
    ETERM *tup[2];
    ETERM *epath = parse_path(&isrel, fmt, args);

    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    tup[0] = arg;
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);
    op_request_term(sock, op, thandle, isrel, req, &status);
    erl_free_compound(req);
    return status;
}

int maapi_copy(int sock, int from_thandle, int to_thandle)
{
    return intcall(sock, MAAPI_COPY, from_thandle, erl_mk_int(to_thandle));
}

int maapi_copy_path(int sock, int from_thandle, int to_thandle,
                    const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vcopy_path(sock, from_thandle, to_thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vcopy_path(int sock, int from_thandle, int to_thandle,
                     const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *arg, *argt[2];
    ETERM *epath;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    }
    argt[1] = epath;
    argt[0] = erl_mk_int(to_thandle);
    arg = erl_mk_tuple(argt, 2);
    op_request_term(sock, MAAPI_COPY_PATH, from_thandle, isrel, arg, &status);
    erl_free_compound(arg);
    return status;
}


int maapi_exists(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = request_int(sock, MAAPI_EXISTS, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vexists(int sock, int thandle, const char *fmt, va_list args)
{
    return request_int(sock, MAAPI_EXISTS, thandle, fmt, args);
}

int maapi_num_instances(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = request_int(sock, MAAPI_NUM_INSTANCES, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vnum_instances(int sock, int thandle, const char *fmt, va_list args)
{
    return request_int(sock, MAAPI_NUM_INSTANCES, thandle, fmt, args);
}

int maapi_create(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, MAAPI_CREATE, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vcreate(int sock, int thandle, const char *fmt, va_list args)
{
    return fmt_request(sock, MAAPI_CREATE, thandle, fmt, args);
}

int maapi_shared_create(int sock, int thandle, int flags, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = maapi_vshared_create(sock, thandle, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_create(int sock, int thandle, int flags,
                        const char *fmt, va_list args)
{
    ETERM *arg;

    clr_confd_err();
    arg = (flags & MAAPI_SHARED_NO_BACKPOINTER) ?
        erl_mk_atom("false") : erl_mk_atom("true");
    if (arg == NULL)
        return ret_err(CONFD_ERR_MALLOC, "failed to allocate memory");
    return vmaapi_set(sock, thandle, MAAPI_NCS_SHARED_CREATE, arg, fmt, args);
}

int maapi_delete(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, MAAPI_DELETE, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vdelete(int sock, int thandle, const char *fmt, va_list args)
{
    return fmt_request(sock, MAAPI_DELETE, thandle, fmt, args);
}


static int copy_tree(int sock, int thandle, int use_shared, int flags,
                     const char *from, const char *tofmt, va_list args)
{
    int isrel, status;
    ETERM *arg;
    confd_value_t v;
    ETERM *tup[4];

    clr_confd_err();
    tup[0] = use_shared ? erl_mk_atom("true") : erl_mk_atom("false");
    tup[1] = (flags & MAAPI_SHARED_NO_BACKPOINTER) ?
        erl_mk_atom("false") : erl_mk_atom("true");
    if ((tup[2] = parse_path(&isrel, from, args)) == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad source path <%s>", from);
    }
    if (isrel == 1) {
        return ret_err(CONFD_ERR_BADPATH, "Source path must be absolute");
    }
    if ((tup[3] = parse_path(&isrel, tofmt, args)) == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad destination path <%s>", tofmt);
    }
    arg = erl_mk_tuple(tup, 4);
    arg_request(sock, MAAPI_COPY_TREE, thandle, &status, isrel, &v, arg);
    return status;
}

int maapi_copy_tree(int sock, int thandle,
                    const char *from, const char *tofmt, ...)
{
    int ret;
    va_list args;

    va_start(args,tofmt);
    ret = copy_tree(sock, thandle, 0, 0, from, tofmt, args);
    va_end(args);
    return ret;
}

int maapi_vcopy_tree(int sock, int thandle,
                     const char *from, const char *tofmt, va_list args)
{
    return copy_tree(sock, thandle, 0, 0, from, tofmt, args);
}

int maapi_shared_copy_tree(int sock, int thandle, int flags,
                           const char *from, const char *tofmt, ...)
{
    int ret;
    va_list args;

    va_start(args,tofmt);
    ret = copy_tree(sock, thandle, 1, flags, from, tofmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_copy_tree(int sock, int thandle, int flags,
                            const char *from, const char *tofmt, va_list args)
{
    return copy_tree(sock, thandle, 1, flags, from, tofmt, args);
}


int maapi_insert(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, MAAPI_INSERT, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vinsert(int sock, int thandle, const char *fmt, va_list args)
{
    return fmt_request(sock, MAAPI_INSERT, thandle, fmt, args);
}

int maapi_shared_insert(int sock, int thandle, int flags, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = maapi_vshared_insert(sock, thandle, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_insert(int sock, int thandle, int flags,
                         const char *fmt, va_list args)
{
    ETERM *tup[2];

    tup[0] = erl_mk_atom("true");
    tup[1] = (flags & MAAPI_SHARED_NO_BACKPOINTER) ?
        erl_mk_atom("false") : erl_mk_atom("true");
    return vmaapi_set(sock, thandle, MAAPI_INSERT, erl_mk_tuple(tup, 2),
                      fmt, args);
}

int maapi_move(int sock, int thandle, confd_value_t* tokey, int n,
               const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vmove(sock, thandle, tokey, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vmove(int sock, int thandle, confd_value_t* tokey, int n,
                const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *arg, *argt[2];
    ETERM *epath;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    }
    argt[0] = epath;
    /* Note the 1 which is means return tuple */
    if ((argt[1] = vals_to_termlist(tokey, n, 1)) == NULL) {
        erl_free_compound(epath);
        return CONFD_ERR;
    }
    arg = erl_mk_tuple(argt, 2);
    op_request_term(sock, MAAPI_MOVE, thandle, isrel, arg, &status);
    erl_free_compound(arg);
    return status;
}

int maapi_move_ordered(int sock, int thandle,
                       enum maapi_move_where where,
                       confd_value_t* tokey, int n,
                       const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vmove_ordered(sock, thandle, where, tokey, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vmove_ordered(int sock, int thandle,
                        enum maapi_move_where where,
                        confd_value_t* tokey, int n,
                        const char *fmt, va_list args)
{
    int isrel, status;
    ETERM *arg, *argt[2], *totup[2];
    ETERM *epath;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    }
    argt[0] = epath;
    switch (where) {
    case MAAPI_MOVE_FIRST:
        argt[1] = erl_mk_atom("first");
        break;
    case MAAPI_MOVE_LAST:
        argt[1] = erl_mk_atom("last");
        break;
    case MAAPI_MOVE_BEFORE:
    case MAAPI_MOVE_AFTER:
        /* Note the 1 which is means return tuple */
        if ((totup[1] = vals_to_termlist(tokey, n, 1)) == NULL) {
            erl_free_compound(epath);
            return CONFD_ERR;
        }
        totup[0] = erl_mk_atom(where == MAAPI_MOVE_BEFORE ? "before" : "after");
        argt[1] = erl_mk_tuple(totup, 2);
        break;
    default:
        erl_free_compound(epath);
        return ret_err(CONFD_ERR_PROTOUSAGE, "Bad 'where' %d", where);
    }
    arg = erl_mk_tuple(argt, 2);
    op_request_term(sock, MAAPI_MOVE_ORDERED, thandle, isrel, arg, &status);
    erl_free_compound(arg);
    return status;
}


/* deprecated */
int maapi_bulk_get_elem(int sock, int thandle, confd_value_t *v,
                        const char *fmt, ...)
{
    int status;
    va_list args;
    va_start(args,fmt);

    request_v(sock, MAAPI_GET_BULK_ELEM, thandle, &status, v, fmt, args);
    va_end(args);
    return status;
}


int maapi_get_elem(int sock, int thandle, confd_value_t *v,
                   const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args,fmt);
    ret = maapi_vget_elem(sock, thandle, v, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_elem(int sock, int thandle, confd_value_t *v,
                    const char *fmt, va_list args)
{
    int status;

    request_v(sock, MAAPI_GET_ELEM, thandle, &status, v, fmt, args);
    return status;
}

/* unsupported */
int maapi_get_elem_no_defaults(int sock, int thandle, confd_value_t *v,
                               const char *fmt, ...)
{
    int status;
    va_list args;
    va_start(args,fmt);

    request_v(sock, MAAPI_GET_ELEM_NO_DEFAULT, thandle, &status, v, fmt, args);
    va_end(args);
    return status;
}


int maapi_set_elem(int sock, int thandle, confd_value_t *v,
                    const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vset_elem(sock, thandle, v, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vset_elem(int sock, int thandle, confd_value_t *v,
                    const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = val_to_term(v)) == NULL)
        return CONFD_ERR;
    return vmaapi_set(sock, thandle, MAAPI_SET_ELEM, arg, fmt, args);
}

int maapi_shared_set_elem(int sock, int thandle, confd_value_t *v, int flags,
                          const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vshared_set_elem(sock, thandle, v, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_set_elem(int sock, int thandle, confd_value_t *v, int flags,
                    const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = val_to_term(v)) == NULL)
        return CONFD_ERR;
    return vmaapi_set(sock, thandle, MAAPI_SHARED_SET_ELEM, arg, fmt, args);
}

int maapi_set_elem2(int sock, int thandle, const char *strval,
                    const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vset_elem2(sock, thandle, strval, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vset_elem2(int sock, int thandle, const char *strval,
                     const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = erl_mk_binary(strval, strlen(strval))) == NULL)
        return ret_err(CONFD_ERR_MALLOC,"Cannot allocate");
    return vmaapi_set(sock, thandle, MAAPI_SET_ELEM2, arg, fmt, args);
}

int maapi_shared_set_elem2(int sock, int thandle, const char *strval,
                           int flags, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vshared_set_elem2(sock, thandle, strval, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_set_elem2(int sock, int thandle, const char *strval,
                            int flags, const char *fmt, va_list args)
{
    ETERM *arg;

    if ((arg = erl_mk_binary(strval, strlen(strval))) == NULL)
        return ret_err(CONFD_ERR_MALLOC,"Cannot allocate");
    return vmaapi_set(sock, thandle, MAAPI_SHARED_SET_ELEM2, arg, fmt, args);
}


int maapi_cd(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, MAAPI_CD, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vcd(int sock, int thandle, const char *fmt, va_list args)
{
    return fmt_request(sock, MAAPI_CD, thandle, fmt, args);
}


int maapi_pushd(int sock, int thandle, const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args,fmt);

    ret = fmt_request(sock, MAAPI_PUSHD, thandle, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vpushd(int sock, int thandle, const char *fmt, va_list args)
{
    return fmt_request(sock, MAAPI_PUSHD, thandle, fmt, args);
}


int maapi_popd(int sock, int thandle)
{
    return intcall(sock, MAAPI_POPD, thandle, NULL);
}


int maapi_getcwd(int sock, int thandle, size_t strsz, char *curdir)
{
    ETERM *reply;
    int status;

    reply = op_request_term(sock, MAAPI_GETCWD, thandle, 0, NULL, &status);
    if (status < 0)
        return status;
    bin_copy(curdir, strsz, reply);
    erl_free_compound(reply);
    return CONFD_OK;
}


int maapi_getcwd_kpath(int sock, int thandle, confd_hkeypath_t **kp)
{
    ETERM *request, *reply;
    int status;
    confd_hkeypath_t kp0, *kp1;

    request = erl_mk_atom("kp");
    reply = op_request_term(sock, MAAPI_GETCWD, thandle, 0, request, &status);
    erl_free_compound(request);
    if (status < 0)
        return status;
    if (populate_keypath(reply, &kp0) &&
        (kp1 = confd_hkeypath_dup(&kp0)) != NULL) {
        *kp = kp1;
    } else {
        status = CONFD_ERR;
    }
    confd_free_eterm_keypath(&kp0);
    erl_free_compound(reply);
    return status;
}


int maapi_init_cursor(int sock, int thandle, struct maapi_cursor *mc,
                      const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vinit_cursor(sock, thandle, mc, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vinit_cursor(int sock, int thandle, struct maapi_cursor *mc,
                       const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath;
    epath = parse_path(&isrel, fmt, args);
    mc->n = -1;
    if (epath == NULL) {
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    }
    mc->prevterm = erl_mk_atom("first");
    mc->path = epath;
    mc->isrel = isrel;
    mc->sock = sock;
    mc->thandle = thandle;
    mc->n = -1;
    mc->cursor_id = cursor_id++;
    mc->hint_bulk = 0;
    mc->secondary_index = NULL;
    return CONFD_OK;
}



void maapi_destroy_cursor(struct maapi_cursor *mc)
{
    int i;

    for(i=0; i < mc->n; i++) {
        confd_free_eterm_val(&mc->keys[i]);
    }
    if (mc->prevterm) {
        erl_free_compound(mc->prevterm);
        mc->prevterm = NULL;
    }
    if (mc->path) {
        erl_free_compound(mc->path);
        mc->path = NULL;
    }
    mc->n = 0;
}



int maapi_get_next(struct maapi_cursor *mc)
{
    int i;
    ETERM *result, *keys;
    int status;
    ETERM *req, *cid, *hint, *index;
    ETERM *tup[5];

    if (mc->n == 0 || mc->prevterm == NULL || mc->path == NULL)
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Invalid cursor");

    cid = erl_mk_int(mc->cursor_id);
    hint = erl_mk_int(mc->hint_bulk);
    if (mc->secondary_index != NULL)
        index = erl_mk_atom(mc->secondary_index);
    else
        index = erl_mk_atom("");

    tup[0] = mc->prevterm;
    tup[1] = mc->path;
    tup[2] = cid;
    tup[3] = hint;
    tup[4] = index;
    req = erl_mk_tuple(tup, 5);
    result = op_request_term(mc->sock, MAAPI_GET_NEXT, mc->thandle, mc->isrel,
                             req, &status);
    erl_free_term(cid);
    erl_free_term(hint);
    erl_free_term(index);
    erl_free_term(req);

    if (result == NULL) {
        maapi_destroy_cursor(mc);
        return status;
    }
    if (ERL_IS_ATOM(result)) {  /* this is atom false */
        erl_free_compound(result);
        maapi_destroy_cursor(mc);
        return CONFD_OK;
    }
    for(i=0; i < mc->n; i++) {
       confd_free_eterm_val(&mc->keys[i]);
    }
    erl_free_compound(mc->prevterm);
    mc->prevterm = result;
    keys = TE(result,1);
    mc->n = ERL_TUPLE_SIZE(keys);
    for(i=0; i < mc->n; i++) {
        if (eterm_to_val(TE(keys,i), &mc->keys[i]) == NULL)
            return CONFD_ERR;
    }
    return CONFD_OK;
}

int maapi_find_next(struct maapi_cursor *mc,
                    enum confd_find_next_type type,
                    confd_value_t *inkeys, int n_inkeys)
{
   ETERM *ekeys;
   int retval;

   clr_confd_err();
   if (type != CONFD_FIND_NEXT && type != CONFD_FIND_SAME_OR_NEXT)
      return ret_err(CONFD_ERR_PROTOUSAGE, "Invalid find_next type");
   if ((ekeys = vals_to_termlist(inkeys, n_inkeys, 1)) != NULL) {
      if (mc->n != 0 && mc->prevterm != NULL && mc->path != NULL) {
         int status;
         ETERM *result,*req,*tup[6];

         tup[0] = ekeys;
         tup[1] = mc->path;
         tup[2] = erl_mk_int(mc->cursor_id);
         tup[3] = erl_mk_int(type);
         tup[4] = erl_mk_int(mc->hint_bulk);
         tup[5] = erl_mk_atom(mc->secondary_index ? mc->secondary_index : "");
         req = erl_mk_tuple(tup, sizeof(tup)/sizeof(tup[0]));

         result = op_request_term(mc->sock, MAAPI_FIND_NEXT,
                                  mc->thandle, mc->isrel,req, &status);

         erl_free_term(req);
         erl_free_term(tup[2]);
         erl_free_term(tup[3]);
         erl_free_term(tup[4]);
         erl_free_term(tup[5]);

         if (NULL == result) {
            maapi_destroy_cursor(mc);
            retval = status;
         }
         else if (ERL_IS_ATOM(result)) {  /* this is atom false */
            erl_free_compound(result);
            maapi_destroy_cursor(mc);
            retval = CONFD_OK;
         }
         else {
            int i;
            ETERM *keys;

            if (mc->prevterm != NULL) {
               erl_free_term(mc->prevterm);
            }
            mc->prevterm = result;
            keys = TE(result,1);
            mc->n = ERL_TUPLE_SIZE(keys);
            for (i = 0, retval = CONFD_OK;
                 retval == CONFD_OK && i < mc->n; i++)
            {
                retval =
                    eterm_to_val(TE(keys,i),
                                 &mc->keys[i]) != NULL ? CONFD_OK : CONFD_ERR;
            }
         }
      }
      else {
         retval = ret_err(CONFD_ERR_PROTOUSAGE, "Invalid cursor");
      }
      erl_free_compound(ekeys);
   }
   else {
      retval = CONFD_ERR;
   }
   return retval;
}


#define check_type(X, _type) { \
    if (v.type == _type) { \
        *rval = X(&v); \
        return CONFD_OK; }\
    else { \
        confd_set_errno(CONFD_ERR_BADTYPE); \
        confd_set_lasterr("Returned type is not " #_type); \
        confd_report_err(CONFD_DEBUG, \
             "Type error, returned type is not " #_type);\
        return CONFD_ERR; }}

#define mget(X, _type) {  \
    confd_value_t v; \
    int ret; \
    va_list args; \
    va_start(args,fmt); \
    if ((ret = maapi_vget_elem(sock, th, &v, fmt, args)) != CONFD_OK) \
        {va_end(args); return ret;} \
    va_end(args); \
    check_type(X, _type)}

#define vmget(X, _type) {  \
    confd_value_t v; \
    int ret; \
    if ((ret = maapi_vget_elem(sock, th, &v, fmt, args)) != CONFD_OK) \
        {return ret;} \
    check_type(X, _type)}


int maapi_get_int8_elem(int sock, int th, int8_t *rval, const char *fmt, ...)
{ mget(CONFD_GET_INT8, C_INT8) }

int maapi_vget_int8_elem(int sock, int th, int8_t *rval,
                         const char *fmt, va_list args)
{ vmget(CONFD_GET_INT8, C_INT8) }

int maapi_get_int16_elem(int sock, int th, int16_t *rval, const char *fmt, ...)
{ mget(CONFD_GET_INT16, C_INT16) }

int maapi_vget_int16_elem(int sock, int th, int16_t *rval
                          , const char *fmt, va_list args)
{ vmget(CONFD_GET_INT16, C_INT16) }

int maapi_get_int32_elem(int sock, int th, int32_t *rval, const char *fmt, ...)
{ mget(CONFD_GET_INT32, C_INT32) }

int maapi_vget_int32_elem(int sock, int th, int32_t *rval,
                          const char *fmt, va_list args)
{ vmget(CONFD_GET_INT32, C_INT32) }

int maapi_get_int64_elem(int sock, int th, int64_t *rval, const char *fmt, ...)
{ mget(CONFD_GET_INT64, C_INT64) }

int maapi_vget_int64_elem(int sock, int th, int64_t *rval,
                          const char *fmt, va_list args)
{ vmget(CONFD_GET_INT64, C_INT64) }

int maapi_get_u_int8_elem(int sock, int th, u_int8_t *rval,
                          const char *fmt, ...)
{ mget(CONFD_GET_UINT8, C_UINT8) }

int maapi_vget_u_int8_elem(int sock, int th, u_int8_t *rval,
                           const char *fmt, va_list args)
{ vmget(CONFD_GET_UINT8, C_UINT8) }

int maapi_get_u_int16_elem(int sock, int th, u_int16_t *rval,
                           const char *fmt, ...)
{ mget(CONFD_GET_UINT16, C_UINT16) }

int maapi_vget_u_int16_elem(int sock, int th, u_int16_t *rval,
                            const char *fmt, va_list args)
{ vmget(CONFD_GET_UINT16, C_UINT16) }

int maapi_get_u_int32_elem(int sock, int th, u_int32_t *rval,
                           const char *fmt, ...)
{ mget(CONFD_GET_UINT32, C_UINT32) }

int maapi_vget_u_int32_elem(int sock, int th, u_int32_t *rval,
                            const char *fmt, va_list args)
{ vmget(CONFD_GET_UINT32, C_UINT32) }

int maapi_get_u_int64_elem(int sock, int th, u_int64_t *rval,
                           const char *fmt, ...)
{ mget(CONFD_GET_UINT64, C_UINT64) }

int maapi_vget_u_int64_elem(int sock, int th, u_int64_t *rval,
                            const char *fmt, va_list args)
{ vmget(CONFD_GET_UINT64, C_UINT64) }

int maapi_get_ipv4_elem(int sock, int th, struct in_addr *rval,
                        const char *fmt, ...)
{ mget(CONFD_GET_IPV4, C_IPV4) }

int maapi_vget_ipv4_elem(int sock, int th, struct in_addr *rval,
                         const char *fmt, va_list args)
{ vmget(CONFD_GET_IPV4, C_IPV4) }

int maapi_get_ipv6_elem(int sock, int th, struct in6_addr *rval,
                        const char *fmt, ...)
{ mget(CONFD_GET_IPV6, C_IPV6) }

int maapi_vget_ipv6_elem(int sock, int th, struct in6_addr *rval,
                         const char *fmt, va_list args)
{ vmget(CONFD_GET_IPV6, C_IPV6) }

int maapi_get_double_elem(int sock, int th, double *rval, const char *fmt, ...)
{ mget(CONFD_GET_DOUBLE, C_DOUBLE) }

int maapi_vget_double_elem(int sock, int th, double *rval,
                           const char *fmt, va_list args)
{ vmget(CONFD_GET_DOUBLE, C_DOUBLE) }

int maapi_get_bool_elem(int sock, int th, int *rval, const char *fmt, ...)
{ mget(CONFD_GET_BOOL, C_BOOL) }

int maapi_vget_bool_elem(int sock, int th, int *rval,
                         const char *fmt, va_list args)
{ vmget(CONFD_GET_BOOL, C_BOOL) }

int maapi_get_datetime_elem(int sock, int th, struct confd_datetime *rval,
                            const char *fmt, ...)
{ mget(CONFD_GET_DATETIME, C_DATETIME) }

int maapi_vget_datetime_elem(int sock, int th, struct confd_datetime *rval,
                             const char *fmt, va_list args)
{ vmget(CONFD_GET_DATETIME, C_DATETIME) }

int maapi_get_date_elem(int sock, int th, struct confd_date *rval,
                        const char *fmt, ...)
{ mget(CONFD_GET_DATE, C_DATE) }

int maapi_vget_date_elem(int sock, int th, struct confd_date *rval,
                         const char *fmt, va_list args)
{ vmget(CONFD_GET_DATE, C_DATE) }

int maapi_get_time_elem(int sock, int th, struct confd_time *rval,
                        const char *fmt, ...)
{ mget(CONFD_GET_TIME, C_TIME) }

int maapi_vget_time_elem(int sock, int th, struct confd_time *rval,
                         const char *fmt, va_list args)
{ vmget(CONFD_GET_TIME, C_TIME) }

int maapi_get_duration_elem(int sock, int th, struct confd_duration *rval,
                            const char *fmt, ...)
{ mget(CONFD_GET_DURATION, C_DURATION) }

int maapi_vget_duration_elem(int sock, int th, struct confd_duration *rval,
                             const char *fmt, va_list args)
{ vmget(CONFD_GET_DURATION, C_DURATION) }

int maapi_get_enum_value_elem(int sock, int th, int32_t *rval,
                              const char *fmt, ...)
{ mget(CONFD_GET_ENUM_HASH, C_ENUM_HASH) }

int maapi_vget_enum_value_elem(int sock, int th, int32_t *rval,
                               const char *fmt, va_list args)
{ vmget(CONFD_GET_ENUM_HASH, C_ENUM_HASH) }

int maapi_get_bit32_elem(int sock, int th, u_int32_t *rval,
                         const char *fmt, ...)
{ mget(CONFD_GET_BIT32, C_BIT32) }

int maapi_vget_bit32_elem(int sock, int th, u_int32_t *rval,
                          const char *fmt, va_list args)
{ vmget(CONFD_GET_BIT32, C_BIT32) }

int maapi_get_bit64_elem(int sock, int th, u_int64_t *rval,
                         const char *fmt, ...)
{ mget(CONFD_GET_BIT64, C_BIT64) }

int maapi_vget_bit64_elem(int sock, int th, u_int64_t *rval,
                          const char *fmt, va_list args)
{ vmget(CONFD_GET_BIT64, C_BIT64) }

/* Return a pointer to a malloc()ed confd_hkeypath_t - up to the caller
 * to free (with confd_free_hkeypath()) when done with it */
int maapi_get_objectref_elem(int sock, int th, confd_hkeypath_t **rval,
                             const char *fmt, ...)
{ mget(CONFD_GET_OBJECTREF, C_OBJECTREF) }

int maapi_vget_objectref_elem(int sock, int th, confd_hkeypath_t **rval,
                              const char *fmt, va_list args)
{ vmget(CONFD_GET_OBJECTREF, C_OBJECTREF) }

/* Return a pointer to a malloc()ed confd_snmp_oid - up to the caller
 * to free buffer when done with it */
int maapi_get_oid_elem(int sock, int th, struct confd_snmp_oid **rval,
                       const char *fmt, ...)
{ mget(CONFD_GET_OID, C_OID) }

int maapi_vget_oid_elem(int sock, int th, struct confd_snmp_oid **rval,
                        const char *fmt, va_list args)
{ vmget(CONFD_GET_OID, C_OID) }

int maapi_get_ipv4prefix_elem(int sock, int th, struct confd_ipv4_prefix *rval,
                              const char *fmt, ...)
{ mget(CONFD_GET_IPV4PREFIX, C_IPV4PREFIX) }

int maapi_vget_ipv4prefix_elem(int sock, int th, struct confd_ipv4_prefix *rval,
                               const char *fmt, va_list args)
{ vmget(CONFD_GET_IPV4PREFIX, C_IPV4PREFIX) }

int maapi_get_ipv6prefix_elem(int sock, int th, struct confd_ipv6_prefix *rval,
                              const char *fmt, ...)
{ mget(CONFD_GET_IPV6PREFIX, C_IPV6PREFIX) }

int maapi_vget_ipv6prefix_elem(int sock, int th, struct confd_ipv6_prefix *rval,
                               const char *fmt, va_list args)
{ vmget(CONFD_GET_IPV6PREFIX, C_IPV6PREFIX) }

int maapi_get_decimal64_elem(int sock, int th, struct confd_decimal64 *rval,
                             const char *fmt, ...)
{ mget(CONFD_GET_DECIMAL64, C_DECIMAL64) }

int maapi_vget_decimal64_elem(int sock, int th, struct confd_decimal64 *rval,
                              const char *fmt, va_list args)
{ vmget(CONFD_GET_DECIMAL64, C_DECIMAL64) }

int maapi_get_identityref_elem(int sock, int th, struct confd_identityref *rval,
                               const char *fmt, ...)
{ mget(CONFD_GET_IDENTITYREF, C_IDENTITYREF) }

int maapi_vget_identityref_elem(int sock, int th,
                                struct confd_identityref *rval,
                                const char *fmt, va_list args)
{ vmget(CONFD_GET_IDENTITYREF, C_IDENTITYREF) }

int maapi_get_ipv4_and_plen_elem(int sock, int th,
                                 struct confd_ipv4_prefix *rval,
                                 const char *fmt, ...)
{ mget(CONFD_GET_IPV4_AND_PLEN, C_IPV4_AND_PLEN) }

int maapi_vget_ipv4_and_plen_elem(int sock, int th,
                                  struct confd_ipv4_prefix *rval,
                                  const char *fmt, va_list args)
{ vmget(CONFD_GET_IPV4_AND_PLEN, C_IPV4_AND_PLEN) }

int maapi_get_ipv6_and_plen_elem(int sock, int th,
                                 struct confd_ipv6_prefix *rval,
                                 const char *fmt, ...)
{ mget(CONFD_GET_IPV6_AND_PLEN, C_IPV6_AND_PLEN) }

int maapi_vget_ipv6_and_plen_elem(int sock, int th,
                                  struct confd_ipv6_prefix *rval,
                                  const char *fmt, va_list args)
{ vmget(CONFD_GET_IPV6_AND_PLEN, C_IPV6_AND_PLEN) }

int maapi_get_dquad_elem(int sock, int th, struct confd_dotted_quad *rval,
                         const char *fmt, ...)
{ mget(CONFD_GET_DQUAD, C_DQUAD) }

int maapi_vget_dquad_elem(int sock, int th, struct confd_dotted_quad *rval,
                          const char *fmt, va_list args)
{ vmget(CONFD_GET_DQUAD, C_DQUAD) }


#define check_buftype(XP, XS, _type) {                  \
    if (v.type == _type) { \
        *rval = XP(&v); \
        *bufsiz = XS(&v); \
        return CONFD_OK; }\
    else { \
        confd_set_errno(CONFD_ERR_BADTYPE); \
        confd_set_lasterr("Returned type is not " #_type); \
        confd_report_err(CONFD_DEBUG, \
             "Type error, returned type is not " #_type);\
        return CONFD_ERR; }}

#define mget_buf(XP, XS, _type) {                       \
    confd_value_t v; \
    int ret; \
    va_list args; \
    va_start(args, fmt); \
    if ((ret = maapi_vget_elem(sock, th, &v, fmt, args)) != CONFD_OK) \
        {va_end(args); return ret;} \
    va_end(args); \
    check_buftype(XP, XS, _type)}

#define vmget_buf(XP, XS, _type) {                      \
    confd_value_t v; \
    int ret; \
    if ((ret = maapi_vget_elem(sock, th, &v, fmt, args)) != CONFD_OK) \
        {return ret;} \
    check_buftype(XP, XS, _type)}

/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int maapi_get_buf_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                       const char *fmt, ...)
{ mget_buf(CONFD_GET_BUFPTR, CONFD_GET_BUFSIZE, C_BUF) }
int maapi_vget_buf_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                        const char *fmt, va_list args)
{ vmget_buf(CONFD_GET_BUFPTR, CONFD_GET_BUFSIZE, C_BUF) }


/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int maapi_get_binary_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                          const char *fmt, ...)
{ mget_buf(CONFD_GET_BINARY_PTR, CONFD_GET_BINARY_SIZE, C_BINARY) }
int maapi_vget_binary_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                           const char *fmt, va_list args)
{ vmget_buf(CONFD_GET_BINARY_PTR, CONFD_GET_BINARY_SIZE, C_BINARY) }


/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int maapi_get_hexstr_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                          const char *fmt, ...)
{ mget_buf(CONFD_GET_HEXSTR_PTR, CONFD_GET_HEXSTR_SIZE, C_HEXSTR) }
int maapi_vget_hexstr_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                           const char *fmt, va_list args)
{ vmget_buf(CONFD_GET_HEXSTR_PTR, CONFD_GET_HEXSTR_SIZE, C_HEXSTR) }


/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int maapi_get_bitbig_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                          const char *fmt, ...)
{ mget_buf(CONFD_GET_BITBIG_PTR, CONFD_GET_BITBIG_SIZE, C_BITBIG) }
int maapi_vget_bitbig_elem(int sock, int th, unsigned char **rval, int *bufsiz,
                           const char *fmt, va_list args)
{ vmget_buf(CONFD_GET_BITBIG_PTR, CONFD_GET_BITBIG_SIZE, C_BITBIG) }


/* Return a pointer to a malloc()ed buffer and its size - up to the caller
 * to free buffer when done with it */
int maapi_get_list_elem(int sock, int th, confd_value_t **values, int *n,
                        const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vget_list_elem(sock, th, values, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_list_elem(int sock, int th, confd_value_t **values, int *n,
                        const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    ret = maapi_vget_elem(sock, th, &v, fmt, args);
    if (ret != CONFD_OK)
        return ret;
    if (v.type == C_LIST) {
        *values = CONFD_GET_LIST(&v);
        *n = CONFD_GET_LISTSIZE(&v);
        return CONFD_OK;
    }
    else {
        confd_set_errno(CONFD_ERR_BADTYPE);
        confd_set_lasterr("Returned type is not a list");
        confd_report_err(CONFD_DEBUG, "Type error, returned type is"
                    " not a list");
        return CONFD_ERR;
    }
}


/* If a buffer returned from maapi_get could fit into (n-1) bytes then
 * copy it into buf and terminate it with a nul character */
int maapi_get_str_elem(int sock, int th, char *buf, int n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vget_str_elem(sock, th, buf, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_str_elem(int sock, int th, char *buf, int n,
                        const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    ret = maapi_vget_elem(sock, th, &v, fmt, args);
    if (ret != CONFD_OK)
        return ret;
    if (v.type != C_BUF) {
        confd_set_errno(CONFD_ERR_BADTYPE);
        confd_set_lasterr("Returned type is not a string");
        confd_report_err(CONFD_DEBUG, "Type error, returned type is"
                    " not a string");
        return CONFD_ERR;
    }
    if (CONFD_GET_BUFSIZE(&v) >= n) {
        ret_err(CONFD_ERR_PROTOUSAGE,
                "buffer too small in maapi_get_str_elem() "
                "(returned buffer is %d bytes)", CONFD_GET_BUFSIZE(&v));
        free(CONFD_GET_BUFPTR(&v));
        return CONFD_ERR;
    }
    memcpy(buf, CONFD_GET_BUFPTR(&v), CONFD_GET_BUFSIZE(&v));
    buf[CONFD_GET_BUFSIZE(&v)] = 0;
    free(CONFD_GET_BUFPTR(&v));
    return CONFD_OK;
}


int maapi_get_qname_elem(int sock, int th,
                         unsigned char **prefix, int *prefixsz,
                         unsigned char **name, int *namesz,
                         const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args,fmt);
    ret = maapi_vget_qname_elem(sock, th, prefix, prefixsz,
                                name, namesz, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_qname_elem(int sock, int th,
                         unsigned char **prefix, int *prefixsz,
                         unsigned char **name, int *namesz,
                         const char *fmt, va_list args)
{
    confd_value_t v;
    int ret;

    ret = maapi_vget_elem(sock, th, &v, fmt, args);
    if (ret != CONFD_OK)
        return ret;
    *prefix = CONFD_GET_QNAME_PREFIX_PTR(&v);
    *name = CONFD_GET_QNAME_NAME_PTR(&v);
    *prefixsz = CONFD_GET_QNAME_PREFIX_SIZE(&v);
    *namesz = CONFD_GET_QNAME_NAME_SIZE(&v);
    return CONFD_OK;
}


static int get_object(ETERM *list, confd_value_t *values, int n)
{
    int len, i;

    len = etermlist_to_vals(list, values, n);
    if (len == CONFD_ERR)
        return CONFD_ERR;
    if (n > len)
        n = len;
    for (i = 0; i < n; i++) {
        if (confd_dup_value(&values[i]) != CONFD_OK)
            return CONFD_ERR;
    }
    return len;
}

int maapi_get_object(int sock, int thandle, confd_value_t *values,
                     int n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vget_object(sock, thandle, values, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_object(int sock, int thandle, confd_value_t *values,
                      int n, const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath, *result;
    int status;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    result = op_request_term(sock, MAAPI_GET_OBJECT,
                             thandle, isrel, epath, &status);
    erl_free_compound(epath);
    if (result == NULL)
        return status;
    status = get_object(result, values, n);
    erl_free_compound(result);
    return status;
}

int maapi_get_objects(struct maapi_cursor *mc, confd_value_t *values,
                      int n, int *nobj)
{
    int i;
    ETERM *result, *keys;
    int status, ret;
    ETERM *req, *cid, *index, *num;
    ETERM *tup[5];
    ETERM *next, *list;
    int got_obj;

    if (mc->n == 0 || mc->prevterm == NULL || mc->path == NULL)
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Invalid cursor");

    cid = erl_mk_int(mc->cursor_id);
    if (mc->secondary_index != NULL)
        index = erl_mk_atom(mc->secondary_index);
    else
        index = erl_mk_atom("");
    num = erl_mk_int(*nobj);

    tup[0] = mc->prevterm;
    tup[1] = mc->path;
    tup[2] = cid;
    tup[3] = index;
    tup[4] = num;
    req = erl_mk_tuple(tup, 5);
    result = op_request_term(mc->sock, MAAPI_GET_OBJECTS, mc->thandle,
                             mc->isrel, req, &status);
    erl_free_term(cid);
    erl_free_term(index);
    erl_free_term(num);
    erl_free_term(req);

    if (result == NULL) {
        maapi_destroy_cursor(mc);
        return status;
    }
    next = TE(result, 0);
    list = TE(result, 1);

    for (i = 0, status = 0;
         i < *nobj && status != CONFD_ERR && !ERL_IS_NIL(list);
         i++) {
        if (!ERL_IS_CONS(list))
            return confd_internal_error("Internal error, bad object list\n");
        ret = get_object(ERL_CONS_HEAD(list), &values[i*n], n);
        if (ret == CONFD_ERR || ret > status)
            status = ret;
        list = ERL_CONS_TAIL(list);
    }
    if (status == CONFD_ERR) {
        erl_free_compound(result);
        return CONFD_ERR;
    }
    got_obj = i;

    if (ERL_IS_ATOM(next)) {  /* this is atom false */
        erl_free_compound(result);
        maapi_destroy_cursor(mc);
    } else {
        TE(result, 0) = NULL;       /* Ouch - we need to keep the 'next' */
        erl_free_compound(result);
        for(i=0; i < mc->n; i++) {
            confd_free_eterm_val(&mc->keys[i]);
        }
        erl_free_compound(mc->prevterm);
        mc->prevterm = next;
        keys = TE(next,1);
        mc->n = ERL_TUPLE_SIZE(keys);
        for(i=0; i < mc->n; i++) {
            if (eterm_to_val(TE(keys,i), &mc->keys[i]) == NULL)
                return CONFD_ERR;
        }
    }
    *nobj = got_obj;
    return status;
}

/* duplicate from cdb.c... */
static int set_value(void *valp, confd_value_t *v)
{
    switch (v->type) {
    case C_STR:
        *(char **)valp = v->val.s; break;
    case C_BUF:
    case C_BINARY:
    case C_HEXSTR:
    case C_BITBIG:
        *(confd_buf_t *)valp = v->val.buf; break;
    case C_DOUBLE:
        *(double *)valp = v->val.d; break;
    case C_IPV4:
        *(struct in_addr *)valp = v->val.ip; break;
    case C_IPV6:
        *(struct in6_addr *)valp = v->val.ip6; break;
    case C_INT8:
        *(int8_t *)valp = v->val.i8; break;
    case C_INT16:
        *(int16_t *)valp = v->val.i16; break;
    case C_INT32:
        *(int32_t *)valp = v->val.i32; break;
    case C_INT64:
        *(int64_t *)valp = v->val.i64; break;
    case C_UINT8:
        *(u_int8_t *)valp = v->val.u8; break;
    case C_UINT16:
        *(u_int16_t *)valp = v->val.u16; break;
    case C_UINT32:
        *(u_int32_t *)valp = v->val.u32; break;
    case C_UINT64:
        *(u_int64_t *)valp = v->val.u64; break;
    case C_BOOL:
        *(int *)valp = v->val.boolean; break;
    case C_QNAME:
        *(struct confd_qname *)valp = v->val.qname; break;
    case C_DATETIME:
        *(struct confd_datetime *)valp = v->val.datetime; break;
    case C_DATE:
        *(struct confd_date *)valp = v->val.date; break;
    case C_TIME:
        *(struct confd_time *)valp = v->val.time; break;
    case C_DURATION:
        *(struct confd_duration *)valp = v->val.duration; break;
    case C_ENUM_HASH:
        *(int32_t *)valp = v->val.enumhash; break;
    case C_BIT32:
        *(u_int32_t *)valp = v->val.b32; break;
    case C_BIT64:
        *(u_int64_t *)valp = v->val.b64; break;
    case C_LIST:
        *(struct confd_list *)valp = v->val.list; break;
    case C_XMLTAG:
    case C_XMLBEGIN:
    case C_XMLBEGINDEL:
    case C_XMLEND:
        *(struct xml_tag *)valp = v->val.xmltag; break;
    case C_OBJECTREF:
        *(struct confd_hkeypath **)valp = v->val.hkp; break;
    case C_OID:
        *(struct confd_snmp_oid **)valp = v->val.oidp; break;
    case C_IPV4PREFIX:
        *(struct confd_ipv4_prefix *)valp = v->val.ipv4prefix; break;
    case C_IPV6PREFIX:
        *(struct confd_ipv6_prefix *)valp = v->val.ipv6prefix; break;
    case C_DECIMAL64:
        *(struct confd_decimal64 *)valp = v->val.d64; break;
    case C_IDENTITYREF:
        *(struct confd_identityref *)valp = v->val.idref; break;
    case C_IPV4_AND_PLEN:
        *(struct confd_ipv4_prefix *)valp = v->val.ipv4prefix; break;
    case C_IPV6_AND_PLEN:
        *(struct confd_ipv6_prefix *)valp = v->val.ipv6prefix; break;
    case C_DQUAD:
        *(struct confd_dotted_quad *)valp = v->val.dquad; break;
    case C_DEFAULT:
        break;
    case C_SYMBOL:
    case C_UNION:
    case C_PTR:
    case C_NOEXISTS:
    case C_CDBBEGIN:
    case C_MAXTYPE:
        /* These are all "can't happen" */
        return 0;
    }
    return 1;
}


int maapi_get_values(int sock, int thandle, confd_tag_value_t *values, int n,
                     const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vget_values(sock, thandle, values, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_values(int sock, int thandle, confd_tag_value_t *values, int n,
                      const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath;
    ETERM *tup[2];
    ETERM *req, *result;
    ETERM *list;
    int status, i;
    confd_value_t *want_vp;
    confd_tag_value_t tv;
    confd_value_t *got_vp = CONFD_GET_TAG_VALUE(&tv);

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    if ((tup[0] = tag_vals_to_termlist(values, n, 0)) == NULL) {
        erl_free_compound(epath);
        return CONFD_ERR;
    }
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);
    result = op_request_term(sock, MAAPI_GET_VALUES,
                             thandle, isrel, req, &status);
    erl_free_compound(req);
    if (result == NULL)
        return status;
    /* Can't use etermlist_to_tag_vals() here */
    list = result;
    for (i = 0; i < n; i++) {
        if (!ERL_IS_CONS(list)) {
            erl_free_compound(result);
            return confd_internal_error(
                "Internal error, bad tag value list\n");
        }
        want_vp = CONFD_GET_TAG_VALUE(&values[i]);
        if (want_vp->type == C_NOEXISTS || want_vp->type == C_PTR ||
            want_vp->type == C_XMLBEGIN || want_vp->type == C_XMLEND) {
            if (eterm_to_tag_val(ERL_CONS_HEAD(list), &tv, 0) == NULL ||
                confd_dup_value(got_vp) == CONFD_ERR) {
                erl_free_compound(result);
                return CONFD_ERR;
            }
            switch (want_vp->type) {
            case C_PTR:
                if (got_vp->type != C_NOEXISTS) {
                    if (CONFD_GET_PTR_TYPE(want_vp) != got_vp->type) {
                        erl_free_compound(result);
                        confd_free_value(got_vp);
                        return ret_err(CONFD_ERR_BADTYPE,
                                       "Returned type %d is wrong "
                                       "for element %d", got_vp->type, i);
                    }
                    if (!set_value(CONFD_GET_PTR_VALP(want_vp), got_vp))
                        return confd_internal_error(
                            "Internal error, bad type for tag-value\n");
                }
                break;
            case C_XMLBEGIN:
            case C_XMLEND:
                /* special case: non-existing optional container */
                if (got_vp->type == C_NOEXISTS)
                    want_vp->type = C_NOEXISTS;
                break;
            default:
                *want_vp = *got_vp;
            }
        }
        list = ERL_CONS_TAIL(list);
    }
    if (!ERL_IS_NIL(list))
        return confd_internal_error(
            "Internal error, too many elems in tag value list\n");
    erl_free_compound(result);
    return status;
}

int maapi_set_object(int sock, int thandle, const confd_value_t *values,
                     int n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vset_object(sock, thandle, values, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vset_object(int sock, int thandle, const confd_value_t *values,
                     int n, const char *fmt, va_list args)
{
    ETERM *arg;

    clr_confd_err();
    if ((arg = vals_to_termlist(values, n, 0)) == NULL)
        return CONFD_ERR;
    return vmaapi_set(sock, thandle, MAAPI_SET_OBJECT, arg, fmt, args);
}

int maapi_set_values(int sock, int thandle, const confd_tag_value_t *values,
                     int n, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vset_values(sock, thandle, values, n, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vset_values(int sock, int thandle, const confd_tag_value_t *values,
                      int n, const char *fmt, va_list args)
{
    ETERM *arg;

    clr_confd_err();
    if ((arg = tag_vals_to_termlist(values, n, 0)) == NULL)
        return CONFD_ERR;
    return vmaapi_set(sock, thandle, MAAPI_SET_VALUES, arg, fmt, args);
}

int maapi_shared_set_values(int sock, int thandle,
                            const confd_tag_value_t *values,
                            int n, int flags, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vshared_set_values(sock, thandle, values, n, flags, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_set_values(int sock, int thandle,
                             const confd_tag_value_t *values,
                             int n, int flags, const char *fmt, va_list args)
{
    ETERM *arg;
    ETERM *tup[2];

    clr_confd_err();
    if ((tup[0] = tag_vals_to_termlist(values, n, 0)) == NULL)
        return CONFD_ERR;
    tup[1] = (flags & MAAPI_SHARED_NO_BACKPOINTER) ?
        erl_mk_atom("false") : erl_mk_atom("true");
    arg = erl_mk_tuple(tup, 2);
    return vmaapi_set(sock, thandle, MAAPI_SHARED_SET_VALUES, arg, fmt, args);
}

int maapi_get_case(int sock, int thandle, const char *choice,
                   confd_value_t *rcase, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vget_case(sock, thandle, choice, rcase, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_case(int sock, int thandle, const char *choice,
                    confd_value_t *rcase, const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath, *req;
    ETERM *tup[2];
    int status;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    if ((tup[0] = _confd_parse_choice_path(choice)) == NULL)
        return CONFD_ERR;
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);

    arg_request(sock, MAAPI_GET_CASE, thandle, &status, isrel, rcase, req);
    return status;
}

int maapi_get_attrs(int sock, int thandle, u_int32_t *attrs, int num_attrs,
                    confd_attr_value_t **attr_vals, int *num_vals,
                    const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vget_attrs(sock, thandle, attrs, num_attrs,
                           attr_vals, num_vals, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vget_attrs(int sock, int thandle, u_int32_t *attrs, int num_attrs,
                     confd_attr_value_t **attr_vals, int *num_vals,
                     const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath, *req;
    ETERM *tup[2];
    ETERM *elist[num_attrs];
    ETERM *result, *attrl;
    int status;
    int len, i;
    confd_attr_value_t *attrp;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    for (i = 0; i < num_attrs; i++)
        elist[i] = erl_mk_uint(attrs[i]);
    tup[0] = erl_mk_list(elist, num_attrs);
    tup[1] = epath;
    req = erl_mk_tuple(tup, 2);
    result = op_request_term(sock, MAAPI_GET_ATTRS,
                             thandle, isrel, req, &status);
    erl_free_compound(req);
    if (result == NULL)
        return status;
    status = CONFD_OK;
    len = erl_length(result);
    if (len == 0) {
        attrp = NULL;
    } else {
        if ((attrp = confd_malloc(len * sizeof(confd_attr_value_t))) == NULL)
            return CONFD_ERR;
        attrl = result;
        for (i = 0; status == CONFD_OK && i < len; i++) {
            ETERM *attr = ERL_CONS_HEAD(attrl);
            attrp[i].attr = ERL_INT_UVALUE(ERL_TUPLE_ELEMENT(attr, 0));
            if (eterm_to_val(ERL_TUPLE_ELEMENT(attr, 1), &attrp[i].v) == NULL ||
                confd_dup_value(&attrp[i].v) == CONFD_ERR)
                status = CONFD_ERR;
            attrl = ERL_CONS_TAIL(attrl);
        }
    }
    erl_free_compound(result);
    if (status == CONFD_OK) {
        *attr_vals = attrp;
        *num_vals = len;
    }
    return status;
}

int maapi_set_attr(int sock, int thandle, u_int32_t attr, confd_value_t *v,
                   const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vset_attr(sock, thandle, attr, v, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vset_attr(int sock, int thandle, u_int32_t attr, confd_value_t *v,
                    const char *fmt, va_list args)
{
    int isrel;
    ETERM *epath, *req;
    ETERM *atup[2];
    ETERM *rtup[2];
    int status;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    if ((atup[1] = val_to_term(v)) == NULL)
        return CONFD_ERR;
    atup[0] = erl_mk_uint(attr);
    rtup[0] = erl_mk_tuple(atup, 2);
    rtup[1] = epath;
    req = erl_mk_tuple(rtup, 2);
    op_request_term(sock, MAAPI_SET_ATTR, thandle, isrel, req, &status);
    erl_free_compound(req);
    return status;
}


int maapi_delete_all(int sock, int thandle,
                     enum maapi_delete_how how)
{
    clr_confd_err();
    return intcall(sock, MAAPI_DELETE_ALL, thandle, erl_mk_int(how));
}

int maapi_revert(int sock, int thandle)
{
    clr_confd_err();
    return intcall(sock, MAAPI_REVERT, thandle, NULL);
}

int maapi_diff_iterate(int sock, int th,
                       enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                                   enum maapi_iter_op op,
                                                   confd_value_t *oldv,
                                                   confd_value_t *newv,
                                                   void *state),
                       int flags,
                       void *initstate)
{
    int ret;
    char xbuf[8];

    put_int32(0, xbuf);         /* useIKP = false */
    put_int32(flags, xbuf+4);

    ret = op_write_buf(sock, MAAPI_DIFF_ITER, xbuf, 8, th);

    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE MAAPI_DIFF_ITER\n");
    }

    if (ret == CONFD_OK) {
        return _confd_iterate(sock, iter, initstate);
    } else {
        return ret;
    }
}


int maapi_keypath_diff_iterate(
    int sock, int th,
    enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                enum maapi_iter_op op,
                                confd_value_t *oldv,
                                confd_value_t *newv,
                                void *state),
    int flags,
    void *initstate,
    const char *fmtpath, ...)
{
    int ret;
    va_list args;

    va_start(args,fmtpath);
    ret = maapi_vkeypath_diff_iterate(
        sock, th, iter, flags, initstate, fmtpath, args);
    va_end(args);
    return ret;
}

int maapi_vkeypath_diff_iterate(
    int sock, int th,
    enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                enum maapi_iter_op op,
                                confd_value_t *oldv,
                                confd_value_t *newv,
                                void *state),
    int flags,
    void *initstate,
    const char *fmtpath, va_list args)
{
    int ret, isrel;
    ETERM *epath;
    ETERM *req[3];
    ETERM *tup;

    clr_confd_err();
    epath = parse_path(&isrel, fmtpath, args);
    if (isrel || (epath == NULL))
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmtpath);
    req[0] = erl_mk_int(0); /* useikp == 0 */
    req[1] = erl_mk_int(flags);
    req[2] = epath;
    tup = erl_mk_tuple(req, 3);
    ret = term_write(sock, tup, MAAPI_DIFF_IKP_ITER, th);
    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE MAAPI_DIFF_IKP_ITER %s\n",
                           format_path(isrel, epath));
    }
    erl_free_compound(tup);

    if (ret == CONFD_OK) {
        return _confd_iterate(sock, iter, initstate);
    } else {
        return ret;
    }
}

int maapi_diff_iterate_resume(
    int sock, enum maapi_iter_ret reply,
    enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                enum maapi_iter_op op,
                                confd_value_t *oldv,
                                confd_value_t *newv,
                                void *state),
    void *resumestate)
{
    return _confd_iterate_resume(sock, reply, iter, resumestate,
                                 "MAAPI_DIFF_ITER_RESUME");
}


int maapi_iterate(
    int sock, int th,
    enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                confd_value_t *v,
                                confd_attr_value_t *attr_vals,
                                int num_attr_vals,
                                void *state),
    int flags,
    void *initstate,
    const char *fmtpath, ...)
{
    int ret;
    va_list args;

    va_start(args,fmtpath);
    ret = maapi_viterate(sock, th, iter, flags, initstate, fmtpath, args);
    va_end(args);
    return ret;
}

int maapi_viterate(
    int sock, int th,
    enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                confd_value_t *v,
                                confd_attr_value_t *attr_vals,
                                int num_attr_vals,
                                void *state),
    int flags,
    void *initstate,
    const char *fmtpath, va_list args)
{
    int ret, isrel;
    ETERM *epath;
    ETERM *req[3];
    ETERM *tup;

    clr_confd_err();
    epath = parse_path(&isrel, fmtpath, args);
    if (isrel || (epath == NULL))
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmtpath);
    req[0] = erl_mk_int(0); /* useikp == 0 */
    req[1] = erl_mk_int(flags);
    req[2] = epath;
    tup = erl_mk_tuple(req, 3);
    ret = term_write(sock, tup, MAAPI_ITERATE, th);
    if (confd_debug_level >= CONFD_TRACE) {
        confd_trace_printf("TRACE MAAPI_ITERATE %s\n",
                           format_path(isrel, epath));
    }
    erl_free_compound(tup);
    if (ret == CONFD_OK) {
        return _confd_iterate(sock, iter, initstate);
    } else {
        return ret;
    }
}

int maapi_iterate_resume(
    int sock, enum maapi_iter_ret reply,
    enum maapi_iter_ret (*iter)(confd_hkeypath_t *kp,
                                confd_value_t *v,
                                confd_attr_value_t *attr_vals,
                                int num_attr_vals,
                                void *state),
    void *resumestate)
{
    return _confd_iterate_resume(sock, reply, iter, resumestate,
                                 "MAAPI_ITERATE_RESUME");
}


static int ncs_apply_template(int sock, int thandle, char *template_name,
                              const struct ncs_name_value *variables,
                              int num_variables, int use_shared, int flags,
                              const char *fmt, va_list args)
{
    int i, isrel, status;
    confd_value_t v;
    ETERM *tup[6], *vl[num_variables], *arg;

    clr_confd_err();
    tup[0] = erl_mk_binary(template_name, strlen(template_name));
    if ((tup[1] = parse_path(&isrel, fmt, args)) == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    }
    for (i = 0; i < num_variables; i++) {
        ETERM *vtup[2];
        vtup[0] = erl_mk_binary(variables[i].name, strlen(variables[i].name));
        vtup[1] = erl_mk_binary(variables[i].value, strlen(variables[i].value));
        vl[i] = erl_mk_tuple(vtup, 2);
    }
    tup[2] = erl_mk_list(vl, num_variables);
    tup[3] = erl_mk_atom("undefined"); /* unused 'document' arg */
    tup[4] = use_shared ? erl_mk_atom("true") : erl_mk_atom("false");
    tup[5] = (flags & MAAPI_SHARED_NO_BACKPOINTER) ?
        erl_mk_atom("false") : erl_mk_atom("true");
    if ((arg = erl_mk_tuple(tup, 6)) == NULL) {
        return ret_err(CONFD_ERR_MALLOC, "Failed to alloc");
    }
    arg_request(sock, MAAPI_NCS_APPLY_TEMPLATE, thandle, &status, isrel,
                &v, arg);
    return status;
}

int maapi_ncs_apply_template(int sock, int thandle, char *template_name,
                             const struct ncs_name_value *variables,
                             int num_variables, int flags,
                             const char *rootfmt, ...)
{
    int ret;
    va_list args;

    va_start(args, rootfmt);
    ret = ncs_apply_template(sock, thandle, template_name,
                             variables, num_variables,
                             0, flags, rootfmt, args);
    va_end(args);
    return ret;
}

int maapi_vncs_apply_template(int sock, int thandle, char *template_name,
                              const struct ncs_name_value *variables,
                              int num_variables, int flags,
                              const char *rootfmt, va_list args)
{
    return ncs_apply_template(sock, thandle, template_name,
                              variables, num_variables,
                              0, flags, rootfmt, args);
}

int maapi_shared_ncs_apply_template(int sock, int thandle, char *template_name,
                                    const struct ncs_name_value *variables,
                                    int num_variables, int flags,
                                    const char *rootfmt, ...)
{
    int ret;
    va_list args;

    va_start(args, rootfmt);
    ret = ncs_apply_template(sock, thandle, template_name,
                             variables, num_variables,
                             1, flags, rootfmt, args);
    va_end(args);
    return ret;
}

int maapi_vshared_ncs_apply_template(int sock, int thandle, char *template_name,
                                     const struct ncs_name_value *variables,
                                     int num_variables, int flags,
                                     const char *rootfmt, va_list args)
{
    return ncs_apply_template(sock, thandle, template_name,
                              variables, num_variables,
                              1, flags, rootfmt, args);
}

int maapi_ncs_get_templates(int sock, char ***templates, int *num_templates)
{
    ETERM *reply, *t;
    int status;
    int i, n;
    char **tl;

    reply = op_request_term(sock, MAAPI_NCS_TEMPLATES, -1, 0, NULL, &status);
    if (status < 0) {
        return status;
    }
    n = erl_length(reply);
    if ((tl = confd_malloc(n * sizeof(char *))) == NULL) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    t = reply;
    for (i = 0; i < n; i++) {
        if ((tl[i] = bin_dup(ERL_CONS_HEAD(t))) == NULL) {
            for (i--; i >= 0; i--) {
                free(tl[i]);
            }
            free(tl);
            erl_free_compound(reply);
            return CONFD_ERR;
        }
        t = ERL_CONS_TAIL(t);
    }
    erl_free_compound(reply);
    *templates = tl;
    *num_templates = n;
    return CONFD_OK;
}

int maapi_ncs_write_service_log_entry(int sock, const char *msg,
                                      confd_value_t *type,
                                      confd_value_t *level,
                                      const char *fmt, ...)
{
    int ret;
    va_list args;
    va_start(args, fmt);
    ret = maapi_vncs_write_service_log_entry(sock, msg, type, level, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vncs_write_service_log_entry(int sock, const char *msg,
                                       confd_value_t *type,
                                       confd_value_t *level,
                                       const char *fmt, va_list args)
{
    int isrel;
    int useikp = 0;
    ETERM *req[5];
    ETERM *tup;

    clr_confd_err();
    if ((req[0] = parse_path(&isrel, fmt, args)) == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad service path <%s>", fmt);
    }
    if (isrel == 1) {
        return ret_err(CONFD_ERR_BADPATH, "Service path must be absolute");
    }
    req[1] = erl_mk_int(useikp);
    req[2] = erl_mk_string(msg);
    if ((req[3] = val_to_term(type)) == NULL)
        return CONFD_ERR;
    if ((req[4] = val_to_term(level)) == NULL)
        return CONFD_ERR;
    tup = erl_mk_tuple(req, 5);
    return intcall(sock, MAAPI_NCS_WRITE_SERVICE_LOG_ENTRY, -1, tup);
}

int maapi_init_upgrade(int sock, int timeoutsecs, int flags)
{
    ETERM *req[2];
    ETERM *tup;

    req[0] = erl_mk_int(timeoutsecs);
    req[1] = erl_mk_int(flags);
    tup = erl_mk_tuple(req, 2);
    return intcall(sock, MAAPI_INIT_UPGRADE,  -1, tup);
}

int maapi_perform_upgrade(int sock, const char **loadpathdirs, int n)
{
    ETERM *req[n];
    ETERM *list;
    int i;

    for (i = 0; i < n; i++)
        req[i] = erl_mk_binary(loadpathdirs[i], strlen(loadpathdirs[i]));
    list = erl_mk_list(req, n);
    return intcall(sock, MAAPI_PERFORM_UPGRADE,  -1, list);
}

int maapi_commit_upgrade(int sock)
{
    return intcall(sock, MAAPI_COMMIT_UPGRADE,  -1, NULL);
}

int maapi_abort_upgrade(int sock)
{
    return intcall(sock, MAAPI_ABORT_UPGRADE,  -1, NULL);
}



static ETERM* encode_oid(struct snmp_oid *op)
{
    ETERM *arr[op->len];
    int i;
    for (i=0; i<op->len; i++) {
        arr[i] = erl_mk_int(op->oid[i]);
    }
    return erl_mk_list(arr, op->len);
}

/* deprecated */
int maapi_snmp_send_notification(int sock,
                    char *notification,
                    char *notif_name,
                    char *ctx_name,
                    struct maapi_snmp_varbind *varbinds,
                    int num_vars)
{
    ETERM *items[num_vars];
    ETERM *arg, *req;
    ETERM *tup[4];
    int i, res;
    for (i=0; i<num_vars; i++) {
        struct maapi_snmp_varbind *vb = varbinds + i;
        switch(vb->type) {
        case C_SNMP_VARIABLE: {
            tup[0] = erl_mk_binary(vb->binding.var.varname,
                                   strlen(vb->binding.var.varname));
            if ((tup[1] = val_to_term(&vb->binding.var.val)) == NULL)
                return CONFD_ERR;
            arg = erl_mk_tuple(tup,2);
            break;
        }
        case C_SNMP_OID: {
            tup[0] = encode_oid(&vb->binding.oid.oid);
            if ((tup[1] = val_to_term(&vb->binding.oid.val))==NULL)
                return CONFD_ERR;
            arg = erl_mk_tuple(tup,2);
            break;
        }
        case C_SNMP_COL_ROW: {
            tup[0] = erl_mk_binary(vb->binding.cr.column,
                                   strlen(vb->binding.cr.column));
            tup[1] = encode_oid(&vb->binding.cr.rowindex);
            if ((tup[2] = val_to_term(&vb->binding.cr.val))==NULL)
                return CONFD_ERR;
            arg = erl_mk_tuple(tup,3);
            break;
        }
        default:
            return CONFD_ERR;
        }
        items[i] = arg;
    }
    arg = erl_mk_list(items, num_vars);
    tup[0] = erl_mk_binary(notification, strlen(notification));
    tup[1] = erl_mk_binary(notif_name, strlen(notif_name));
    tup[2] = erl_mk_binary(ctx_name, strlen(ctx_name));
    tup[3] = arg;
    req = erl_mk_tuple(tup, 4);
    res = intcall(sock, MAAPI_SNMP_SEND_TRAP, -1, req);
    erl_free_compound(req);
    return res;
}


static int vrequest_action(int sock, int op, int thandle,
                          int ns, const char *fmt, va_list args,
                          confd_tag_value_t *params, int nparams,
                          confd_tag_value_t **values, int *nvalues)
{
    int i, isrel, len;
    ETERM *epath;
    ETERM *parmtup[3];
    ETERM *tup[3];
    ETERM *req, *reply;
    int status, retval;
    confd_tag_value_t *tv;

    epath = parse_path(&isrel, fmt, args);
    if (epath == NULL)
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmt);
    if (thandle == -1 && isrel) {
        erl_free_compound(epath);
        return ret_err(CONFD_ERR_BADPATH,
                       "Bad path <%s> - relative path not allowed", fmt);
    }

    if ((parmtup[1] = tag_vals_to_termlist(params, nparams, 0)) == NULL) {
        erl_free_compound(epath);
        return CONFD_ERR;
    }
    parmtup[0] = erl_mk_atom("hxml");
    tup[0] = erl_mk_tuple(parmtup, 2);
    tup[1] = epath;
    if (thandle == -1) {
        tup[2] = erl_mk_int(ns);
        req = erl_mk_tuple(tup, 3);
    } else {
        req = erl_mk_tuple(tup, 2);
    }

    reply = op_request_term(sock, op, thandle, isrel, req, &status);
    erl_free_compound(req);
    if (status < 0)
        return status;
    if (reply == NULL) {
        *values = NULL;
        *nvalues = 0;
        return status;
    }
    len = erl_length(reply);
    if ((tv = confd_malloc(len * sizeof(confd_tag_value_t))) == NULL) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    retval = etermlist_to_tag_vals(reply, tv, len);
    if (retval != len) {
        erl_free_compound(reply);
        free(tv);
        if (retval != CONFD_ERR)
            confd_internal_error("Internal error, tag value list too long\n");
        return CONFD_ERR;
    }
    for (i = 0; i < len; i++) {
        if (confd_dup_value(CONFD_GET_TAG_VALUE(&tv[i])) == CONFD_ERR) {
            erl_free_compound(reply);
            free(tv);
            return CONFD_ERR;
        }
    }
    erl_free_compound(reply);
    *values = tv;
    *nvalues = len;
    return CONFD_OK;
}

int maapi_request_action(int sock,
                         confd_tag_value_t *params, int nparams,
                         confd_tag_value_t **values, int *nvalues,
                         int hashed_ns, const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args, fmt);
    ret = vrequest_action(sock, MAAPI_REQUEST_ACTION, -1, hashed_ns,
                          fmt, args, params, nparams, values, nvalues);
    va_end(args);
    return ret;
}

int maapi_vrequest_action(int sock,
                          confd_tag_value_t *params, int nparams,
                          confd_tag_value_t **values, int *nvalues,
                          int hashed_ns, const char *fmt, va_list args)
{
    return vrequest_action(sock, MAAPI_REQUEST_ACTION, -1, hashed_ns,
                           fmt, args, params, nparams, values, nvalues);
}

int maapi_request_action_th(int sock, int thandle,
                            confd_tag_value_t *params, int nparams,
                            confd_tag_value_t **values, int *nvalues,
                            const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args, fmt);
    ret = vrequest_action(sock, MAAPI_REQUEST_ACTION_TH, thandle, 0,
                          fmt, args, params, nparams, values, nvalues);
    va_end(args);
    return ret;
}

int maapi_vrequest_action_th(int sock, int thandle,
                             confd_tag_value_t *params, int nparams,
                             confd_tag_value_t **values, int *nvalues,
                             const char *fmt, va_list args)
{
    return vrequest_action(sock, MAAPI_REQUEST_ACTION_TH, thandle, 0,
                           fmt, args, params, nparams, values, nvalues);
}

static int vrequest_action_str(int sock, int op, int thandle, char **output,
                               const char *cmd_fmt, const char *path_fmt,
                               va_list args)
{
    int status;
    int isrel;
    int sz;
    char cmd[BUFSIZ];
    ETERM *epath;
    ETERM *parmtup[2];
    ETERM *req;
    ETERM *reply;

    *output = NULL;
    status = substitute_percent(cmd_fmt, cmd, sizeof(cmd), args, 0);
    if ((status < 0) || (status > BUFSIZ)) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Bad action <%s>", cmd_fmt);
    }

    epath = parse_path(&isrel, path_fmt, args);
    if (epath == NULL) {
        return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", path_fmt);
    }

    if (thandle == -1 && isrel) {
        erl_free_compound(epath);
        return ret_err(CONFD_ERR_BADPATH,
                       "Bad path <%s> - relative path not allowed", path_fmt);
    }

    parmtup[0] = epath;
    parmtup[1] = erl_mk_binary(cmd, strlen(cmd));
    req = erl_mk_tuple(parmtup, 2);
    reply = op_request_term(sock, op, thandle, isrel, req, &status);
    erl_free_compound(req);
    if (reply == NULL) {
        return status;
    }
    if (status < 0) {
        erl_free_compound(reply);
        return status;
    }

    if (!ERL_IS_BINARY(reply)) {
        erl_free_compound(reply);
        return ret_err(CONFD_ERR_INTERNAL, "Reply is not a binary");
    }

    sz = ERL_BIN_SIZE(reply);
    *output = confd_malloc(sz+1);
    if (*output == NULL) {
        erl_free_compound(reply);
        return CONFD_ERR;
    }
    memcpy(*output, ERL_BIN_PTR(reply), sz);
    if (sz > 0 && (*output)[sz-1] == '\n') {
        /* Trim trailing newline */
        (*output)[sz-1] = '\000';
    } else {
        (*output)[sz] = '\000';
    }
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_request_action_str_th(int sock, int thandle, char **output,
                                const char *cmd_fmt, const char *path_fmt,
                                ...)
{
    va_list args;
    int ret;

    va_start(args, path_fmt);
    ret = vrequest_action_str(sock, MAAPI_REQUEST_ACTION_STR_TH,
                              thandle, output, cmd_fmt, path_fmt, args);
    va_end(args);
    return ret;
}

int maapi_vrequest_action_str_th(int sock, int thandle, char **output,
                                 const char *cmd_fmt, const char *path_fmt,
                                 va_list args)
{
    return vrequest_action_str(sock, MAAPI_REQUEST_ACTION_STR_TH,
                               thandle, output, cmd_fmt, path_fmt, args);
}

int maapi_xpath2kpath(int sock, const char *xpath, confd_hkeypath_t **hkp)
{
    ETERM *request, *reply;
    int status;
    confd_hkeypath_t kp, *dup_kp;

    request = erl_mk_binary(xpath, strlen(xpath));
    reply = op_request_term(sock, MAAPI_XPATH2HKP, -1, 0, request, &status);
    erl_free_compound(request);
    if (status < 0)
        return status;
    if (!populate_keypath(reply, &kp))
        return CONFD_ERR;
    dup_kp = confd_hkeypath_dup(&kp);
    erl_free_compound(reply);
    if (dup_kp == NULL)
        return CONFD_ERR;
    *hkp = dup_kp;
    return CONFD_OK;
}


/* Dynamic schema access */

/* some prime numbers just above 2 ^ 28 */

#define FUNNY_NUMBER1  268440163
#define FUNNY_NUMBER4  268436141

/* make the update thread-safe - this doesn't mean that it's OK to have
   multiple threads calling maapi_load_schemas(), and each time it is
   called, any pointers previously returned by the access functions will
   become invalid - but we should be able to handle it without crashing  */
PTHREAD_MUTEX_T maapi_load_schemas_lock;

#define SCHEMA_MAGIC "confd_schema"
#define SCHEMA_BYTES 0x0102030405060708LL
#define SCHEMA_SIZE_INC (16 * pagesize)

struct schemas_info {
    char magic[sizeof(SCHEMA_MAGIC)];
    size_t long_size, ptr_size;
    long long_bytes;
    void *base;
    size_t size;
    int flags;
    int libvsn;
    struct schema *schemas;
    int nschemas;
    int nschemas_listed;
    struct hashtable *hash2str;
    struct hashtable *str2hash;
    struct confd_type confd_types[CE_MAXTYPE];
};

/* shm_base is (also) used as flag - non-NULL iff mmap is active */
static void *shm_base = NULL;
static int shm_fd, shm_keepsize, shm_flags;
static size_t shm_size, shm_mapped, shm_used, shm_filesize;
static size_t shm_page_start, shm_page_end, shm_page_used;
static size_t pagesize;
/* shm_si is (also) used as flag - non-NULL iff confd_mmap_schemas_setup()
   but not the subsequent confd_load_schemas[_list]() has been run */
static struct schemas_info *shm_si = NULL;

static void *grow_shm(size_t tot_size)
{
    void *ret;

    if (tot_size > shm_filesize) {
        while (tot_size > shm_filesize) {
            if (shm_filesize == 0 && shm_size != 0)
                shm_filesize = shm_size;
            else
                shm_filesize += SCHEMA_SIZE_INC;
        }
        if (ftruncate(shm_fd, shm_filesize) != 0) {
            confd_set_errno(CONFD_ERR_OS);
            return ret_null("Failed to grow mmapped file to %"
                            PRIuMAX " bytes: %s",
                            (uintmax_t)shm_mapped, strerror(errno));
        }
    }
    if (tot_size > shm_mapped) {
        if (shm_used != 0) {
            if (shm_keepsize) {
                confd_set_errno(CONFD_ERR_PROTOUSAGE);
                return ret_null("Given fixed size %" PRIuMAX " is insufficient",
                                (uintmax_t)shm_mapped);
            }
            munmap(shm_base, shm_mapped);
        }
        while (tot_size > shm_mapped) {
            if (shm_mapped == 0 && shm_size != 0)
                shm_mapped = shm_size;
            else
                shm_mapped += SCHEMA_SIZE_INC;
        }
        if ((ret = mmap(shm_base, shm_mapped, PROT_READ|PROT_WRITE,
                        MAP_SHARED|shm_flags, shm_fd, 0)) != shm_base) {
            if (shm_used == 0 && ret != MAP_FAILED) {
                /* OK for first mmap (only) to give different addr */
                shm_base = ret;
            } else {
                confd_set_errno(CONFD_ERR_OS);
                if (ret == MAP_FAILED) {
                    return ret_null("Failed to mmap %" PRIuMAX
                                    " bytes at 0x%" PRIxPTR ": %s",
                                    (uintmax_t)shm_mapped, (uintptr_t)shm_base,
                                    strerror(errno));
                } else {
                    shm_base = ret; /* for munmap */
                    return ret_null("Failed to mmap %" PRIuMAX
                                    " bytes at 0x%" PRIxPTR
                                    ": mmap() returned 0x%" PRIxPTR,
                                    (uintmax_t)shm_mapped, (uintptr_t)shm_base,
                                    (uintptr_t)ret);
                }
            }
        }
    }
    return shm_base;
}

static void *shm_alloc(size_t size)
{
    void *ret;

    size = ((size + 7) & ~7); /* keep 8-byte alignment */
    if (shm_used <= shm_page_start && shm_used + size > shm_page_start)
        /* skip page allocation range */
        shm_used = shm_page_end;
    if (grow_shm(shm_used + size) == NULL)
        return NULL;
    ret = (char *)shm_base + shm_used;
    shm_used += size;
    return ret;
}

static void *shm_page_alloc(size_t size)
{
    void *ret;

    size = ((size + 7) & ~7); /* keep 8-byte alignment */
    if (shm_page_start + shm_page_used + size > shm_page_end) {
        if (shm_page_start < shm_used) {
            /* start a new page allocation range */
            while (shm_page_start < shm_used)
                shm_page_start += pagesize;
            shm_page_end = shm_page_start;
            shm_page_used = 0;
        }
        /* add needed pages */
        while (shm_page_start + shm_page_used + size > shm_page_end)
            shm_page_end += pagesize;
        if (grow_shm(shm_page_end) == NULL)
            return NULL;
    }
    ret = (char *)shm_base + shm_page_start + shm_page_used;
    shm_page_used += size;
    return ret;
}

static void shm_free(void *ptr)
{
    return;
}

static void *(*s_malloc)(size_t size) = confd_malloc;
static void *(*s_page_alloc)(size_t size) = confd_malloc;
static void (*s_free)(void *ptr) = free;

static void *s_calloc(size_t size)
{
    void *ret = s_malloc(size);

    if (ret != NULL) {
        memset(ret, 0, size);
    }
    return ret;
}

static void *type_alloc(size_t size)
{
    void *ret = s_page_alloc(size);

    if (ret != NULL) {
        memset(ret, 0, size);
    }
    return ret;
}

static char *s_bin_dup(const ETERM *b)
{
    int sz = 0;
    void *ptr;
    char *buf;

    if (ERL_IS_BINARY(b)) {
        sz =  ERL_BIN_SIZE(b);
        ptr = ERL_BIN_PTR(b);
    }
    else if (ERL_IS_ATOM(b)) {
        sz = ERL_ATOM_SIZE(b);
        ptr = ERL_ATOM_PTR(b);
    } else {
        return NULL;
    }

    if ((buf = s_malloc(sz + 1)) == NULL)
        return NULL;
    memcpy(buf, ptr, sz);
    buf[sz] = 0;
    return buf;
}

static struct confd_type *shm_find_type(const char *str)
{
    struct confd_type *type = confd_find_type(str);

    if (type == NULL) {
        return type;
    } else {
        return &shm_si->confd_types[type - &confd_types[0]];
    }
}

static struct confd_type *(*s_find_type)(const char *str) = confd_find_type;


static unsigned int hash2str_hashfromkey(void *ky)
{
    return (uintptr_t)ky;
}

static int hash2str_equalkeys(void *k1, void *k2)
{
    return (k1 == k2);
}

static unsigned int str2hash_hashfromkey(void *ky)
{
    char *str = (char *)ky;
    int len = strlen(str);
    int i;
    unsigned int hash = 0;

    for (i = 0; i < len; i++)
        hash = hash * FUNNY_NUMBER1 + *str++;
    return hash * FUNNY_NUMBER4 + len;
}

static int str2hash_equalkeys(void *k1, void *k2)
{
    return (strcmp(k1, k2) == 0);
}

static ETERM *ns_term_list;
static ETERM *ns_term_tail;

static ETERM *term_read_list(int sock, int *ret)
{
    ETERM *term;

    if (ns_term_list == NULL) {
        if ((term = term_read(sock, ret, -1)) == NULL)
            return NULL;
        if (!ERL_IS_LIST(term))
            return term;
        ns_term_list = ns_term_tail = term;
    }
    term = ERL_CONS_HEAD(ns_term_tail);
    ns_term_tail = ERL_CONS_TAIL(ns_term_tail);
    *ret = CONFD_OK;
    return term;
}

static void free_list_term(ETERM *term)
{
    if (ns_term_list == NULL) {
        erl_free_compound(term);
    } else if (ERL_IS_EMPTY_LIST(ns_term_tail)) {
        erl_free_compound(ns_term_list);
        ns_term_list = NULL;
    }
}

static void free_list_all(void)
{
    if (ns_term_list != NULL) {
        erl_free_compound(ns_term_list);
        ns_term_list = NULL;
    }
}

static void replace_hashtables(struct hashtable *hash2str,
                               struct hashtable *str2hash,
                               int mmapped)
{
    struct hashtable *old_hash2str = hash2str_tab;
    struct hashtable *old_str2hash = str2hash_tab;
    int old_mmapped = confd_hashtables_mmapped;

    hash2str_tab = hash2str;
    str2hash_tab = str2hash;
    confd_hashtables_mmapped = mmapped;
    if (old_hash2str != NULL && old_mmapped == 0) {
        hashtable_destroy(old_hash2str, 1);
        hashtable_destroy(old_str2hash, 0);
    }
}

static int load_hash_db(int sock)
{
    int ret, read_ret;
    struct hashtable *hash2str = NULL, *str2hash = NULL;
    ETERM *term, *atom;
    int size = 0;
    char *str;
    u_int32_t hash;

    confd_trace(CONFD_TRACE, "MAAPI_LOAD_HASH_DB\n");
    ret = op_write(sock, MAAPI_LOAD_HASH_DB, -1);
    if (ret != CONFD_OK)
        return ret;
    if ((term = term_read_list(sock, &ret)) == NULL)
        return ret;
    if (ERL_IS_INTEGER(term)) {
        size = ERL_INT_VALUE(term);
    } else {
        ret = ret_err(CONFD_ERR_INTERNAL, "Bad HASH_DB size");
        /* keep reading */
    }
    free_list_term(term);

    /* For shm we need to avoid expanding since it will free()
       - for non-shm it saves some cycles to avoid it.
       Slight hack here, hashtable allows 65% "load" before expanding
       - we ask for 2 * needed which should thus never go above 50%   */
    if (ret == CONFD_OK &&
        ((hash2str = create_hashtable_mallf(2 * size, hash2str_hashfromkey,
                                            hash2str_equalkeys,
                                            s_malloc, s_free,
                                            NULL, NULL)) == NULL ||
         (str2hash = create_hashtable_mallf(2 * size, str2hash_hashfromkey,
                                            str2hash_equalkeys,
                                            s_malloc, s_free,
                                            NULL, NULL)) == NULL)) {
        confd_set_errno(CONFD_ERR_MALLOC);
        ret = CONFD_ERR;
    }

    while (1) {
        if ((term = term_read_list(sock, &read_ret)) == NULL) {
            if (ret == CONFD_OK)
                ret = read_ret;
            break;
        }
        if (ERL_IS_ATOM(term) && bin_eq(term, "eof")) {
            free_list_term(term);
            break;
        }
        if (ret == CONFD_OK) {
            if (ERL_IS_TUPLE(term) && ERL_TUPLE_SIZE(term) == 2) {
                atom = TE(term, 0);
                if ((str = s_bin_dup(atom)) == NULL) {
                    ret = CONFD_ERR;
                    /* keep reading */
                } else if (--size < 0) {
                    ret = ret_err(CONFD_ERR_INTERNAL, "Too many HASH_DB items");
                    /* keep reading */
                } else {
                    hash = TUINT(term, 1);
                    if (!hashtable_insert(hash2str, INT2VOID(hash), str) ||
                        !hashtable_insert(str2hash, str, INT2VOID(hash))) {
                        confd_set_errno(CONFD_ERR_MALLOC);
                        ret = CONFD_ERR;
                        /* keep reading */
                    }
                }
            } else {
                ret = ret_err(CONFD_ERR_INTERNAL, "Bad HASH_DB data");
                /* keep reading */
            }
        }
        free_list_term(term);
    }

    if (ret != CONFD_OK) {
        if (hash2str != NULL)
            hashtable_destroy(hash2str, 1);
        if (str2hash != NULL)
            hashtable_destroy(str2hash, 0);
        return ret;
    }

    if (shm_si != NULL) {
        shm_si->hash2str = hash2str;
        shm_si->str2hash = str2hash;
        return ret;
    }

    replace_hashtables(hash2str, str2hash, 0);

    return CONFD_OK;
}

#define OK(ret) do {                            \
        int _ret = (ret);                       \
        if (_ret != CONFD_OK) return _ret;      \
    } while (0)

/* make sure array NAME of TYPE elems is long enough for elem IX */
#define REALLOC_IX(type, name, ix) do {                         \
        if (ix >= name ## _len) {                               \
            while (ix >= name ## _len)                          \
                name ## _len += 128;                            \
            name = realloc(name, name ## _len * sizeof(type));  \
            if (name == NULL) {                                 \
                confd_set_errno(CONFD_ERR_MALLOC);              \
                return CONFD_ERR;                               \
            }                                                   \
        }                                                       \
    } while (0)

struct tmp_schema {
    u_int32_t nshash;
    const char *uri;
    const char *prefix;
    const char *revision;
    const char *module;
    struct confd_cs_node *root;
    struct named_type *types;
    int loaded;
    int num_types;
    int types_len;
    struct hashtable *type_hash;
};

static int find_tmp_schema(struct tmp_schema **found, u_int32_t nshash,
                           struct tmp_schema ***schemas,
                           int *schemas_len, int *num_schemas)
{
    int i;
    struct tmp_schema *tmp;

    for (i = 0; i < *num_schemas; i++) {
        if ((*schemas)[i]->nshash == nshash) {
            *found = (*schemas)[i];
            return CONFD_OK;
        }
    }
    REALLOC_IX(struct tmp_schema *, *schemas, *num_schemas);
    if ((tmp = confd_malloc(sizeof(struct tmp_schema))) == NULL)
        return CONFD_ERR;
    memset(tmp, 0, sizeof(struct tmp_schema));
    /* tmp->uri == NULL indicates not-yet-loaded ns */
    tmp->nshash = nshash;
    tmp->type_hash = create_hashtable(16, str2hash_hashfromkey,
                                      str2hash_equalkeys);
    (*schemas)[(*num_schemas)++] = tmp;
    *found = tmp;
    return CONFD_OK;
}

static int find_tmp_type(struct confd_type **found, ETERM *name,
                         struct tmp_schema *cur)
{
    struct named_type *tmp;

    if ((*found = hashtable_search(cur->type_hash, ERL_ATOM_PTR(name))) != NULL)
        return CONFD_OK;
    REALLOC_IX(struct named_type, cur->types, cur->num_types);
    tmp = &(cur->types)[(cur->num_types)++];
    if ((tmp->name = s_bin_dup(name)) == NULL)
        return CONFD_ERR;
    if ((tmp->type = type_alloc(sizeof(struct confd_type))) == NULL)
        return CONFD_ERR;
    tmp->type->opaque = (void *)-1; /* "magic" for not-yet-loaded type def */
    hashtable_insert(cur->type_hash, tmp->name, tmp->type);
    *found = tmp->type;
    return CONFD_OK;
}

static int get_type(struct confd_type **type, u_int32_t ns, ETERM *name,
                    struct tmp_schema ***schemas,
                    int *schemas_len, int *num_schemas)
{
    int size = ERL_ATOM_SIZE(name) + 1;

    if (ns == 0) {
        /* xs: or confd: type - "global" lookup, must succeed */
        char str_name[size];

        bin_copy(str_name, sizeof(str_name), name);
        if ((*type = s_find_type(str_name)) == NULL) {
            /* FIXME: some xs/confd types are not supported yet
               - don't fail the whole load_schemas b/c of them
               (hexValue "doesn't really exist" but was used for
                confd_dyncfg.cs) */
            if (strcmp(str_name, "anyURI") != 0 &&    /* maybe FIXME */
                strcmp(str_name, "QName") != 0 &&     /* maybe FIXME */
                strcmp(str_name, "objectRef") != 0 && /* probably FIXME */
                strcmp(str_name, "hexValue") != 0 &&  /* never FIXME */
                strcmp(str_name, "identityref") != 0) /* really FIXME */
                return ret_err(CONFD_ERR_INTERNAL,
                               "Unknown type 0:%s", str_name);
        }
    } else {
        /* ns-specific type - schema and/or type may not be loaded yet,
           in which case find_tmp_schema()/find_tmp_type() will create
           "placeholders" - we only require that the struct confd_type
           stays in the same place */
        struct tmp_schema *schema;

        OK(find_tmp_schema(&schema, ns, schemas, schemas_len, num_schemas));
        OK(find_tmp_type(type, name, schema));
    }
    return CONFD_OK;
}

typedef int (*str_to_val_t)(struct confd_type *self,
                            struct confd_type_ctx *ctx,
                            const char *str, unsigned int len,
                            confd_value_t *v);
typedef int (*val_to_str_t)(struct confd_type *self,
                            struct confd_type_ctx *ctx,
                            const confd_value_t *v,
                            char *str, unsigned int len,
                            const char **strp);
typedef int (*validate_t)(struct confd_type *self,
                          struct confd_type_ctx *ctx,
                          const confd_value_t *v);

static str_to_val_t str_to_val_funcs[] = {
    NULL,                       /* can't use index 0 */
#define CONFD_BITS_STR_TO_VAL 1
    confd_bits_str_to_val,
#define CONFD_DECIMAL64_STR_TO_VAL 2
    confd_decimal64_str_to_val,
#define CONFD_ENUM_STR_TO_VAL 3
    confd_enum_str_to_val,
#define CONFD_LIST_STR_TO_VAL 4
    confd_list_str_to_val,
#define CONFD_UNION_STR_TO_VAL 5
    confd_union_str_to_val,
#define CONFD_IDREF_STR_TO_VAL 6
    confd_idref_str_to_val
};
static int n_str_to_val_funcs =
    sizeof(str_to_val_funcs)/sizeof(str_to_val_funcs[0]);

static str_to_val_t s_str_to_val_funcs[] = {
    NULL,
    confd_bits_str_to_val,
    confd_decimal64_str_to_val,
    confd_enum_str_to_val,
    confd_list_str_to_val,
    confd_union_str_to_val,
    confd_idref_str_to_val
};

static val_to_str_t val_to_str_funcs[] = {
    NULL,
#define CONFD_BITS_VAL_TO_STR 1
    confd_bits_val_to_str,
#define CONFD_DECIMAL64_VAL_TO_STR 2
    confd_decimal64_val_to_str,
#define CONFD_ENUM_VAL_TO_STR 3
    confd_enum_val_to_str,
#define CONFD_LIST_VAL_TO_STR 4
    confd_list_val_to_str,
#define CONFD_UNION_VAL_TO_STR 5
    confd_union_val_to_str,
#define CONFD_IDREF_VAL_TO_STR 6
    confd_idref_val_to_str
};
static int n_val_to_str_funcs =
    sizeof(val_to_str_funcs)/sizeof(val_to_str_funcs[0]);

static val_to_str_t s_val_to_str_funcs[] = {
    NULL,
    confd_bits_val_to_str,
    confd_decimal64_val_to_str,
    confd_enum_val_to_str,
    confd_list_val_to_str,
    confd_union_val_to_str,
    confd_idref_val_to_str
};

static validate_t validate_funcs[] = {
    NULL,
#define CONFD_BITS_VALIDATE 1
    confd_bits_validate,
#define CONFD_DECIMAL64_VALIDATE 2
    confd_decimal64_validate,
#define CONFD_ENUM_VALIDATE 3
    confd_enum_validate,
#define CONFD_LIST_VALIDATE 4
    confd_list_validate,
#define CONFD_UNION_VALIDATE 5
    confd_union_validate,
#define CONFD_TYPE_VALIDATE_LIST_RESTRICTION 6
    confd_type_validate_list_restriction,
#define CONFD_TYPE_VALIDATE_NUMBER_RESTRICTION 7
    confd_type_validate_number_restriction,
#define CONFD_TYPE_VALIDATE_STRING_RESTRICTION 8
    confd_type_validate_string_restriction,
#define CONFD_IDREF_VALIDATE 9
    confd_idref_validate
};
static int n_validate_funcs =
    sizeof(validate_funcs)/sizeof(validate_funcs[0]);

static validate_t s_validate_funcs[] = {
    NULL,
    confd_bits_validate,
    confd_decimal64_validate,
    confd_enum_validate,
    confd_list_validate,
    confd_union_validate,
    confd_type_validate_list_restriction,
    confd_type_validate_number_restriction,
    confd_type_validate_string_restriction,
    confd_idref_validate
};

/* Format of 'type' records sent from confd:

 {type, Derivation, Name, ParentNs, ParentName, Opaque}

 Derivation = enum | idref | bits | union | list | number | string |
              list_restr | decimal64 | identity | none
 Name = atom()
 ParentNs = integer() (0 if xs: or confd: or no parent)
 ParentName = atom() ('' if no parent)
 Opaque = if enum:       [{Enum::binary(), Id::integer()}]
             idref:      [{Qname::binary(), Ns::integer(), Id::integer()}]
             bits:       {Width::integer(), [{Label::binary(), Bit:integer()}]}
             union:      [MemberType]
             list:       ElemType
             number:     [Range]
             string:     {[LengthRange], Regexp}
             list_restr: [LenghtRange]
             decimal64:  {FractionDigits, [Range]}
             identity:   []
             none:       []
 MemberType = ElemType = {Ns::integer(), Name::atom()}
 Range = {Lo:Value, Hi:Value, Flags}
 LengthRange = {Lo:Value, Hi:Value}
 Regexp = binary() | []

*/
static int load_type(struct confd_type *type, ETERM *term,
                     struct tmp_schema ***schemas,
                     int *schemas_len, int *num_schemas)
{
    char derivation[32];
    ETERM *parent_name;
    u_int32_t parent_ns;
    ETERM *hd, *tl;

    type->opaque = NULL;        /* clear not-yet-loaded "magic" */
    bin_copy(derivation, sizeof(derivation), TE(term, 1));
    parent_name = TE(term, 4);
    if (ERL_ATOM_SIZE(parent_name) != 0) {
        parent_ns = TUINT(term, 3);
        OK(get_type(&type->parent, parent_ns, parent_name,
                    schemas, schemas_len, num_schemas));
    }

    if (strcmp(derivation, "none") == 0) {
        /* user-defined type
           - set up as "identity" with always-failing parent
           - user can register, replacing parent */
        type->parent = s_find_type("NO_TYPE");
        type->opaque = (void *)CONFD_TYPE_USER; /* magic for user-defined */
    } else if (strcmp(derivation, "enum") == 0) {
        struct confd_type_enums *enums;
        struct confd_type_enum *enm;

        type->str_to_val = s_str_to_val_funcs[CONFD_ENUM_STR_TO_VAL];
        type->val_to_str = s_val_to_str_funcs[CONFD_ENUM_VAL_TO_STR];
        type->validate = s_validate_funcs[CONFD_ENUM_VALIDATE];
        if ((enums = s_malloc(sizeof(struct confd_type_enums))) == NULL)
            return CONFD_ERR;
        tl = TE(term, 5);
        enums->enm_len = erl_length(tl);
        if ((enm = s_malloc(enums->enm_len *
                            sizeof(struct confd_type_enum))) == NULL)
            return CONFD_ERR;
        enums->enm = enm;
        while (!ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if ((enm->name = s_bin_dup(TE(hd, 0))) == NULL)
                return CONFD_ERR;
            enm->len = ERL_BIN_SIZE(TE(hd, 0));
            enm->val = TUINT(hd, 1);
            enm++;
        }
        type->opaque = enums;

    } else if (strcmp(derivation, "idref") == 0) {
        struct confd_type_idrefs *idrefs;
        struct confd_type_idref *idr, *idr_uc;

        type->str_to_val = s_str_to_val_funcs[CONFD_IDREF_STR_TO_VAL];
        type->val_to_str = s_val_to_str_funcs[CONFD_IDREF_VAL_TO_STR];
        type->validate = s_validate_funcs[CONFD_IDREF_VALIDATE];
        if ((idrefs = s_malloc(sizeof(struct confd_type_idrefs))) == NULL)
            return CONFD_ERR;
        tl = TE(term, 5);
        idrefs->idr_len = erl_length(tl);
        if ((idr = s_malloc(idrefs->idr_len *
                            sizeof(struct confd_type_idref))) == NULL)
            return CONFD_ERR;
        idrefs->idr = idr;
        while (!ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if ((idr->qname = s_bin_dup(TE(hd, 0))) == NULL)
                return CONFD_ERR;
            idr->name = strchr(idr->qname, ':') + 1;
            idr->idref.ns = TUINT(hd, 1);
            idr->idref.id = TUINT(hd, 2);
            for (idr_uc = idrefs->idr; idr_uc < idr; idr_uc++) {
                if (idr_uc->idref.id == idr->idref.id) {
                    /* not unique */
                    idr_uc->name = idr_uc->qname;
                    idr->name = idr->qname;
                    break;
                }
            }
            idr++;
        }
        type->opaque = idrefs;

    } else if (strcmp(derivation, "bits") == 0) {
        ETERM *opaque;
        struct confd_type_bits *bits;
        struct confd_type_bit *bit;

        type->str_to_val = s_str_to_val_funcs[CONFD_BITS_STR_TO_VAL];
        type->val_to_str = s_val_to_str_funcs[CONFD_BITS_VAL_TO_STR];
        type->validate = s_validate_funcs[CONFD_BITS_VALIDATE];
        if ((bits = s_malloc(sizeof(struct confd_type_bits))) == NULL)
            return CONFD_ERR;
        opaque = TE(term, 5);
        bits->width = TINT(opaque, 0);
        tl = TE(opaque, 1);
        bits->bit_len = erl_length(tl);
        if ((bit = s_malloc(bits->bit_len *
                            sizeof(struct confd_type_bit))) == NULL)
            return CONFD_ERR;
        bits->bit = bit;
        while (!ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if ((bit->name = s_bin_dup(TE(hd, 0))) == NULL)
                return CONFD_ERR;
            bit->len = ERL_BIN_SIZE(TE(hd, 0));
            if (bits->width <= 64) {
                /* bitmask */
                bit->value = (1ULL << TUINT(hd, 1));
            } else {
                /* position */
                bit->value = TUINT(hd, 1);
            }
            bit++;
        }
        type->opaque = bits;

    } else if (strcmp(derivation, "decimal64") == 0) {
        ETERM *opaque;
        struct confd_type_decimal64 *d64;
        struct confd_range *range;
        type->str_to_val = s_str_to_val_funcs[CONFD_DECIMAL64_STR_TO_VAL];
        type->val_to_str = s_val_to_str_funcs[CONFD_DECIMAL64_VAL_TO_STR];
        type->validate = s_validate_funcs[CONFD_DECIMAL64_VALIDATE];
        if ((d64 = s_malloc(sizeof(struct confd_type_decimal64))) == NULL)
            return CONFD_ERR;
        opaque = TE(term, 5);
        d64->fraction_digits = TUINT(opaque, 0);
        tl = TE(opaque, 1);
        d64->nr.range_len = erl_length(tl);
        if (d64->nr.range_len > 0) {
            if ((range = s_malloc(d64->nr.range_len *
                                  sizeof(struct confd_range))) == NULL)
                return CONFD_ERR;
            d64->nr.range = range;
            while (!ERL_IS_EMPTY_LIST(tl)) {
                hd = ERL_CONS_HEAD(tl);
                tl = ERL_CONS_TAIL(tl);
                if (eterm_to_val(TE(hd, 0), &range->lo) == NULL ||
                    eterm_to_val(TE(hd, 1), &range->hi) == NULL)
                    return CONFD_ERR;
                range->flags = TINT(hd, 2);
                range++;
            }
        }
        type->opaque = d64;

    } else if (strcmp(derivation, "union") == 0) {
        struct confd_type_union *uni;
        struct confd_type_member_type *member;
        int member_ns;
        ETERM *member_name;

        type->str_to_val = s_str_to_val_funcs[CONFD_UNION_STR_TO_VAL];
        type->val_to_str = s_val_to_str_funcs[CONFD_UNION_VAL_TO_STR];
        type->validate = s_validate_funcs[CONFD_UNION_VALIDATE];
        if ((uni = s_malloc(sizeof(struct confd_type_union))) == NULL)
            return CONFD_ERR;
        tl = TE(term, 5);
        uni->member_type_len = erl_length(tl);
        if ((member = s_malloc(uni->member_type_len *
                               sizeof(struct confd_type_member_type))) == NULL)
            return CONFD_ERR;
        uni->member_type = member;
        while (!ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            member_ns = TUINT(hd, 0);
            member_name = TE(hd, 1);
            OK(get_type(&member->type, member_ns, member_name,
                        schemas, schemas_len, num_schemas));
            member++;
        }
        type->opaque = uni;

    } else if (strcmp(derivation, "list") == 0) {
        struct confd_type_list *list;
        int member_ns;
        ETERM *member_name;

        type->str_to_val = s_str_to_val_funcs[CONFD_LIST_STR_TO_VAL];
        type->val_to_str = s_val_to_str_funcs[CONFD_LIST_VAL_TO_STR];
        type->validate = s_validate_funcs[CONFD_LIST_VALIDATE];
        if ((list = s_malloc(sizeof(struct confd_type_list))) == NULL)
            return CONFD_ERR;
        member_ns = TUINT(TE(term, 5), 0);
        member_name = TE(TE(term, 5), 1);
        OK(get_type(&list->type, member_ns, member_name,
                    schemas, schemas_len, num_schemas));
        type->opaque = list;

    } else if (strcmp(derivation, "number") == 0) {
        struct confd_type_number_restriction *number;
        struct confd_range *range;

        type->validate =
            s_validate_funcs[CONFD_TYPE_VALIDATE_NUMBER_RESTRICTION];
        if ((number = s_malloc(
                 sizeof(struct confd_type_number_restriction))) == NULL)
            return CONFD_ERR;
        tl = TE(term, 5);
        number->range_len = erl_length(tl);
        if ((range = s_malloc(number->range_len *
                              sizeof(struct confd_range))) == NULL)
            return CONFD_ERR;
        number->range = range;
        while (!ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if (eterm_to_val(TE(hd, 0), &range->lo) == NULL ||
                eterm_to_val(TE(hd, 1), &range->hi) == NULL)
                return CONFD_ERR;
            range->flags = TINT(hd, 2);
            range++;
        }
        type->opaque = number;

    } else if (strcmp(derivation, "string") == 0) {
        ETERM *opaque;
        struct confd_type_string_restriction *string;
        struct confd_length *length;

        type->validate =
            s_validate_funcs[CONFD_TYPE_VALIDATE_STRING_RESTRICTION];
        if ((string = s_malloc(
                 sizeof(struct confd_type_string_restriction))) == NULL)
            return CONFD_ERR;
        opaque = TE(term, 5);
        tl = TE(opaque, 0);
        string->length_len = erl_length(tl);
        if (string->length_len > 0) {
            if ((length = s_malloc(string->length_len *
                                   sizeof(struct confd_length))) == NULL)
                return CONFD_ERR;
            string->length = length;
            while (!ERL_IS_EMPTY_LIST(tl)) {
                hd = ERL_CONS_HEAD(tl);
                tl = ERL_CONS_TAIL(tl);
                if (eterm_to_val(TE(hd, 0), &length->lo) == NULL ||
                    eterm_to_val(TE(hd, 1), &length->hi) == NULL)
                    return CONFD_ERR;
                length++;
            }
        }
#if HAVE_REGEX_H
        if (ERL_IS_BINARY(TE(opaque, 1))) {
            int size = ERL_BIN_SIZE(TE(opaque, 1));
            int patsize = size + 5; /* "^(" + ")$" + NUL */
            char *pat = s_malloc(patsize);
            if (pat == NULL)
                return CONFD_ERR;
            snprintf(pat, patsize, "^(%.*s)$",
                     size, ERL_BIN_PTR(TE(opaque, 1)));
            string->pattern.text = pat;
            string->has_pattern = 2;
        } else {
            string->has_pattern = 0;
        }
#else
        string->has_pattern = 0;
#endif  /* HAVE_REGEX_H */
        type->opaque = string;

    } else if (strcmp(derivation, "list_restr") == 0) {
        struct confd_type_list_restriction *list;
        struct confd_length *length;

        type->validate = s_validate_funcs[CONFD_TYPE_VALIDATE_LIST_RESTRICTION];
        if ((list = s_malloc(
                 sizeof(struct confd_type_list_restriction))) == NULL)
            return CONFD_ERR;
        tl = TE(term, 5);
        list->length_len = erl_length(tl);
        if ((length = s_malloc(list->length_len *
                               sizeof(struct confd_length))) == NULL)
            return CONFD_ERR;
        list->length = length;
        while (!ERL_IS_EMPTY_LIST(tl)) {
            hd = ERL_CONS_HEAD(tl);
            tl = ERL_CONS_TAIL(tl);
            if (eterm_to_val(TE(hd, 0), &length->lo) == NULL ||
                eterm_to_val(TE(hd, 1), &length->hi) == NULL)
                return CONFD_ERR;
            length++;
        }
        type->opaque = list;

    } else if (strcmp(derivation, "identity") == 0) {
        /* nothing to do
           - confd_type_init_type() will set up the callbacks */

    } else {
        return ret_err(CONFD_ERR_INTERNAL, "Unknown type derivation %s",
                       derivation);
    }

    return CONFD_OK;
}

static struct confd_cs_meta_data *get_meta_data(ETERM *argl)
{
    int i, n;
    struct confd_cs_meta_data *md;
    ETERM *arg;

    if (ERL_IS_LIST(argl) && erl_length(argl) > 0) {
        n = erl_length(argl);
    } else {
        /* atom 'undefined' */
        return NULL;
    }
    if ((md = s_malloc((n + 1) * sizeof(struct confd_cs_meta_data))) == NULL) {
        return NULL;
    }
    for (i = 0; i < n; i++) {
        arg = ERL_CONS_HEAD(argl);
        md[i].key = s_bin_dup(TE(arg, 0));
        if (ERL_IS_ATOM(TE(arg, 1))) {
            /* atom 'undefined' */
            md[i].value = NULL;
        } else {
            md[i].value = s_bin_dup(TE(arg, 1));
        }
        argl = ERL_CONS_TAIL(argl);
    }
    md[i].key = NULL;
    md[i].value = NULL;
    return md;
}

/* Format of non-'type' records sent from confd:

   {keys, KeyN::integer(), [KeyTagHash::integer()]}

   {case, ParentNodeN::integer(), CaseN::integer(),
    TagHash::integer(), NsHash::integer(),
    FirstNodeN::integer(), LastNodeN::integer(),
    NextCaseN::integer(), FirstChoiceN::integer()}

   {choice, ParentNodeN::integer(), ChoiceN::integer(),
    TagHash::integer(), NsHash::integer(),
    MinOccurs::integer(), DefaultCaseN::integer(),
    FirstCaseN::integer(), NextChoiceN::integer()}

   {node, NodeN::integer(), TagHash::integer(), NsHash::integer(),
    KeyN::integer(), MinOccurs::integer(), MaxOccurs::integer(),
    PrimType::integer(), TypeNsHash::integer(), TypeName::atom(),
    DefVal::term(), Flags::integer(), FirstChildN::integer(),
    NextNodeN::integer(), FirstChoiceN::integer(), Cmp::integer()
    MetaData::[{binary(), binary()|undefined}]}

   {root, RootNodeN::integer()}

   {parent, [{NodeN:integer(), ParentNodeN::integer()}]}

   {notree}

   NodeN is unique within Ns.

   ChoiceN, CaseN are unique within parent Node.

   Ns ends with 'parent' or 'notree' record.
*/

static int load_one_ns(int sock, struct tmp_schema *cur,
                       struct tmp_schema ***schemas,
                       int *schemas_len, int *num_schemas)
{
    int ret;
    int done = 0;
    ETERM *term, *rectype;
    struct confd_cs_node **nodes = NULL;
    int nodes_len = 0;
    u_int32_t **keyarrs = NULL;
    int keyarrs_len = 0;
    struct confd_cs_choice **choices = NULL;
    int choices_len = 0;
    struct confd_cs_case **cases = NULL;
    int cases_len = 0;
    ETERM *type_name;
    struct confd_type *type;
    confd_value_t defval;

    memset(&defval, 0, sizeof(defval)); /* keep valgrind happy with msync() */

    while (!done) {
        if ((term = term_read_list(sock, &ret)) == NULL)
            return ret;
        rectype = TE(term, 0);

        if (bin_eq(rectype, "type")) {
            type_name = TE(term, 2);
            OK(find_tmp_type(&type, type_name, cur));
            OK(load_type(type, term, schemas, schemas_len, num_schemas));

        } else if (bin_eq(rectype, "keys")) {
            int kn = TINT(term, 1);
            ETERM *hd;
            ETERM *tl = TE(term, 2);
            u_int32_t *keyarr =
                s_malloc((erl_length(tl) + 1) * sizeof(u_int32_t));
            u_int32_t *kp = keyarr;

            if (keyarr == NULL)
                return CONFD_ERR;
            while (!ERL_IS_EMPTY_LIST(tl)) {
                hd = ERL_CONS_HEAD(tl);
                tl = ERL_CONS_TAIL(tl);
                *kp++ = ERL_INT_UVALUE(hd);
            }
            *kp = 0;
            REALLOC_IX(u_int32_t *, keyarrs, kn);
            keyarrs[kn] = keyarr;

        } else if (bin_eq(rectype, "case")) {
            int cn = TINT(term, 2); /* 1 is node #, we don't care */
            struct confd_cs_case *case0 =
                s_calloc(sizeof(struct confd_cs_case));
            int first, last, next, choice;
            struct confd_cs_choice *cp;

            if (case0 == NULL)
                return CONFD_ERR;
            case0->tag = TUINT(term, 3);
            case0->ns = TUINT(term, 4);
            if ((first = TINT(term, 5)) != 0)
                case0->first = nodes[first];
            if ((last = TINT(term, 6)) != 0)
                case0->last = nodes[last];
            if ((next = TINT(term, 7)) != 0)
                case0->next = cases[next];
            if (ERL_TUPLE_SIZE(term) > 8 && (choice = TINT(term, 8)) != 0) {
                case0->choices = choices[choice];
                for (cp = case0->choices; cp != NULL; cp = cp->next)
                    cp->case_parent = case0;
            }
            REALLOC_IX(struct confd_cs_case *, cases, cn);
            cases[cn] = case0;

        } else if (bin_eq(rectype, "choice")) {
            int cn = TINT(term, 2); /* 1 is node #, we don't care */
            struct confd_cs_choice *choice =
                s_calloc(sizeof(struct confd_cs_choice));
            int default_case, case0, next;
            struct confd_cs_case *cp;

            if (choice == NULL)
                return CONFD_ERR;
            choice->tag = TUINT(term, 3);
            choice->ns = TUINT(term, 4);
            choice->minOccurs = TUINT(term, 5);
            if ((default_case = TINT(term, 6)) != 0)
                choice->default_case = cases[default_case];
            if ((case0 = TINT(term, 7)) != 0) {
                choice->cases = cases[case0];
                for (cp = choice->cases; cp != NULL; cp = cp->next)
                    cp->parent = choice;
            }
            if ((next = TINT(term, 8)) != 0)
                choice->next = choices[next];
            REALLOC_IX(struct confd_cs_choice *, choices, cn);
            choices[cn] = choice;

        } else if (bin_eq(rectype, "node")) {
            int nn = TINT(term, 1);
            struct confd_cs_node *node =
                s_calloc(sizeof(struct confd_cs_node));
            int keyref, child, next, type_ns, choice;
            struct confd_cs_choice *cp;

            if (node == NULL)
                return CONFD_ERR;
            node->tag = TUINT(term, 2);
            node->ns = TUINT(term, 3);
            if ((keyref = TINT(term, 4)) != 0)
                node->info.keys = keyarrs[keyref];
            node->info.minOccurs = TINT(term, 5);
            node->info.maxOccurs = TINT(term, 6);
            node->info.shallow_type = (enum confd_vtype)TINT(term, 7);
            type_name = TE(term, 9);
            if (ERL_ATOM_SIZE(type_name) == 0) {
                node->info.type = NULL;
            } else {
                type_ns = TUINT(term, 8);
                OK(get_type(&node->info.type, type_ns, type_name,
                            schemas, schemas_len, num_schemas));
            }
            if (eterm_to_val(TE(term, 10), &defval) == NULL)
                return CONFD_ERR;
            if (defval.type != C_NOEXISTS) {
                node->info.defval = s_malloc(sizeof(confd_value_t));
                if (node->info.defval == NULL)
                    return CONFD_ERR;
                confd_value_dup_to_mallf(&defval, node->info.defval,
                                         s_malloc, s_free);
                confd_free_eterm_val(&defval);
            }
            node->info.flags = TUINT(term, 11);
            if ((child = TINT(term, 12)) != 0)
                node->children = nodes[child];
            if ((next = TINT(term, 13)) != 0)
                node->next = nodes[next];
            if ((choice = TINT(term, 14)) != 0) {
                node->info.choices = choices[choice];
                for (cp = node->info.choices; cp != NULL; cp = cp->next)
                    cp->parent = node;
            }
            node->info.cmp = TUINT(term, 15);
            node->info.meta_data = get_meta_data(TE(term, 16));
            REALLOC_IX(struct confd_cs_node *, nodes, nn);
            nodes[nn] = node;

        } else if (bin_eq(rectype, "root")) {
            int rn = TINT(term, 1);

            if (rn == 0)
                cur->root = NULL;
            else
                cur->root = nodes[rn];

        } else if (bin_eq(rectype, "parent")) {
            ETERM *hd;
            ETERM *tl = TE(term, 1);
            int nn, parent;

            while (!ERL_IS_EMPTY_LIST(tl)) {
                hd = ERL_CONS_HEAD(tl);
                tl = ERL_CONS_TAIL(tl);
                if (ERL_IS_INTEGER(TE(hd, 1))) {
                    nn = TINT(hd, 0);
                    parent = TINT(hd, 1);
                    nodes[nn]->parent = nodes[parent];
                }
            }
            cur->loaded = 1;
            done = 1;
        } else if (bin_eq(rectype, "notree")) {
            done = 1;
        }

        free_list_term(term);
    }

    if (keyarrs != NULL)
        free(keyarrs);
    if (cases != NULL)
        free(cases);
    if (choices != NULL)
        free(choices);
    if (nodes != NULL)
        free(nodes);
    return ret;
}

#define UPDATE_TYPE_PTR(func) do {                              \
        if (type->func != NULL &&                               \
            (uintptr_t)type->func < n_ ## func ## _funcs)       \
            type->func = func ## _funcs[(uintptr_t)type->func]; \
    } while (0)

static int load_many_ns(int sock)
{
    int ret = CONFD_OK, read_ret;
    ETERM *term;
    u_int32_t ns;
    struct tmp_schema **schemas = NULL;
    int schemas_len = 0;
    int num_schemas = 0;
    struct tmp_schema *cur;
    int i, j;
    struct schema *new;
    int num_loaded;

    while (ret == CONFD_OK ||
           (ret == CONFD_ERR && confd_errno != CONFD_ERR_INTERNAL)) {
        if ((term = term_read_list(sock, &read_ret)) == NULL)
            return read_ret;
        if (ERL_IS_ATOM(term) && bin_eq(term, "eof")) {
            free_list_term(term);
            break;
        }
        if (ret != CONFD_OK)
            continue;
        if (!bin_eq(TE(term, 0), "ns")) {
            free_list_term(term);
            ret = ret_err(CONFD_ERR_INTERNAL, "Bad schema data");
            continue;
        }
        ns = TUINT(term, 3);
        ret = find_tmp_schema(&cur, ns, &schemas, &schemas_len, &num_schemas);
        if (ret != CONFD_OK)
            continue;
        if (cur->uri == NULL) { /* may be extra load due to type references */
            if ((cur->uri = s_bin_dup(TE(term, 1))) == NULL ||
                (cur->prefix = s_bin_dup(TE(term, 2))) == NULL)
                ret = CONFD_ERR;
            if (ERL_TUPLE_SIZE(term) > 4 && ERL_IS_BINARY(TE(term, 4))) {
                if ((cur->revision = s_bin_dup(TE(term, 4))) == NULL)
                    ret = CONFD_ERR;
            } else {
                cur->revision = NULL;
            }
            if (ERL_TUPLE_SIZE(term) > 5 && ERL_IS_BINARY(TE(term, 5))) {
                if ((cur->module = s_bin_dup(TE(term, 5))) == NULL)
                    ret = CONFD_ERR;
            } else {
                cur->module = NULL;
            }
        }
        free_list_term(term);
        if (ret != CONFD_OK)
            continue;
        ret = load_one_ns(sock, cur, &schemas, &schemas_len, &num_schemas);
    }

    if (ret != CONFD_OK)
        return ret;

    /* cleanup and sanity checks */
    for (i = 0; i < num_schemas; i++) {
        cur = schemas[i];
        if (cur->uri == NULL) {
            /* schema was created due to type reference but never loaded
               - there must be at least one not-yet-loaded type, use
               the first one for the error msg */
            return ret_err(CONFD_ERR_INTERNAL,
                   "Reference to type %s in unknown ns %d",
                   cur->types[0].name, cur->nshash);
        }
        /* FIXME? We could keep the hashtables / copy them to shm instead
           of using the arrays - or at least build the arrays from the
           hashtables here instead of piece-wise in find_tmp_type() */
        hashtable_destroy(cur->type_hash, 0);
        if (cur->num_types > 0) {
            for (j = 0; j < cur->num_types; j++) {
                if (cur->types[j].type->opaque == (void *)-1) {
                    /* type created due to type reference but never loaded */
                    return ret_err(CONFD_ERR_INTERNAL,
                                   "Reference to unknown type %s in ns %d",
                                   cur->types[j].name, cur->nshash);
                }
            }
            if (shm_si == NULL) {
                /* truncate to used length */
                cur->types =
                    realloc(cur->types,
                            cur->num_types * sizeof(struct named_type));
            } else {
                /* copy used length to shm */
                struct named_type *tmp =
                    s_malloc(cur->num_types * sizeof(struct named_type));
                if (tmp == NULL)
                    return CONFD_ERR;
                memcpy(tmp, cur->types,
                       cur->num_types * sizeof(struct named_type));
                free(cur->types);
                cur->types = tmp;
            }
        }
    }

    if ((new = s_malloc(num_schemas * sizeof(struct schema))) == NULL)
        return CONFD_ERR;
    num_loaded = 0;
    for (i = 0; i < num_schemas; i++) {
        cur = schemas[i];
        if (shm_si == NULL) {
            for (j = 0; j < cur->num_types; j++)
                confd_type_init_type(cur->types[j].type);
        }
        new[i].nshash = cur->nshash;
        new[i].uri = cur->uri;
        new[i].prefix = cur->prefix;
        new[i].revision = cur->revision;
        new[i].module = cur->module;
        new[i].root = cur->root;
        new[i].loaded = cur->loaded;
        if (new[i].loaded)
            num_loaded++;
        new[i].types = cur->types;
        new[i].num_types = cur->num_types;
        free(cur);
    }
    free(schemas);
    if (shm_si == NULL) {
        confd_register_schemas(new, num_schemas, num_loaded, 0);
    } else {
        shm_si->schemas = new;
        shm_si->nschemas = num_schemas;
        shm_si->nschemas_listed = num_loaded;
    }
    return ret;
}

static int load_all_ns(int sock)
{
    int ret;

    confd_trace(CONFD_TRACE, "MAAPI_LOAD_ALL_NS\n");
    if ((ret = op_write(sock, MAAPI_LOAD_ALL_NS, -1)) == CONFD_OK)
        ret = load_many_ns(sock);
    return ret;
}

static int load_ns_list(int sock, int flags,
                        const u_int32_t *nshash, const int *nsflags,
                        int num_ns)
{
    ETERM *nslist[num_ns];
    ETERM *nstup[2];
    ETERM *tup[2];
    ETERM *req;
    int i, ret;

    tup[0] = erl_mk_int(flags);
    for (i = 0; i < num_ns; i++) {
        nstup[0] = erl_mk_uint(nshash[i]);
        nstup[1] = erl_mk_int(nsflags[i]);
        nslist[i] = erl_mk_tuple(nstup, 2);
    }
    tup[1] = erl_mk_list(nslist, num_ns);
    req = erl_mk_tuple(tup, 2);
    confd_trace(CONFD_TRACE, "MAAPI_LOAD_NS_LIST\n");
    ret = term_write(sock, req, MAAPI_LOAD_NS_LIST, -1);
    erl_free_compound(req);
    if (ret == CONFD_OK)
        ret = load_many_ns(sock);
    return ret;
}

static int finish_mmap(int ret)
{
    int p;
    size_t new_size = shm_filesize;

    if (shm_base == NULL)
        return ret;
    if (shm_si == NULL) {
        /* this means that we *were* using mmap,
           but current load did not */
        munmap(shm_base, shm_mapped);
        shm_base = NULL;
        return ret;
    }
    /* trim what is unused due to SCHEMA_SIZE_INC from file size */
    if (shm_size == 0) {
        if (shm_used <= shm_page_start)
            shm_used = shm_page_end;
        while (new_size - pagesize >= shm_used) {
            new_size -= pagesize;
        }
        if (new_size != shm_filesize) {
            if (ftruncate(shm_fd, new_size) == 0) {
                shm_filesize = new_size;
            }
        }
    }
    /* make sure shm is synced with file system cache */
    if (ret == CONFD_OK && msync(shm_base, shm_filesize, MS_ASYNC) != 0)
        ret = ret_err(CONFD_ERR_OS, "Failed to msync(): %s", strerror(errno));
    munmap(shm_base, shm_mapped);
    close(shm_fd);
    shm_base = shm_si = NULL;
    s_malloc = confd_malloc;
    s_page_alloc = confd_malloc;
    s_free = free;
    s_find_type = confd_find_type;
    for (p = 0; p < n_str_to_val_funcs; p++)
        s_str_to_val_funcs[p] = str_to_val_funcs[p];
    for (p = 0; p < n_val_to_str_funcs; p++)
        s_val_to_str_funcs[p] = val_to_str_funcs[p];
    for (p = 0; p < n_validate_funcs; p++)
        s_validate_funcs[p] = validate_funcs[p];
    return ret;
}

int maapi_load_schemas(int sock)
{
    int ret;

    clr_confd_err();
    PTHREAD_MUTEX_LOCK(&maapi_load_schemas_lock);
    if ((ret = load_all_ns(sock)) == CONFD_OK)
        ret = load_hash_db(sock);
    if (ret != CONFD_OK)
        free_list_all();
    ret = finish_mmap(ret);
    PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
    return ret;
}

int maapi_load_schemas_list(int sock, int flags,
                            const u_int32_t *nshash, const int *nsflags,
                            int num_ns)
{
    int ret;

    clr_confd_err();
    PTHREAD_MUTEX_LOCK(&maapi_load_schemas_lock);
    if ((ret = load_ns_list(sock, flags, nshash, nsflags, num_ns)) == CONFD_OK
        && (flags & CONFD_LOAD_SCHEMA_HASH) != 0)
        ret = load_hash_db(sock);
    if (ret != CONFD_OK)
        free_list_all();
    ret = finish_mmap(ret);
    PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
    return ret;
}

static void do_free_schemas(int only_if_mmapped)
{
    int doit = (shm_base != NULL) || !only_if_mmapped;

    if (doit) {
        confd_register_schemas(NULL, 0, 0, 0);
        replace_hashtables(NULL, NULL, 0);
    }
    if (shm_base != NULL) {
        munmap(shm_base, shm_mapped);
        shm_base = shm_si = NULL;
    }
}

int confd_mmap_schemas_setup(void *addr, size_t size,
                             const char *filename, int flags)
{
    uintptr_t p;
    int fd;

    clr_confd_err();
    if (size == 0 && (flags & CONFD_MMAP_SCHEMAS_KEEP_SIZE) != 0)
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Can't give CONFD_MMAP_SCHEMAS_KEEP_SIZE "
                       "when size == 0");
    if ((flags & CONFD_MMAP_SCHEMAS_FIXED_ADDR) != 0) {
#ifndef MAP_FIXED
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Can't give CONFD_MMAP_SCHEMAS_FIXED_ADDR "
                       "when OS mmap() does not support MAP_FIXED");
#endif
        if (addr == NULL)
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Can't give CONFD_MMAP_SCHEMAS_FIXED_ADDR "
                           "when addr == NULL");
    }
    if ((pagesize = (size_t)sysconf(_SC_PAGESIZE)) == -1) {
        return ret_err(CONFD_ERR_OS, "Failed to obtain page size: %s",
                       strerror(errno));
    }
    if ((fd = open(filename, O_RDWR|O_CREAT|O_TRUNC, 0666)) < 0) {
        return ret_err(CONFD_ERR_OS, "Failed to open %s: %s",
                       filename, strerror(errno));
    }
    PTHREAD_MUTEX_LOCK(&maapi_load_schemas_lock);
    do_free_schemas(1);
    shm_fd = fd;
    shm_filesize = 0;
    shm_base = addr;
    shm_size = size;
    shm_keepsize = (flags & CONFD_MMAP_SCHEMAS_KEEP_SIZE) != 0;
    shm_flags = 0;
    if ((flags & CONFD_MMAP_SCHEMAS_FIXED_ADDR) != 0)
        shm_flags |= MAP_FIXED;
    shm_mapped = 0;
    shm_used = 0;
    shm_page_start = shm_page_end = shm_page_used = 0;
    if ((shm_si = shm_alloc(sizeof(struct schemas_info))) == NULL) {
        close(shm_fd);
        shm_base = NULL;
        PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
        return CONFD_ERR;
    }
    strcpy(shm_si->magic, SCHEMA_MAGIC);
    shm_si->long_size = sizeof(long);
    shm_si->ptr_size = sizeof(void *);
    shm_si->long_bytes = (long)SCHEMA_BYTES;
    shm_si->base = shm_base;
    if (shm_keepsize)
        shm_si->size = shm_size;
    else
        shm_si->size = 0;
    shm_si->flags = shm_flags;
    shm_si->libvsn = CONFD_LIB_VSN;
    memcpy(shm_si->confd_types, confd_types, sizeof(shm_si->confd_types));
    s_malloc = shm_alloc;
    s_page_alloc = shm_page_alloc;
    s_free = shm_free;
    s_find_type = shm_find_type;
    for (p = 0; p < n_str_to_val_funcs; p++)
        s_str_to_val_funcs[p] = (str_to_val_t)p;
    for (p = 0; p < n_val_to_str_funcs; p++)
        s_val_to_str_funcs[p] = (val_to_str_t)p;
    for (p = 0; p < n_validate_funcs; p++)
        s_validate_funcs[p] = (validate_t)p;
    PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
    return CONFD_OK;
}

int confd_mmap_schemas(const char *filename)
{
    struct stat st;
    int fd;
    void *tmpaddr, *addr;
    size_t size;
    int flags;
    struct schemas_info *ssi;
    struct schema *cur;
    struct confd_type *type;
    int i, j;
    int ret;

    if (stat(filename, &st) != 0) {
        return ret_err(CONFD_ERR_OS, "Failed to stat(%s): %s",
                       filename, strerror(errno));
    }
    if (st.st_size < sizeof(struct schemas_info)) {
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "Size of %s (%" PRIdMAX ") is too small",
                       filename, (intmax_t)st.st_size);
    }
    if ((fd = open(filename, O_RDONLY)) < 0) {
        return ret_err(CONFD_ERR_OS, "Failed to open %s: %s",
                       filename, strerror(errno));
    }
    /* check magic / arch / libvsn in the file */
    if ((tmpaddr = mmap(NULL, st.st_size, PROT_READ|PROT_WRITE,
                        MAP_PRIVATE, fd, 0)) == MAP_FAILED) {
        ret = ret_err(CONFD_ERR_OS,
                      "Failed to mmap %" PRIdMAX " bytes: %s",
                      (intmax_t)st.st_size, strerror(errno));
        close(fd);
        return ret;
    }
    ssi = tmpaddr;
    if (memcmp(ssi->magic, SCHEMA_MAGIC, sizeof(SCHEMA_MAGIC)) != 0) {
        close(fd);
        munmap(tmpaddr, st.st_size);
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "%s is not a ConfD schema file", filename);
    }
    if (ssi->long_size != sizeof(long) || ssi->ptr_size != sizeof(void *) ||
        ssi->long_bytes != (long)SCHEMA_BYTES) {
        close(fd);
        munmap(tmpaddr, st.st_size);
        return ret_err(CONFD_ERR_PROTOUSAGE,
                       "File %s is for different architecture", filename);
    }
    if (ssi->libvsn != CONFD_LIB_VSN) {
        int file_vsn = ssi->libvsn;
        close(fd);
        munmap(tmpaddr, st.st_size);
        return ret_err(CONFD_ERR_PROTOUSAGE,
                      "File %s was created by different library version: %x",
                       filename, file_vsn);
    }
    /*  get address / size / flags from the file */
    addr = ssi->base;
    size = ssi->size != 0 ? ssi->size : st.st_size;
    flags = ssi->flags;
    munmap(tmpaddr, st.st_size);
    PTHREAD_MUTEX_LOCK(&maapi_load_schemas_lock);
    do_free_schemas(1);
    if ((tmpaddr = mmap(addr, size, PROT_READ|PROT_WRITE,
                        MAP_PRIVATE|flags, fd, 0)) != addr) {
        if (tmpaddr == MAP_FAILED) {
            ret = ret_err(CONFD_ERR_OS,
                          "Failed to mmap %" PRIuMAX
                          " bytes at 0x%" PRIxPTR ": %s",
                          (uintmax_t)size, (uintptr_t)addr, strerror(errno));
        } else {
            ret = ret_err(CONFD_ERR_OS,
                          "Failed to mmap %" PRIuMAX
                          " bytes at 0x%" PRIxPTR
                          ": mmap() returned 0x%" PRIxPTR,
                          (uintmax_t)size, (uintptr_t)addr, (uintptr_t)tmpaddr);
        }
        close(fd);
        PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
        return ret;
    }
    close(fd);
    shm_base = addr;
    shm_mapped = size;
    ssi = shm_base;
    memcpy(ssi->confd_types, confd_types, sizeof(ssi->confd_types));
    for (i = 0; i < ssi->nschemas; i++) {
        cur = &ssi->schemas[i];
        for (j = 0; j < cur->num_types; j++) {
            type = cur->types[j].type;
            UPDATE_TYPE_PTR(str_to_val);
            UPDATE_TYPE_PTR(val_to_str);
            UPDATE_TYPE_PTR(validate);
            confd_type_init_type(type);
        }
    }
    confd_register_schemas(ssi->schemas, ssi->nschemas,
                           ssi->nschemas_listed, 1);

    if (ssi->hash2str != NULL) {
        hashtable_set_funcs(ssi->hash2str,
                            hash2str_hashfromkey, hash2str_equalkeys,
                            malloc, free, NULL, NULL);
        hashtable_set_funcs(ssi->str2hash,
                            str2hash_hashfromkey, str2hash_equalkeys,
                            malloc, free, NULL, NULL);
    }
    replace_hashtables(ssi->hash2str, ssi->str2hash, 1);

    PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
    return CONFD_OK;
}

void confd_free_schemas(void)
{
    PTHREAD_MUTEX_LOCK(&maapi_load_schemas_lock);
    do_free_schemas(0);
    PTHREAD_MUTEX_UNLOCK(&maapi_load_schemas_lock);
}

int maapi_get_schema_file_path(int sock, char **buf)
{
    int status;
    ETERM *reply;

    reply = op_request_term(sock, MAAPI_GET_SCHEMA_FILE_PATH, -1, 0,
                            NULL, &status);
    if (status <  0)
        return status;
    *buf = bin_dup(reply);
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_set_readonly_mode(int sock, int flag) {
    ETERM *request = erl_mk_int(flag);
    int status;
    op_request_term(sock, MAAPI_SET_READONLY, -1, 0, request, &status);
    erl_free_compound(request);
    return status;
}


int maapi_disconnect_remote(int sock, const char *address)
{
    return intcall(sock, MAAPI_DISCONNECT_REMOTE, -1,
                   erl_mk_binary(address, strlen(address)));
}

int maapi_disconnect_sockets(int sock, int *sockets, int nsocks)
{
    ETERM *list[nsocks];
    int i;

    for (i = 0; i < nsocks; i++)
        list[i] = erl_mk_int(sockets[i]);
    return intcall(sock, MAAPI_DISCONNECT_SOCKETS, -1,
                   erl_mk_list(list, nsocks));
}


int maapi_save_config(int sock, int th,  int flags,
                      const char *fmtpath, ...)
{
    int ret;
    va_list args;

    va_start(args,fmtpath);
    ret = maapi_vsave_config(sock, th, flags, fmtpath, args);
    va_end(args);
    return ret;
}

int maapi_vsave_config(int sock, int th,  int flags,
                      const char *fmtpath, va_list args)
{
    ETERM *epath;
    int isrel = 0;
    ETERM *req[2];
    ETERM *tup;
    ETERM *res;
    int status;

    if (fmtpath == NULL) {
        epath = erl_mk_empty_list();
    }
    else if (strcmp(fmtpath, "")==0) {
        epath = erl_mk_empty_list();
    }
    else if (flags & MAAPI_CONFIG_XPATH) {
        char tmpbuf[BUFSIZ];
        int r;
        r = substitute_percent(fmtpath, tmpbuf, sizeof(tmpbuf), args, 0);
        if ((r < 0) || (r > BUFSIZ)) {
            return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmtpath);
        }
        epath = erl_mk_binary(tmpbuf, r);
    }
    else {
        clr_confd_err();
        epath = parse_path(&isrel, fmtpath, args);
        if (epath == NULL)
            return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmtpath);
    }

    /* now build request tuple */
    req[0] = epath;
    req[1] = erl_mk_int(flags);
    tup = erl_mk_tuple(req, 2);
    if ((res = op_request_term(sock, MAAPI_SAVE_CONFIG, th,
                               isrel, tup, &status)) == NULL) {
        erl_free_compound(tup);
        return status;
    }
    status = ERL_INT_VALUE(res);
    erl_free_compound(res);
    erl_free_compound(tup);
    return status;
}

int maapi_save_config_result(int sock, int saveId)
{
    return intcall(sock, MAAPI_SAVE_CONFIG_RESULT, -1, erl_mk_int(saveId));
}

int maapi_roll_config(int sock, int th, const char *fmtpath, ...)
{
    int ret;
    va_list args;

    va_start(args,fmtpath);
    ret = maapi_vroll_config(sock, th, fmtpath, args);
    va_end(args);
    return ret;
}

int maapi_vroll_config(int sock, int th, const char *fmtpath, va_list args)
{
    ETERM *epath;
    int isrel;
    ETERM *res;
    int status;

    if (fmtpath == NULL) {
        epath = erl_mk_empty_list();
    }
    else if (strcmp(fmtpath, "")==0) {
        epath = erl_mk_empty_list();
    }
    else {
        clr_confd_err();
        epath = parse_path(&isrel, fmtpath, args);
        if (isrel || (epath == NULL))
            return ret_err(CONFD_ERR_BADPATH, "Bad path <%s>", fmtpath);
    }

    /* now build request tuple */
    if ((res = op_request_term(sock, MAAPI_ROLL_CONFIG, th,
                               0, epath, &status)) == NULL) {
        erl_free_compound(epath);
        return status;
    }
    status = ERL_INT_VALUE(res);
    erl_free_compound(res);
    erl_free_compound(epath);
    return status;
}


int maapi_roll_config_result(int sock, int rollId)
{
    return intcall(sock, MAAPI_ROLL_CONFIG_RESULT, -1, erl_mk_int(rollId));
}

int maapi_load_config(int sock, int th,  int flags,
                      const char *filename)
{
    ETERM *req[2];
    ETERM *tup;
    req[0] = erl_mk_int(flags);
    req[1] = erl_mk_binary(filename, strlen(filename));
    tup = erl_mk_tuple(req, 2);
    return intcall(sock, MAAPI_LOAD_CONFIG_FILE, th, tup);
}

int maapi_load_config_cmds(int sock, int th, int flags,
                           const char *cmds, const char *fmt, ...)
{
    va_list args;
    int ret;

    va_start(args,fmt);
    ret = maapi_vload_config_cmds(sock, th, flags, cmds, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vload_config_cmds(int sock, int th, int flags,
                            const char *cmds, const char *fmt, va_list args)
{
    int isrel, status, retval;
    ETERM *request;
    ETERM *tup[3];
    ETERM *reply;

    clr_confd_err();

    if (strlen(fmt) == 0) {
        tup[0] = erl_mk_empty_list();
    } else {
        if ((tup[0] = parse_path(&isrel, fmt, args)) == NULL ||
            isrel == 1) {
            return ret_err(CONFD_ERR_BADPATH, "bad path");
        }
    }
    tup[1] = erl_mk_int(flags);
    tup[2] = erl_mk_binary(cmds, strlen(cmds));

    request = erl_mk_tuple(tup, 3);
    reply = op_request_term(sock, MAAPI_LOAD_CONFIG_CMDS, th, 0,
                            request, &status);
    erl_free_compound(request);

    if (status == CONFD_OK && reply != NULL &&
        ERL_IS_INTEGER(reply)) {
        retval = ERL_INT_VALUE(reply);
    }
    else {
        retval = status;
    }
    if (reply) erl_free_compound(reply);
    return retval;
}

int maapi_load_config_stream(int sock, int th,  int flags)
{
    return intcall(sock, MAAPI_LOAD_CONFIG, th, erl_mk_int(flags));
}

int maapi_load_config_stream_result(int sock, int id)
{
    return intcall(sock, MAAPI_LOAD_CONFIG_RESULT, -1, erl_mk_int(id));
}

int maapi_get_stream_progress(int sock, int id)
{
    return intcall(sock, MAAPI_GET_STREAM_PROGRESS, -1, erl_mk_int(id));
}

static int xpath_results(int sock,
                         int (*result)(confd_hkeypath_t *kp,
                                       confd_value_t *v,
                                       void *state),
                         void (*trace)(char *),
                         void *initstate)
{
    while (1) {
        ETERM *e; int ret;
        confd_hkeypath_t kp;
        confd_value_t v, *vp;
        unsigned char buf[8];
        int uret;

        if ((e = term_read(sock, &ret, -1)) == NULL)
            return ret;
        if (ERL_IS_ATOM(TE(e,0))) {
            if (strncmp("return", (char *)ERL_ATOM_PTR(TE(e,0)), 6) == 0) {
                erl_free_compound(e);
                return CONFD_OK;
            }
            if ((ERL_TUPLE_SIZE(e) == 2) && ERL_IS_BINARY(TE(e,1))) {
                int len = ERL_BIN_SIZE(TE(e,1));
                char *tmp = confd_malloc(len + 1);
                if (tmp == NULL) {
                    erl_free_compound(e);
                    return CONFD_ERR;
                }
                memcpy(tmp, ERL_BIN_PTR(TE(e,1)), len);
                *(tmp + len) = '\000';
                if (strncmp("trace", (char *)ERL_ATOM_PTR(TE(e,0)), 6) == 0) {
                    if (trace) {
                        trace(tmp);
                    }
                    erl_free_compound(e);
                    free(tmp);
                    continue;
                }
                if (strncmp("error", (char *)ERL_ATOM_PTR(TE(e,0)), 5) == 0) {
                    erl_free_compound(e);
                    ret_err(CONFD_ERR_XPATH, "%s", tmp);
                    free(tmp);
                    return CONFD_ERR;
                }
                free(tmp);
            }
            erl_free_compound(e);
            return ret_err(CONFD_ERR_INTERNAL, "internal protocol error");
        }
        if (!populate_keypath(TE(e,0), &kp)) {
            erl_free_compound(e);
            return CONFD_ERR;
        }
        vp = NULL;
        if (ERL_TUPLE_SIZE(e) > 1) {
            ETERM *val = TE(e, 1);
            if (!bin_eq(val, "undefined")) {
                if (eterm_to_val(val, &v) == NULL) {
                    erl_free_compound(e);
                    return CONFD_ERR;
                }
                vp = &v;
            }
        }

        uret = result(&kp, vp, initstate);
        if (vp != NULL) { confd_free_eterm_val(vp); }
        erl_free_compound(e);

        put_int32(4, buf);
        switch (uret) {
        case ITER_STOP:
        case ITER_CONTINUE:
            put_int32(uret, buf+4);
            if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
                return ret;
            if (uret == ITER_STOP)
                return CONFD_OK;
            break;
        default:
            put_int32(ITER_STOP, buf+4);
            if ((ret = confd_write(sock, buf, 8)) != CONFD_OK)
                return ret;
            return ret_err(CONFD_ERR_PROTOUSAGE,
                           "Bad return value: %d", uret);
        }
    }
}

int maapi_vxpath_eval(int sock, int th, const char *expr,
                      int (*result)(confd_hkeypath_t *kp,
                                    confd_value_t *v,
                                    void *state),
                      void (*trace)(char *),
                      void *initstate,
                      const char *fmtpath, va_list args)
{
    int status;
    int isrel;
    ETERM *epath;
    ETERM *e[3];
    ETERM *req;

    clr_confd_err();

    if (fmtpath == NULL) {
        epath = erl_mk_empty_list();
    } else if (strcmp(fmtpath, "") == 0) {
        epath = erl_mk_empty_list();
    } else {
        epath = parse_path(&isrel, fmtpath, args);
        if (isrel || (epath == NULL)) {
            return ret_err(CONFD_ERR_BADPATH,
                           "Path is not valid context node <%s>", fmtpath);
        }
    }

    e[0] = erl_mk_binary(expr, strlen(expr));
    e[1] = trace ? erl_mk_atom("true") : erl_mk_atom("false");
    e[2] = epath;
    req = erl_mk_tuple(e, 3);

    op_request_term(sock, MAAPI_XPATH_EVAL, th, 0, req, &status);
    erl_free_compound(req);

    if (status == CONFD_OK) {
        return xpath_results(sock, result, trace, initstate);
    } else {
        return status;
    }
}

int maapi_xpath_eval(int sock, int th, const char *expr,
                     int (*result)(confd_hkeypath_t *kp,
                                   confd_value_t *v,
                                   void *state),
                     void (*trace)(char *),
                     void *initstate,
                     const char *fmtpath, ...)
{
    int ret;
    va_list args;
    va_start(args, fmtpath);
    ret = maapi_vxpath_eval(sock, th, expr, result, trace,
                            initstate, fmtpath, args);
    va_end(args);
    return ret;
}

int maapi_vxpath_eval_expr(int sock, int th, const char *expr, char **res,
                           void (*trace)(char *),
                           const char *fmtpath, va_list args)
{
    int status;
    int isrel = 1;
    ETERM *epath;
    ETERM *e[3];
    ETERM *req;

    *res = NULL;
    clr_confd_err();

    if (fmtpath == NULL) {
        epath = erl_mk_empty_list();
    } else if (strcmp(fmtpath, "") == 0) {
        epath = erl_mk_empty_list();
    } else {
        if ((epath = parse_path(&isrel, fmtpath, args)) == NULL) {
            return ret_err(CONFD_ERR_BADPATH, "Bad path to context node<%s>",
                           fmtpath);
        }
    }

    e[0] = erl_mk_binary(expr, strlen(expr));
    e[1] = trace ? erl_mk_atom("true") : erl_mk_atom("false");
    e[2] = epath;
    req = erl_mk_tuple(e, 3);

    op_request_term(sock, MAAPI_XPATH_EVAL_EXPR, th, isrel, req, &status);
    erl_free_compound(req);

    if (status == CONFD_OK) {
        for (;;) {
            ETERM *reply;

            if ((reply = term_read(sock, &status, -1)) == NULL)
                return status;

            if ((ERL_TUPLE_SIZE(reply) == 2) && ERL_IS_ATOM(TE(reply,0)) &&
                ERL_IS_BINARY(TE(reply,1))) {
                int len = ERL_BIN_SIZE(TE(reply,1));
                char *tmp = confd_malloc(len + 1);
                if (tmp == NULL) {
                    erl_free_compound(reply);
                    return CONFD_ERR;
                }
                memcpy(tmp, ERL_BIN_PTR(TE(reply,1)), len);
                *(tmp + len) = '\000';

                if (strncmp("ok",
                            (char *)ERL_ATOM_PTR(TE(reply,0)), 2) == 0) {
                    erl_free_compound(reply);
                    *res = tmp;
                    return CONFD_OK;
                }
                if (strncmp("error",
                            (char *)ERL_ATOM_PTR(TE(reply,0)), 5) == 0) {
                    erl_free_compound(reply);
                    ret_err(CONFD_ERR_XPATH, "%s", tmp);
                    free(tmp);
                    return CONFD_ERR;
                }
                if (strncmp("trace",
                            (char *)ERL_ATOM_PTR(TE(reply,0)), 5) == 0) {
                    erl_free_compound(reply);
                    if (trace) {
                        trace(tmp);
                    }
                    free(tmp);
                    continue;
                }
                free(tmp);
                erl_free_compound(reply);
                return ret_err(CONFD_ERR_INTERNAL, "internal protocol error");
            }
        }
    }

    return status;
}

int maapi_xpath_eval_expr(int sock, int th,
                          const char *expr, char **res,
                          void (*trace)(char *),
                          const char *fmtpath, ...)
{
    int ret;
    va_list args;
    va_start(args, fmtpath);
    ret = maapi_vxpath_eval_expr(sock, th, expr, res, trace, fmtpath, args);
    va_end(args);
    return ret;
}

int maapi_query_start(int sock, int th,
                      const char *expr,
                      const char *context_node,
                      int chunk_size,
                      int initial_offset,
                      enum confd_query_result_type result_as,
                      int nselect, const char *select[],
                      int nsort,   const char *sort[])
{
    int i, status, ret;
    ETERM *req;
    ETERM *reqs[3];
    ETERM *opts = erl_mk_empty_list();
    ETERM *selectl;
    ETERM *reply;

    if (context_node && (*context_node != '\000')) {
        ETERM *t[2] = { erl_mk_atom("context_node_string"),
                        erl_mk_string(context_node) };
        opts = erl_cons(erl_mk_tuple(t , 2), opts);
    }

    if (chunk_size > 0) {
        ETERM *t[2] = { erl_mk_atom("chunk_size"),
                        erl_mk_int(chunk_size) };
        opts = erl_cons(erl_mk_tuple(t , 2), opts);
    }
    if (initial_offset > 1) {
        ETERM *t[2] = { erl_mk_atom("initial_offset"),
                        erl_mk_int(initial_offset) };
        opts = erl_cons(erl_mk_tuple(t, 2), opts);
    }
    {
        ETERM *t[2];
        t[0] = erl_mk_atom("result_as");
        switch (result_as) {
        case CONFD_QUERY_TAG_VALUE:
        {
            ETERM *tt[2] = { erl_mk_atom("tag"), erl_mk_atom("leaf_value") };
            t[1] = erl_mk_list(tt, 2);
            break;
        }
        case CONFD_QUERY_HKEYPATH_VALUE:
        {
            ETERM *tt[2] =
                { erl_mk_atom("ikeypath"), erl_mk_atom("leaf_value") };
            t[1] = erl_mk_list(tt, 2);
            break;
        }
        case CONFD_QUERY_HKEYPATH:
            t[1] = erl_mk_atom("ikeypath");
            break;
        case CONFD_QUERY_STRING:
        default:
            t[1] = erl_mk_atom("string");
        }

        opts = erl_cons(erl_mk_tuple(t, 2), opts);
    }

    if (nsort != 0) {
        int i, n = abs(nsort);
        ETERM *t[2];
        t[0] = erl_mk_atom("sort");
        ETERM *l[n];
        for (i=0; i<n; i++) {
            l[i] = erl_mk_string(sort[i]);
        }
        t[1] = erl_mk_list(l, n);
        opts = erl_cons(erl_mk_tuple(t, 2), opts);
        if (nsort < 0) {
            opts = erl_cons(erl_mk_atom("reverse"), opts);
        }
    }

    {
        ETERM *l[nselect];
        for (i=0; i<nselect; i++) {
            l[i] = erl_mk_string(select[i]);
        }
        selectl = erl_mk_list(l, nselect);
    }

    reqs[0] = erl_mk_string(expr);
    reqs[1] = selectl;
    reqs[2] = opts;
    req = erl_mk_tuple(reqs, 3);
    reply = op_request_term(sock, MAAPI_QUERY_START, th, 0, req, &status);
    erl_free_compound(req);
    if (status == CONFD_OK) {
        if ((reply != NULL) && ERL_IS_INTEGER(reply)) {
            ret = ERL_INT_VALUE(reply);
        } else {
            confd_set_errno(CONFD_ERR_INTERNAL);
            ret = CONFD_ERR;
        }
    } else {
        ret = status;
    }
    if (reply) erl_free_compound(reply);
    return ret;
}

int maapi_query_vstart(int sock, int th,
                       const char *expr,
                       const char *context_node,
                       int chunk_size,
                       int initial_offset,
                       enum confd_query_result_type result_as,
                       int select_nparams,
                       va_list select_params)
{
    int i;
    const char *select[select_nparams];

    for (i=0; i<select_nparams; i++) {
        select[i] = va_arg(select_params, char *);
    }
    return maapi_query_start(sock, th, expr, context_node,
                             chunk_size, initial_offset, result_as,
                             select_nparams, select, 0, NULL);
}

int maapi_query_startv(int sock, int th,
                       const char *expr,
                       const char *context_node,
                       int chunk_size,
                       int initial_offset,
                       enum confd_query_result_type result_as,
                       int select_nparams,
                       ...)
{
    int ret;
    va_list select_params;
    va_start(select_params, select_nparams);
    ret = maapi_query_vstart(sock, th, expr, context_node,
                             chunk_size, initial_offset,
                             result_as, select_nparams, select_params);
    va_end(select_params);
    return ret;
}

int maapi_query_free_result(struct confd_query_result *qr)
{
    if (qr) {
        if (qr->nresults > 0) {
            int i, j;
            for (i=0; i<qr->nresults; i++) {
                for (j=0; j<qr->nelements; j++) {
#define IF_NOT_NULL(F, P) { if (P) { F(P); } }
                    switch (qr->type) {
                    case CONFD_QUERY_STRING:
                        IF_NOT_NULL(free, qr->results[i].str[j]);
                        break;
                    case CONFD_QUERY_HKEYPATH:
                        IF_NOT_NULL(confd_free_eterm_keypath,
                                    &qr->results[i].hkp[j]);
                        break;
                    case CONFD_QUERY_HKEYPATH_VALUE:
                        IF_NOT_NULL(confd_free_eterm_keypath,
                                    &qr->results[i].kv[j].hkp);
                        IF_NOT_NULL(confd_free_eterm_val,
                                    &qr->results[i].kv[j].val);
                        break;
                    case CONFD_QUERY_TAG_VALUE:
                        IF_NOT_NULL(confd_free_eterm_val,
                                    &qr->results[i].tv[j].v);
                        break;
#undef IF_NOT_NULL
                    }
                }
            }
            free(qr->results[0].str); /* the block */
            free(qr->results);        /* the result array */
            if (qr->__internal) {
                ETERM *e = qr->__internal;
                erl_free_compound(e);
            }
        }
        free(qr);
    }
    return CONFD_OK;
}

int maapi_query_result(int sock, int qh, struct confd_query_result **qrs)
{
    int ret;
    ETERM *reply;
    reply = op_request_term(sock, MAAPI_QUERY_RESULT, qh, 0, NULL, &ret);
    if (ret == CONFD_OK) {
        struct confd_query_result *qr =
            confd_malloc(sizeof(struct confd_query_result));
        if (qr) {
            int fail = 0;
            memset(qr, 0, sizeof(*qr));
            if (! ERL_IS_TUPLE(reply) || ERL_TUPLE_SIZE(reply) != 5) {
                fail++;
                goto done;
            }
            qr->offset = ERL_INT_VALUE(TE(reply, 0));
            qr->nresults = ERL_INT_VALUE(TE(reply, 1));
            qr->nelements = ERL_INT_VALUE(TE(reply, 2));
            qr->type = ERL_INT_VALUE(TE(reply, 3));
            if (qr->nresults > 0) {
                int i, j;
                void *block = NULL;
                size_t element_sz = 0;
                ETERM *rl, *c, *cl;
                /* allocate the results array */
                qr->results =
                    confd_malloc(qr->nresults * sizeof(qr->results[0]));
                if (qr->results) {
                    /* allocate a block big enough for the arrays of
                     * elements that the results point to */
                    size_t sz;
                    switch (qr->type) {
                    case CONFD_QUERY_STRING:
                        element_sz = sizeof(char *);
                        break;
                    case CONFD_QUERY_HKEYPATH:
                        element_sz = sizeof(qr->results[0].hkp[0]);
                        break;
                    case CONFD_QUERY_HKEYPATH_VALUE:
                        element_sz =  sizeof(qr->results[0].kv[0]);
                        break;
                    case CONFD_QUERY_TAG_VALUE:
                        element_sz =  sizeof(qr->results[0].tv[0]);
                        break;
                    }
                    if (element_sz) {
                        sz = element_sz * qr->nresults * qr->nelements;
                        block = confd_malloc(sz);
                        if (block) {
                            /* zero out the memory, we rely on non-used
                             * pointers being null in free_result above */
                            memset(qr->results, 0,
                                   qr->nresults * sizeof(qr->results[0]));
                            memset(block, 0, sz);
                        } else {
                            fail++;
                        }
                    } else {
                        fail++;
                    }
                } else {
                    fail++;
                }
                if (fail) { ret = CONFD_ERR; goto done; }
                /* populate the results array with pointers into the block */
                for (i=0, rl = TE(reply, 4); i < qr->nresults;
                     i++, rl = ERL_CONS_TAIL(rl)) {
                    cl = ERL_CONS_HEAD(rl);
                    /* okay, since all the types in the union are pointers */
                    qr->results[i].str = block +
                        ((i * qr->nelements) * element_sz);
                    /* populate the block with result elements */
                    for (j=0; j < qr->nelements; j++, cl=ERL_CONS_TAIL(cl)) {
                        c = ERL_CONS_HEAD(cl);
                        switch (qr->type) {
                        case CONFD_QUERY_STRING:
                        {
                            if (ERL_IS_LIST(c)) {
                                qr->results[i].str[j] = erl_iolist_to_string(c);
                            } else {
                                size_t len = ERL_BIN_SIZE(c);
                                char *tmp = confd_malloc(len+1);
                                if (tmp) {
                                    memcpy(tmp, ERL_BIN_PTR(c), len);
                                    tmp[len] = '\000';
                                    qr->results[i].str[j] = tmp;
                                } else {
                                    fail++;
                                }
                            }
                            break;
                        }
                        case CONFD_QUERY_HKEYPATH:
                            if (!populate_keypath(c, &qr->results[i].hkp[j]))
                                fail++;
                            break;
                        case CONFD_QUERY_HKEYPATH_VALUE:
                            if (!populate_keypath(TE(c,0),
                                                  &qr->results[i].kv[j].hkp))
                                fail++;
                            if (!eterm_to_val(TE(c,1),
                                              &qr->results[i].kv[j].val))
                                fail++;
                            break;
                        case CONFD_QUERY_TAG_VALUE:
                            if (!eterm_to_tag_val(c, &qr->results[i].tv[j], 0))
                                fail++;
                            break;
                        }
                        if (fail) break;
                    }
                    if (fail) { ret = CONFD_ERR; break; }
                }
            }
        done:
            if (fail) {
                if (ret == CONFD_OK) {
                    ret =
                        ret_err(CONFD_ERR_INTERNAL, "internal protocol error");
                }
                maapi_query_free_result(qr);
            } else {
                qr->__internal = reply;
                *qrs = qr;
            }
        } else {
            ret = CONFD_ERR;
        }
    }
    if ((ret != CONFD_OK) && reply) {
        erl_free_compound(reply);
    }
    return ret;
}

int maapi_query_result_count(int sock, int qh)
{
    int status = CONFD_OK;
    confd_value_t res = { .type = C_UINT32, .val.u32 = 0 };
    arg_request(sock, MAAPI_QUERY_RESULT_COUNT, qh, &status, 0, &res, NULL);
    if (status == CONFD_OK) {
        return CONFD_GET_INT32(&res);
    }
    return status;
}

int maapi_query_reset_to(int sock, int qh, int offset)
{
    int ret;
    ETERM *request, *reply;
    request = erl_mk_int(offset);
    reply = op_request_term(sock, MAAPI_QUERY_RESET, qh, 0, request, &ret);
    erl_free_compound(request);
    if (reply) { erl_free_compound(reply); }
    return ret;
}

int maapi_query_reset(int sock, int qh)
{
    int ret;
    ETERM *reply;
    reply = op_request_term(sock, MAAPI_QUERY_RESET, qh, 0, NULL, &ret);
    if (reply) { erl_free_compound(reply); }
    return ret;
}

int maapi_query_stop(int sock, int qh)
{
    int ret;
    ETERM *reply;
    reply = op_request_term(sock, MAAPI_QUERY_STOP, qh, 0, NULL, &ret);
    if (reply) { erl_free_compound(reply); }
    return ret;
}

int maapi_do_display(int sock, int th, const char *fmtpath, ...)
{
   int ret;
   va_list args;
   va_start(args,fmtpath);

   ret = request_int(sock, MAAPI_DO_DISPLAY, th, fmtpath, args);
   va_end(args);
   return ret;
}

int maapi_vdo_display(int sock, int th, const char *fmtpath, va_list args)
{
   return request_int(sock, MAAPI_DO_DISPLAY, th, fmtpath, args);
}

int maapi_install_crypto_keys(int sock)
{
    int status;
    ETERM *reply;
    ETERM *item;

    reply = op_request_term(sock, MAAPI_GET_CRYPTO_KEYS, -1, 0, NULL, &status);
    if (status < 0) {
        return CONFD_ERR;
    }
    if (! ERL_IS_TUPLE(reply) || ERL_TUPLE_SIZE(reply) != 6) {
        erl_free_compound(reply);
        return confd_internal_error("Bad data for crypto keys");
    }
    item = TE(reply, 0);
    if (ERL_IS_BINARY(item)) {
        /* install des keys */
        memcpy(&confd_crypto_keys.des3_key1[0], ERL_BIN_PTR(TE(reply,0)), 8);
        memcpy(&confd_crypto_keys.des3_key2[0], ERL_BIN_PTR(TE(reply,1)), 8);
        memcpy(&confd_crypto_keys.des3_key3[0], ERL_BIN_PTR(TE(reply,2)), 8);
        memcpy(&confd_crypto_keys.des3_ivec[0], ERL_BIN_PTR(TE(reply,3)), 8);
        confd_crypto_keys.des3_keys_initialized = 1;
    }
    item  = TE(reply, 4);
    if (ERL_IS_BINARY(item)) {
        /* install aes keys */
        memcpy(&confd_crypto_keys.aes_key[0], ERL_BIN_PTR(TE(reply,4)), 16);
        memcpy(&confd_crypto_keys.aes_ivec[0], ERL_BIN_PTR(TE(reply,5)), 16);
        confd_crypto_keys.aes_keys_initialized = 1;
    }
    erl_free_compound(reply);
    return CONFD_OK;
}

int maapi_aaa_reload(int sock, int synchronous)
{
    return intcall(sock, MAAPI_AAA_RELOAD, -1, erl_mk_int(synchronous));
}

int maapi_aaa_reload_path(int sock, int synchronous, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vaaa_reload_path(sock, synchronous, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vaaa_reload_path(int sock, int synchronous, const char *fmt,
                           va_list args)
{
    ETERM *epath, *req;
    ETERM *tup[3];
    int isrel;
    int useikp = 0;

    clr_confd_err();
    epath = parse_path(&isrel, fmt, args);
    if (isrel || epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    tup[0] = erl_mk_int(synchronous);
    tup[1] = epath;
    tup[2] = erl_mk_int(useikp);
    req = erl_mk_tuple(tup, 3);
    return intcall(sock, MAAPI_AAA_RELOAD_PATH, -1, req);
}

int maapi_snmpa_reload(int sock, int synchronous)
{
    return intcall(sock, MAAPI_SNMPA_RELOAD, -1, erl_mk_int(synchronous));
}

int maapi_start_phase(int sock, int phase, int synchronous)
{
    ETERM *e[2];
    if ((phase < 1) || (phase > 2)) {
        return ret_err(CONFD_ERR_PROTOUSAGE, "Invalid phase");
    }
    e[0] = erl_mk_int(phase);
    e[1] = erl_mk_int(synchronous);
    return intcall(sock, MAAPI_START_PHASE, -1, erl_mk_tuple(e, 2));
}

int maapi_wait_start(int sock, int phase)
{
    return intcall(sock, MAAPI_WAIT_START, -1, erl_mk_int(phase));
}

int maapi_reload_config(int sock)
{
    return intcall(sock, MAAPI_RELOAD_CONFIG, -1, NULL);
}

int maapi_reopen_logs(int sock)
{
    return intcall(sock, MAAPI_REOPEN_LOGS, -1, NULL);
}

int maapi_stop(int sock, int synchronous)
{
    int ret;
    if ((ret = intcall(sock, MAAPI_STOP, -1, erl_mk_int(synchronous))) ==
        CONFD_EOF) {
        /* EOF is expected when daemon exits */
        clr_confd_err();
        ret = CONFD_OK;
    }
    return ret;
}

int maapi_rebind_listener(int sock, int listener)
{
    return intcall(sock, MAAPI_REBIND_LISTENER, -1, erl_mk_int(listener));
}

int maapi_clear_opcache(int sock, const char *fmt, ...)
{
    int ret;
    va_list args;

    va_start(args, fmt);
    ret = maapi_vclear_opcache(sock, fmt, args);
    va_end(args);
    return ret;
}

int maapi_vclear_opcache(int sock, const char *fmt, va_list args)
{
    ETERM *epath, *req;
    ETERM *tup[2];
    int isrel;
    int useikp = 0;

    clr_confd_err();
    /* parse_path() turns fmt == NULL / "" into ['.'] with isrel == 1
       - which is fine, since it's actually the same as "/" here, and we
       want to allow that but not other relative paths - catch it up front */
    if (fmt == NULL || *fmt == '\0')
        epath = parse_path(&isrel, "/", args);
    else
        epath = parse_path(&isrel, fmt, args);
    if (isrel || epath == NULL)
        return ret_err(CONFD_ERR_BADPATH,"Bad path <%s>", fmt);
    tup[0] = epath;
    tup[1] = erl_mk_int(useikp);
    req = erl_mk_tuple(tup, 2);
    return intcall(sock, MAAPI_CLEAR_OPCACHE, -1, req);
}
