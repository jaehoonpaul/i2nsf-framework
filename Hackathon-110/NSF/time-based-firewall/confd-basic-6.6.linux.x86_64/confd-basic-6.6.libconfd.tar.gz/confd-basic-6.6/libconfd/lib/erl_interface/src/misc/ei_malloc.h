/*
 * %CopyrightBegin%
 * 
 * Copyright Ericsson AB 2002-2009. All Rights Reserved.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * %CopyrightEnd%
 *

 */
#ifndef _EI_MALLOC_H
#define _EI_MALLOC_H

void* ei_malloc(long size);
void* ei_realloc(void* orig, long size);
void  ei_free(void *ptr);

typedef void* (*ei_malloc_fun_t)(long size);
typedef void  (*ei_free_fun_t)(void* ptr);
typedef void* (*ei_realloc_fun_t)(void* orig, long size);

void ei_set_malloc(ei_malloc_fun_t my_malloc,
		   ei_realloc_fun_t my_realloc,
		   ei_free_fun_t my_free);

#endif /* _EI_MALLOC_H */
