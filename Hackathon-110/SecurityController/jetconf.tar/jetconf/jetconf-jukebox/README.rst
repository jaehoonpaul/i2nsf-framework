.. |date| date::

*******
JetConf example Jukebox backend
*******

:Author: Pavel Špírek <pavel.spirek@nic.cz>
:Date: |date|

