import os


print(sorted(os.listdir("log")))
