/*
 * Copyright 2017 Tail-F Systems AB
 * Tail-F customers are permitted to redistribute in binary form, with
 * or without modification, for use in customer products.
 */

#include <confd.h>

// LINUXCFG component setup() procedure registering CDB subscriber
void routing_subs_setup(struct confd_daemon_ctx *dctx, int rsock);
