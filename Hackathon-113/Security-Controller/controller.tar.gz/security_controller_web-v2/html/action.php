<?php

$rule_name = $_POST['rule_name'];

echo $rule_name;


?>
