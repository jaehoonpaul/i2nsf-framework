
import logo from './logo.svg';
import './App.css';
import { useHistory } from 'react-router-dom';
import {RealTimeChart5_block, RealTimeChart6_block, RealTimeChart5, RealTimeChart6} from '.';

const Table2 = ()=> {

const history = useHistory();
        const componentClicked = (e) =>{
        if (e==='main'){
        history.push({pathname:"/"})
        }
        }


  return (

    <div className="App">
      <header style={{backgroundColor: "white"}} className="App-header">
        <div style={{fontWeight:'600', fontSize:'40px', color:'black'}}>
<p>
          Firewall Resources Data
</p>
</div>
<button onClick={(e)=> componentClicked('main')}>URL Filtering</button>
<div style={{display:'flex'}}>
<div style={{fontSize:'20px', marginTop:'20px', marginRight:'20px', width:'40%', textAlign:'left',color:'black'}}>
NSF Name : time_based_firewall
</div>
<div>
       <RealTimeChart5_block>
       </RealTimeChart5_block>
       <RealTimeChart5>
       </RealTimeChart5>
</div>
<div>
       <RealTimeChart6_block>
       </RealTimeChart6_block>
       <RealTimeChart6>
       </RealTimeChart6>

</div>
</div>
        </header>
    </div>

)}

export default Table2;
