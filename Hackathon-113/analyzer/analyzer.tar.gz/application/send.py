import os

print("Sending feedback to Security Controller");

with open('just.xml', 'r') as f:
  files = f.read()
  print(files)
  f.close()

os.system("/home/ubuntu/confd/bin/netconf-console --host 10.0.0.17 feedback.xml")
