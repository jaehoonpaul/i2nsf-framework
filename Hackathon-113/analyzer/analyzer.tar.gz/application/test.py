import socket
import json

HOST = '115.145.178.170'
PORT = 65432

with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as sock:
  sock.connect((HOST,PORT))

  src_ip = "10.0.0.1"
  policy = {
         'i2nsf-security-policy': {
           'system-policy-name': 'feedback-policy-01',
           'rules': {
             'rule-name': 'anti-ddos-rule',
             'condition': {
               'ipv4': {
                 'source': src_ip,
               },
               'ddos': {
                 'alert-packet-rate': 500,
               }
             },
             'action': {
               'packet-action': {
                 'ingress-action': 'drop'
               }
             }
           }
         }
      }

  print(json.dumps(policy,indent=4))
  data = json.dumps(policy)
  sock.sendall(bytes(data,encoding='utf-8'))
  received = sock.recv(1024)
