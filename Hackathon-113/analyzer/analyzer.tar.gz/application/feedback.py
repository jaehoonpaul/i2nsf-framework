import pandas as pd
import joblib

load_model = joblib.load('my_model.pkl')

d = {'memory-usage':[18],
     'cpu-usage':[100],
     'disk-usage':[79],
     'disk-left':[20],
     'in-Traffic-Gap':[1],
     'out-Traffic-Gap':[3],
}

#score = load_model.predict(observation)

df = pd.DataFrame(data=d)
#print(df)
score = load_model.predict(df)
print(score[0])

